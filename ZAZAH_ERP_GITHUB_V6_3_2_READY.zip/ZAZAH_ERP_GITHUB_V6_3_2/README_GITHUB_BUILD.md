# ZAZAH ERP V6.3.2 — Build APK avec GitHub Actions

Ce projet est prêt à être envoyé sur GitHub et à générer automatiquement un APK Android.

## Méthode rapide

1. Créez un nouveau dépôt GitHub, par exemple `zazah-erp-android`.
2. Décompressez ce ZIP.
3. Envoyez **le contenu du dossier** dans le dépôt, de façon à avoir `app/`, `.github/`, `build.gradle` et `settings.gradle` à la racine.
4. Ouvrez l'onglet **Actions** du dépôt.
5. Sélectionnez **Build ZAZAH ERP APK**.
6. Cliquez sur **Run workflow**.
7. Quand le build devient vert, ouvrez-le et téléchargez l'artifact **ZAZAH-ERP-V6.3.2-APK**.
8. Dans le ZIP de l'artifact se trouve `ZAZAH_ERP_V6.3.2.apk`.

## Build automatique

Le workflow se lance aussi automatiquement lors d'un push sur `main` ou `master`.

## Créer une Release GitHub avec APK

Créez et poussez un tag commençant par `v`, par exemple :

```bash
git tag v6.3.2
git push origin v6.3.2
```

GitHub Actions compile alors l'APK et l'ajoute automatiquement à une **GitHub Release**.

## Configuration utilisée

- Java 17
- Android SDK 35
- Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- APK généré : Debug, signé automatiquement avec la clé debug du runner

## Données SQLite

Installer une nouvelle APK avec le même `applicationId` par-dessus l'application existante conserve normalement les données si la signature est compatible. Une APK Debug générée par GitHub n'utilise pas forcément la même clé Debug que votre PC. Pour des mises à jour fiables sans désinstallation, utilisez ensuite une clé de signature Release fixe stockée dans GitHub Secrets.
