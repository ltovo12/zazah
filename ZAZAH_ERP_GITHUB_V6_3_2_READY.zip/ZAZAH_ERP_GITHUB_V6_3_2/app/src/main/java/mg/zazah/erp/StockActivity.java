package mg.zazah.erp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class StockActivity extends AppCompatActivity {
    DatabaseHelper db;
    Spinner emp;
    EditText q;
    ListView list;
    Button btnNewVariant;
    Button btnProducts;
    ArrayList<Long> ids = new ArrayList<>();
    ArrayList<Row> rows = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_stock);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        emp = findViewById(R.id.spinnerStockEmp);
        q = findViewById(R.id.inputStockSearch);
        list = findViewById(R.id.listStock);
        btnNewVariant = findViewById(R.id.btnNewVariant);
        btnProducts = findViewById(R.id.btnStockProducts);

        ArrayList<String> names = new ArrayList<>();
        Cursor c = db.emplacements();
        while (c.moveToNext()) { ids.add(c.getLong(0)); names.add(c.getString(1)); }
        c.close();
        emp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        selectTsenaDefault(names);
        emp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int i, long l) { load(); }
            public void onNothingSelected(AdapterView<?> p) {}
        });
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ load(); }
            public void afterTextChanged(Editable e){}
        });
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < rows.size()) showAddQtyDialog(rows.get(position));
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < rows.size()) showMoveVariantDialog(rows.get(position));
            return true;
        });
        btnNewVariant.setOnClickListener(v -> showNewVariantDialog());
        btnProducts.setOnClickListener(v -> startActivity(new Intent(this, ProductsActivity.class)));
        load();
    }

    @Override protected void onResume() {
        super.onResume();
        if (db != null && q != null) load();
    }

    private void selectTsenaDefault(ArrayList<String> names) {
        int tsenaIndex = -1;
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            if (name != null && "tsena".equalsIgnoreCase(name.trim())) {
                tsenaIndex = i;
                break;
            }
        }
        if (tsenaIndex >= 0) emp.setSelection(tsenaIndex, false);
        else if (emp.getCount() > 0) emp.setSelection(0, false);
    }

    private long currentEmplacementId() {
        if (ids.isEmpty()) return db.defaultEmplacementId();
        int p = emp.getSelectedItemPosition();
        if (p < 0 || p >= ids.size()) return db.defaultEmplacementId();
        return ids.get(p);
    }

    void load() {
        if (ids.isEmpty()) return;
        rows.clear();
        Cursor c = db.stock(q.getText().toString(), currentEmplacementId());
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        while (c.moveToNext()) {
            Row r = new Row();
            r.variantId = c.getLong(0);
            r.productId = c.getLong(7);
            r.product = c.getString(1);
            r.couleur = c.getString(2);
            r.taille = c.getString(3);
            r.code = c.getString(4);
            r.price = c.getDouble(5);
            r.stock = c.getDouble(6);
            rows.add(r);
            String d = r.product;
            if (!r.couleur.isEmpty()) d += " • " + r.couleur;
            if (!r.taille.isEmpty()) d += " • T." + r.taille;
            String sub = "Stock : " + String.format(Locale.FRANCE, "%.1f", r.stock) + "  •  " +
                    String.format(Locale.FRANCE, "%,.0f", r.price) + " Ar" +
                    (r.code.isEmpty() ? "" : "  •  " + r.code);
            items.add(new TwoLineAdapter.Item(d, sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, items));
    }

    void showAddQtyDialog(Row row) {
        LinearLayout card = dialogCard();
        addSectionTitle(card, "Ajouter quantité stock");
        addHint(card, "Mettez à jour rapidement le stock de cette variante.");

        TextView info = new TextView(this);
        info.setText(row.display() + "\nStock actuel : " + qty(row.stock));
        info.setTextColor(0xFF334155);
        info.setTextSize(14);
        info.setPadding(0, 0, 0, dp(12));
        card.addView(info);

        addLabel(card, "Quantité à ajouter");
        EditText qtyInput = styledInput("Ex: 1 ou 0,5");
        qtyInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        qtyInput.setText("1");
        card.addView(qtyInput);

        AlertDialog dialog = new DialogUi.Builder(this)
                .setTitle("Stock")
                .setView(dialogContainer(card))
                .setPositiveButton("Ajouter", (d, w) -> {
                    try {
                        double value = num(qtyInput);
                        db.addStock(row.variantId, currentEmplacementId(), value);
                        load();
                        Toast.makeText(this, "Stock ajouté dans SQLite", Toast.LENGTH_SHORT).show();
                        if ("ONLINE".equals(AppPrefs.mode(this))) startActivity(new Intent(this, SyncActivity.class));
                    } catch (Exception ex) {
                        Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNeutralButton("Changer produit", (d, w) -> showMoveVariantDialog(row))
                .setNegativeButton("Annuler", null)
                .create();
        dialog.show();
        DialogUi.style(dialog);
    }

    void showMoveVariantDialog(Row row) {
        ArrayList<ProductOption> allProducts = new ArrayList<>();
        Cursor c = db.productsSimple();
        while (c.moveToNext()) {
            ProductOption p = new ProductOption();
            p.id = c.getLong(0);
            p.name = c.getString(1);
            p.price = c.getDouble(2);
            p.imageUrl = c.getString(3);
            if (p.id != row.productId) allProducts.add(p);
        }
        c.close();

        if (allProducts.isEmpty()) {
            Toast.makeText(this, "Aucun autre produit disponible", Toast.LENGTH_LONG).show();
            return;
        }

        LinearLayout card = dialogCard();
        addSectionTitle(card, "Changer le produit");
        addHint(card, "La variante garde son ID, son code-barres, sa couleur, sa taille, son prix et tout son stock.");

        TextView current = new TextView(this);
        current.setText("Variante actuelle :\n" + row.display());
        current.setTextColor(0xFF334155);
        current.setTextSize(14);
        current.setPadding(0, 0, 0, dp(10));
        card.addView(current);

        addLabel(card, "Rechercher le nouveau produit");
        EditText search = styledInput("Nom du produit...");
        card.addView(search);

        ListView productList = new ListView(this);
        productList.setDividerHeight(1);
        card.addView(productList, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(300)));

        ArrayList<ProductOption> filtered = new ArrayList<>();
        final ArrayAdapter<ProductOption> adapter = new ArrayAdapter<ProductOption>(
                this, android.R.layout.simple_list_item_1, filtered) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                ProductOption p = getItem(position);
                if (p != null) v.setText(p.name + "  •  " + money(p.price) + " Ar");
                v.setPadding(dp(12), dp(12), dp(12), dp(12));
                return v;
            }
        };
        productList.setAdapter(adapter);

        Runnable applyFilter = () -> {
            String needle = search.getText().toString().trim().toLowerCase(Locale.ROOT);
            filtered.clear();
            for (ProductOption p : allProducts) {
                if (needle.isEmpty() || p.name.toLowerCase(Locale.ROOT).contains(needle)) {
                    filtered.add(p);
                }
            }
            adapter.notifyDataSetChanged();
        };
        applyFilter.run();
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ applyFilter.run(); }
            public void afterTextChanged(Editable e){}
        });

        AlertDialog dialog = new DialogUi.Builder(this)
                .setTitle("Déplacer la variante")
                .setView(dialogContainer(card))
                .setNegativeButton("Fermer", null)
                .create();

        productList.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= filtered.size()) return;
            ProductOption target = filtered.get(position);
            new DialogUi.Builder(this)
                    .setTitle("Confirmer le changement")
                    .setMessage("Déplacer « " + row.display() + " » vers « " + target.name + " » ?\n\nLe stock existant sera conservé.")
                    .setPositiveButton("Déplacer", (d, w) -> {
                        try {
                            db.moveVariantProduct(row.variantId, target.id);
                            dialog.dismiss();
                            load();
                            Toast.makeText(this, "Variante déplacée vers " + target.name, Toast.LENGTH_LONG).show();
                            if ("ONLINE".equals(AppPrefs.mode(this))) {
                                startActivity(new Intent(this, SyncActivity.class));
                            }
                        } catch (Exception ex) {
                            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNegativeButton("Annuler", null)
                    .show();
        });

        dialog.show();
        DialogUi.style(dialog);
    }

    void showNewVariantDialog() {
        LinearLayout card = dialogCard();
        addSectionTitle(card, "Nouveau variant");
        addHint(card, "Créez un variant avec couleur, taille, prix, image et stock initial.");

        ArrayList<ProductOption> products = new ArrayList<>();
        Cursor c = db.productsSimple();
        while (c.moveToNext()) {
            ProductOption p = new ProductOption();
            p.id = c.getLong(0);
            p.name = c.getString(1);
            p.price = c.getDouble(2);
            p.imageUrl = c.getString(3);
            products.add(p);
        }
        c.close();

        addLabel(card, "Produit");

        EditText productSearch = styledInput("Rechercher un produit...");
        productSearch.setSingleLine(true);
        card.addView(productSearch);

        Spinner productSpinner = new Spinner(this);
        productSpinner.setBackgroundResource(R.drawable.bg_input);
        ArrayList<ProductOption> filteredProducts = new ArrayList<>(products);
        ArrayAdapter<ProductOption> productAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                filteredProducts
        );
        productSpinner.setAdapter(productAdapter);
        card.addView(productSpinner, matchWrap());

        addLabel(card, "Couleur");
        ArrayList<ColorOption> colors = defaultColors();
        Spinner colorSpinner = new Spinner(this);
        colorSpinner.setBackgroundResource(R.drawable.bg_input);
        ArrayAdapter<ColorOption> colorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, colors);
        colorSpinner.setAdapter(colorAdapter);
        card.addView(colorSpinner, matchWrap());

        EditText customColorInput = styledInput("Nom de la couleur");
        customColorInput.setVisibility(View.GONE);
        card.addView(customColorInput);

        TextView colorPreview = new TextView(this);
        colorPreview.setText("  Couleur sélectionnée  ");
        colorPreview.setTextSize(12);
        colorPreview.setGravity(Gravity.CENTER);
        colorPreview.setTextColor(0xFFFFFFFF);
        colorPreview.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout.LayoutParams colorPreviewLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        colorPreviewLp.bottomMargin = dp(10);
        colorPreview.setLayoutParams(colorPreviewLp);
        card.addView(colorPreview);

        colorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= colors.size()) return;
                ColorOption selected = colors.get(position);
                customColorInput.setVisibility(selected.custom ? View.VISIBLE : View.GONE);
                colorPreview.setText(selected.custom ? "  Couleur personnalisée  " : "  " + selected.name + "  ");
                colorPreview.setBackgroundColor(selected.custom ? 0xFF714B67 : selected.argb);
                if (selected.argb == 0xFFFFFFFF || selected.argb == 0xFFFFFFF0 || selected.argb == 0xFFFFF8DC || selected.argb == 0xFFFFFFE0) {
                    colorPreview.setTextColor(0xFF334155);
                } else {
                    colorPreview.setTextColor(0xFFFFFFFF);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        addLabel(card, "Taille");
        EditText sizeInput = styledInput("Ex: 38 / XL");
        card.addView(sizeInput);

        addLabel(card, "Code-barres");
        EditText codeInput = styledInput("Ex: ZTS00000099");
        card.addView(codeInput);

        addLabel(card, "Image du variant");
        EditText imageInput = styledInput("URL complète ou chemin image du serveur");
        card.addView(imageInput);
        addHint(card, "Exemple : uploads/services/mon-image.jpg ou https://votresite/image.jpg");

        LinearLayout priceRow = new LinearLayout(this);
        priceRow.setOrientation(LinearLayout.HORIZONTAL);
        priceRow.setGravity(Gravity.CENTER_VERTICAL);
        priceRow.setPadding(0, dp(4), 0, 0);

        LinearLayout priceWrap = verticalField("Prix spécifique");
        EditText priceInput = styledInput("Vide = prix produit");
        priceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        priceWrap.addView(priceInput);

        LinearLayout qtyWrap = verticalField("Stock initial");
        EditText qtyInput = styledInput("0");
        qtyInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        qtyInput.setText("0");
        qtyWrap.addView(qtyInput);

        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp1.setMarginEnd(dp(6));
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp2.setMarginStart(dp(6));
        priceRow.addView(priceWrap, lp1);
        priceRow.addView(qtyWrap, lp2);
        card.addView(priceRow);

        final TextView helper = new TextView(this);
        helper.setTextColor(0xFF64748B);
        helper.setTextSize(12);
        helper.setPadding(0, dp(12), 0, 0);
        if (!products.isEmpty()) helper.setText("Prix par défaut du produit : " + money(products.get(0).price) + " Ar");
        else helper.setText("Aucun produit disponible dans SQLite.");
        card.addView(helper);

        productSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Object selectedItem = productSpinner.getSelectedItem();
                if (selectedItem instanceof ProductOption) {
                    ProductOption p = (ProductOption) selectedItem;
                    helper.setText("Prix par défaut du produit : " + money(p.price) + " Ar");
                    if (imageInput.getText().toString().trim().isEmpty() && p.imageUrl != null && !p.imageUrl.trim().isEmpty()) {
                        imageInput.setHint("Image produit : " + p.imageUrl);
                    }
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {
                helper.setText("Aucun produit correspondant à la recherche.");
            }
        });

        productSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String term = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                filteredProducts.clear();

                for (ProductOption p : products) {
                    String productName = p.name == null ? "" : p.name.toLowerCase(Locale.ROOT);
                    if (term.isEmpty() || productName.contains(term)) {
                        filteredProducts.add(p);
                    }
                }

                productAdapter.notifyDataSetChanged();

                if (filteredProducts.isEmpty()) {
                    helper.setText("Aucun produit correspondant à « " + s + " ».");
                } else {
                    productSpinner.setSelection(0);
                    ProductOption first = filteredProducts.get(0);
                    helper.setText("Prix par défaut du produit : " + money(first.price) + " Ar");
                }
            }

            @Override public void afterTextChanged(Editable s) {}
        });

        AlertDialog dialog = new DialogUi.Builder(this)
                .setTitle("Variant")
                .setView(dialogContainer(card))
                .setPositiveButton("Créer", (d, w) -> {
                    if (products.isEmpty()) {
                        Toast.makeText(this, "Aucun produit disponible", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        Object selectedItem = productSpinner.getSelectedItem();
                        if (!(selectedItem instanceof ProductOption)) {
                            Toast.makeText(this, "Recherchez puis sélectionnez un produit", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        ProductOption p = (ProductOption) selectedItem;
                        double price = priceInput.getText().toString().trim().isEmpty() ? p.price : num(priceInput);
                        double initialQty = qtyInput.getText().toString().trim().isEmpty() ? 0 : num(qtyInput);
                        ColorOption selectedColor = colors.get(colorSpinner.getSelectedItemPosition());
                        String colorName = selectedColor.custom
                                ? customColorInput.getText().toString().trim()
                                : selectedColor.name;
                        db.createVariant(p.id,
                                colorName,
                                sizeInput.getText().toString(),
                                codeInput.getText().toString(),
                                price,
                                initialQty,
                                currentEmplacementId(),
                                imageInput.getText().toString());
                        load();
                        Toast.makeText(this, "Variant créé dans SQLite", Toast.LENGTH_SHORT).show();
                        if ("ONLINE".equals(AppPrefs.mode(this))) startActivity(new Intent(this, SyncActivity.class));
                    } catch (Exception ex) {
                        Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Annuler", null)
                .create();
        dialog.show();
        DialogUi.style(dialog);
    }

    private ScrollView dialogContainer(LinearLayout content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(dp(4), dp(4), dp(4), dp(4));
        scroll.addView(content);
        return scroll;
    }

    private LinearLayout dialogCard() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(8));
        box.setBackgroundResource(R.drawable.bg_card);
        return box;
    }

    private LinearLayout verticalField(String label) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        addLabel(wrap, label);
        return wrap;
    }

    private void addSectionTitle(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(18);
        t.setTextColor(0xFF2F2B33);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, 0, 0, dp(6));
        parent.addView(t);
    }

    private void addHint(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(12);
        t.setTextColor(0xFF64748B);
        t.setPadding(0, 0, 0, dp(10));
        parent.addView(t);
    }

    private void addLabel(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(0xFF714B67);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(2), 0, dp(6));
        parent.addView(t);
    }

    private EditText styledInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setMinHeight(dp(48));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        e.setLayoutParams(lp);
        return e;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        return lp;
    }

    private ArrayList<ColorOption> defaultColors() {
        ArrayList<ColorOption> out = new ArrayList<>();
        out.add(new ColorOption("Bleu", 0xFF2196F3));
        out.add(new ColorOption("Noir", 0xFF212121));
        out.add(new ColorOption("Blanc", 0xFFFFFFFF));
        out.add(new ColorOption("Blanc cassé", 0xFFFFFFF0));
        out.add(new ColorOption("Gris", 0xFF808080));
        out.add(new ColorOption("Marron", 0xFF795548));
        out.add(new ColorOption("Rose", 0xFFE91E63));
        out.add(new ColorOption("Rouge", 0xFFF44336));
        out.add(new ColorOption("Vert", 0xFF4CAF50));
        out.add(new ColorOption("Jaune", 0xFFFFD600));
        out.add(new ColorOption("Orange", 0xFFFF9800));
        out.add(new ColorOption("Violet", 0xFF9C27B0));
        out.add(new ColorOption("Fuchsia", 0xFFFF00FF));
        out.add(new ColorOption("Beige", 0xFFF5F5DC));
        out.add(new ColorOption("Bordeaux", 0xFF800020));
        out.add(new ColorOption("Marine", 0xFF000080));
        out.add(new ColorOption("Kaki", 0xFF808000));
        out.add(new ColorOption("Crème", 0xFFFFFDD0));
        out.add(ColorOption.custom());
        return out;
    }

    int dp(int v) { return Math.round(getResources().getDisplayMetrics().density * v); }
    static double num(EditText e){ try { return Double.parseDouble(e.getText().toString().trim().replace(',','.')); } catch(Exception x) { return 0; } }
    static String qty(double v){ return String.format(Locale.FRANCE, "%.1f", v); }
    static String money(double v){ return String.format(Locale.FRANCE, "%,.0f", v); }

    static class Row {
        long variantId, productId; String product, couleur, taille, code; double price, stock;
        String display() {
            String d = product;
            if (couleur != null && !couleur.isEmpty()) d += " • " + couleur;
            if (taille != null && !taille.isEmpty()) d += " • T." + taille;
            return d;
        }
    }
    static class ProductOption {
        long id; String name; double price; String imageUrl;
        @Override public String toString() { return name; }
    }

    static class ColorOption {
        String name;
        int argb;
        boolean custom;
        ColorOption(String name, int argb) { this.name = name; this.argb = argb; }
        static ColorOption custom() {
            ColorOption c = new ColorOption("Autre couleur…", 0xFF714B67);
            c.custom = true;
            return c;
        }
        @Override public String toString() { return name; }
    }
}
