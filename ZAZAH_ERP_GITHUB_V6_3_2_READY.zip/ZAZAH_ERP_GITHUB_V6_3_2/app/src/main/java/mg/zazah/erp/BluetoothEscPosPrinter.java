package mg.zazah.erp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.Normalizer;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class BluetoothEscPosPrinter {
    public static final int LABEL_BARCODE = 1;
    public static final int LABEL_QR = 2;
    public static final int LABEL_BOTH = 3;
    public static final int LABEL_QR_40X30 = 4;
    public static final int LABEL_QR_60X40 = 5;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final Charset CHARSET = Charset.forName("windows-1252");

    public interface Callback {
        void onSuccess();
        void onError(String message);
    }

    public static boolean hasConnectPermission(Context c) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                ContextCompat.checkSelfPermission(c, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    public static void printSale(Context context, JSONObject receipt, JSONArray lines, String clientName, Callback callback) {
        if (Sc03BlePrinter.isSc03(context)) {
            Sc03BlePrinter.printSale(context, receipt, lines, clientName, callback);
            return;
        }
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                String address = AppPrefs.printerAddress(context);
                if (address == null || address.trim().isEmpty()) {
                    throw new Exception("Aucune imprimante ticket configurée");
                }
                if (!hasConnectPermission(context)) {
                    throw new Exception("Autorisation Bluetooth manquante. Ouvrez Paramètres > imprimante ticket.");
                }

                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new Exception("Bluetooth non disponible sur cet appareil");
                if (!adapter.isEnabled()) throw new Exception("Activez le Bluetooth");

                BluetoothDevice device = findBonded(adapter, address);
                if (device == null) throw new Exception("Imprimante Bluetooth non appairée");

                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                socket.connect();
                OutputStream out = socket.getOutputStream();

                int width = AppPrefs.paperWidth(context);
                int cols = width == 80 ? 48 : 32;

                // Identité et message du ticket : dernier paramétrage reçu depuis l'ERP en ligne.
                DatabaseHelper localDb = new DatabaseHelper(context.getApplicationContext());
                String companyName = localDb.setting("ticket_company_name", "ZAZAH TSENA SABOTSY").trim();
                String companyAddress = localDb.setting("ticket_company_address", "").trim();
                String companyPhone = localDb.setting("ticket_company_phone", "").trim();
                String ticketMessage = localDb.setting("ticket_message", "Merci pour votre achat !").trim();
                localDb.close();
                if (companyName.isEmpty()) companyName = "ZAZAH TSENA SABOTSY";

                // Ticket caisse ESC/POS adapte automatiquement au papier 58/80 mm.
                out.write(new byte[]{0x1B, 0x40});
                out.write(new byte[]{0x1B, 0x74, 0x10});

                center(out);
                bold(out, true);
                for (String row : wrap(companyName, cols)) write(out, row + "\n");
                bold(out, false);
                write(out, "Gestion Commerciale\n");
                if (!companyAddress.isEmpty()) {
                    for (String row : wrap(companyAddress, cols)) write(out, row + "\n");
                }
                if (!companyPhone.isEmpty()) {
                    for (String row : wrap("Tel : " + companyPhone, cols)) write(out, row + "\n");
                }
                write(out, repeat('-', cols) + "\n");
                bold(out, true);
                doubleSize(out, true);
                write(out, "TICKET DE CAISSE\n");
                doubleSize(out, false);
                bold(out, false);
                write(out, repeat('=', cols) + "\n");

                left(out);
                write(out, fitLine("N° " + receipt.optString("num_vente", ""), cols) + "\n");
                write(out, fitLine("Date " + receipt.optString("date_vente", ""), cols) + "\n");
                if (clientName != null && !clientName.trim().isEmpty()) {
                    for (String row : wrap("Client : " + clientName.trim(), cols)) write(out, row + "\n");
                }

                write(out, repeat('-', cols) + "\n");
                bold(out, true);
                write(out, "ARTICLES\n");
                bold(out, false);
                write(out, repeat('-', cols) + "\n");

                // V5.25.27 : pour les composants d'un pack, le ticket montre
                // le prix global du pack une seule fois, puis uniquement les quantités.
                LinkedHashMap<String, Double> packTotals = new LinkedHashMap<>();
                for (int i = 0; i < lines.length(); i++) {
                    JSONObject l = lines.getJSONObject(i);
                    String des = l.optString("designation", "Produit");
                    int sep = des.indexOf(" • ");
                    if (sep > 0) {
                        String packName = des.substring(0, sep).trim();
                        if (packName.toLowerCase(Locale.ROOT).startsWith("pack")) {
                            double qty = l.optDouble("quantite", 0);
                            double price = l.optDouble("prix", 0);
                            double total = l.has("total_ligne") ? l.optDouble("total_ligne", qty * price) : qty * price;
                            packTotals.put(packName, packTotals.containsKey(packName)
                                    ? packTotals.get(packName) + total : total);
                        }
                    }
                }
                HashSet<String> printedPacks = new HashSet<>();

                for (int i = 0; i < lines.length(); i++) {
                    JSONObject l = lines.getJSONObject(i);
                    String des = l.optString("designation", "Produit");
                    double qty = l.optDouble("quantite", 0);
                    double price = l.optDouble("prix", 0);
                    double total = l.has("total_ligne") ? l.optDouble("total_ligne", qty * price) : qty * price;

                    int sep = des.indexOf(" • ");
                    String packName = sep > 0 ? des.substring(0, sep).trim() : "";
                    boolean isPack = sep > 0 && packName.toLowerCase(Locale.ROOT).startsWith("pack");

                    if (isPack) {
                        String component = des.substring(sep + 3).trim();
                        if (!printedPacks.contains(packName)) {
                            printedPacks.add(packName);
                            bold(out, true);
                            write(out, twoCols(packName, money(packTotals.get(packName)) + " Ar", cols) + "\n");
                            bold(out, false);
                        }
                        write(out, twoCols("  " + component, "Qte " + fmtQty(qty), cols) + "\n");
                    } else {
                        bold(out, true);
                        for (String row : wrap(des, cols)) write(out, row + "\n");
                        bold(out, false);

                        String detail = fmtQty(qty) + " x " + money(price) + " Ar";
                        String lineTotal = money(total) + " Ar";
                        write(out, twoCols(detail, lineTotal, cols) + "\n");
                    }
                    if (i < lines.length() - 1) write(out, dotted(cols) + "\n");
                }

                write(out, repeat('-', cols) + "\n");
                double subtotal = receipt.optDouble("sous_total", 0);
                double remise = receipt.optDouble("remise", 0);
                double tva = receipt.optDouble("montant_tva", 0);
                double livraison = receipt.optDouble("frais_livraison", 0);
                double grandTotal = receipt.optDouble("montant_total", 0);

                write(out, twoCols("Sous-total", money(subtotal) + " Ar", cols) + "\n");
                if (remise > 0) write(out, twoCols("Remise", "-" + money(remise) + " Ar", cols) + "\n");
                if (tva > 0) write(out, twoCols("TVA", money(tva) + " Ar", cols) + "\n");
                if (livraison > 0) write(out, twoCols("Livraison", money(livraison) + " Ar", cols) + "\n");

                write(out, repeat('=', cols) + "\n");
                center(out);
                bold(out, true);
                doubleSize(out, true);
                write(out, "TOTAL\n");
                write(out, money(grandTotal) + " Ar\n");
                doubleSize(out, false);
                bold(out, false);
                write(out, repeat('=', cols) + "\n");

                left(out);
                String payment = receipt.optString("mode_paiement", "").trim();
                if (!payment.isEmpty()) write(out, twoCols("Paiement", payment, cols) + "\n");

                String note = receipt.optString("commentaire", "").trim();
                if (!note.isEmpty()) {
                    left(out);
                    write(out, "\n" + repeat('-', cols) + "\n");
                    for (String row : wrap("Note : " + note, cols)) write(out, row + "\n");
                }

                center(out);
                write(out, "\n" + repeat('-', cols) + "\n");
                if (!ticketMessage.isEmpty()) {
                    bold(out, true);
                    String normalizedMessage = ticketMessage.replace("\r\n", "\n").replace('\r', '\n');
                    String[] messageLines = normalizedMessage.split("\n", -1);
                    for (String messageLine : messageLines) {
                        if (messageLine.trim().isEmpty()) {
                            write(out, "\n");
                        } else {
                            for (String row : wrap(messageLine, cols)) write(out, row + "\n");
                        }
                    }
                    bold(out, false);
                }
                write(out, "\n" + companyName + "\n\n\n");

                // Coupe papier si l'imprimante la prend en charge.
                out.write(new byte[]{0x1D, 0x56, 0x41, 0x10});
                out.flush();
                try { Thread.sleep(350); } catch (InterruptedException ignored) {}

                if (callback != null) callback.onSuccess();
            } catch (Exception e) {
                if (callback != null) callback.onError(e.getMessage() == null ? "Erreur impression" : e.getMessage());
            } finally {
                if (socket != null) try { socket.close(); } catch (Exception ignored) {}
            }
        }).start();
    }


    /**
     * V5.25.46 - Impression d'étiquette produit depuis SQLite.
     * Une étiquette contient le nom, la variante et le prix. V5.25.47 permet
     * de choisir un code-barres Code 128 OU un QR code avant impression.
     *
     * Les commandes sont des commandes ESC/POS natives : aucune librairie
     * externe n'est nécessaire et le format suit la largeur 58/80 mm déjà
     * configurée dans les paramètres de l'application.
     */
    public static void printLabel(Context context, String productName, String variantText,
                                  String code, double price, long variantId, int copies,
                                  Callback callback) {
        printLabel(context, productName, variantText, code, price, variantId, copies, LABEL_BOTH, callback);
    }

    /** V5.25.47 : impression sélective Barcode OU QR code. */
    public static void printLabel(Context context, String productName, String variantText,
                                  String code, double price, long variantId, int copies,
                                  int labelCodeType, Callback callback) {
        if (Sc03BlePrinter.isSc03(context)) {
            Sc03BlePrinter.printLabel(context, productName, variantText, code, price, variantId, copies, labelCodeType, callback);
            return;
        }
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                String address = AppPrefs.printerAddress(context);
                if (address == null || address.trim().isEmpty()) {
                    throw new Exception("Aucune imprimante Bluetooth configurée");
                }
                if (!hasConnectPermission(context)) {
                    throw new Exception("Autorisation Bluetooth manquante. Ouvrez Paramètres > imprimante ticket.");
                }

                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new Exception("Bluetooth non disponible sur cet appareil");
                if (!adapter.isEnabled()) throw new Exception("Activez le Bluetooth");

                BluetoothDevice device = findBonded(adapter, address);
                if (device == null) throw new Exception("Imprimante Bluetooth non appairée");

                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                socket.connect();
                OutputStream out = socket.getOutputStream();

                int width = AppPrefs.paperWidth(context);
                int cols = width == 80 ? 48 : 32;
                int safeCopies = Math.max(1, Math.min(50, copies));

                String product = safe(productName).trim();
                if (product.isEmpty()) product = "Produit";

                String variant = safe(variantText).trim();
                String barcode = barcodeData(code, variantId);

                DatabaseHelper localDb = new DatabaseHelper(context.getApplicationContext());
                String companyName = localDb.setting("ticket_company_name", "ZAZAH TSENA SABOTSY").trim();
                localDb.close();
                if (companyName.isEmpty()) companyName = "ZAZAH TSENA SABOTSY";

                String qrPayload =
                        "ZAZAH|variant=" + variantId +
                        "|code=" + barcode +
                        "|produit=" + product +
                        (variant.isEmpty() ? "" : "|variante=" + variant) +
                        "|prix=" + String.format(Locale.US, "%.0f", Math.max(0, price));

                for (int copy = 0; copy < safeCopies; copy++) {
                    out.write(new byte[]{0x1B, 0x40});
                    out.write(new byte[]{0x1B, 0x74, 0x10});
                    center(out);

                    bold(out, true);
                    for (String row : wrap(product, cols)) write(out, row + "\n");
                    bold(out, false);

                    if (!variant.isEmpty()) {
                        for (String row : wrap(variant, cols)) write(out, row + "\n");
                    }

                    if (price > 0) {
                        doubleSize(out, true);
                        bold(out, true);
                        write(out, money(price) + " Ar\n");
                        bold(out, false);
                        doubleSize(out, false);
                    }

                    write(out, "\n");

                    boolean printBarcode = labelCodeType == LABEL_BARCODE || labelCodeType == LABEL_BOTH;
                    boolean printQrCode = labelCodeType == LABEL_QR || labelCodeType == LABEL_QR_40X30 || labelCodeType == LABEL_QR_60X40 || labelCodeType == LABEL_BOTH;
                    if (!printBarcode && !printQrCode) printBarcode = true;

                    if (printBarcode) {
                        printCode128(out, barcode, width == 80 ? 86 : 72, width == 80 ? 3 : 2);
                        write(out, barcode + "\n");
                    }

                    if (printQrCode) {
                        printQr(out, qrPayload, width == 80 ? 6 : 5);
                        write(out, barcode + "\n");
                    }

                    write(out, "\n");
                    bold(out, true);
                    for (String row : wrap(companyName, cols)) write(out, row + "\n");
                    bold(out, false);

                    if (copy < safeCopies - 1) {
                        write(out, "\n" + repeat('-', cols) + "\n\n");
                    }
                }

                // Avance du papier puis coupe si l'imprimante la prend en charge.
                out.write(new byte[]{0x1B, 0x64, 0x03});
                out.write(new byte[]{0x1D, 0x56, 0x41, 0x10});
                out.flush();
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}

                if (callback != null) callback.onSuccess();
            } catch (Exception e) {
                if (callback != null) {
                    callback.onError(e.getMessage() == null ? "Erreur impression étiquette" : e.getMessage());
                }
            } finally {
                if (socket != null) try { socket.close(); } catch (Exception ignored) {}
            }
        }).start();
    }

    private static String barcodeData(String source, long variantId) {
        String data = source == null ? "" : source.trim();
        if (data.isEmpty()) {
            data = "ZTS" + String.format(Locale.US, "%08d", Math.abs(variantId) % 100000000L);
        }

        StringBuilder out = new StringBuilder();
        for (int i = 0; i < data.length(); i++) {
            char c = data.charAt(i);
            if (c >= 32 && c <= 126 && c != '{') out.append(c);
        }
        if (out.length() == 0) {
            out.append("ZTS").append(String.format(Locale.US, "%08d", Math.abs(variantId) % 100000000L));
        }
        if (out.length() > 36) out.setLength(36);
        return out.toString();
    }

    /**
     * Code 128 - jeu B. Fonctionne avec la majorité des imprimantes ESC/POS.
     */
    private static void printCode128(OutputStream out, String code, int height, int moduleWidth) throws Exception {
        String value = barcodeData(code, 0);
        byte[] raw = ("{B" + value).getBytes(Charset.forName("US-ASCII"));

        // HRI sous le code-barres, hauteur et largeur du module.
        out.write(new byte[]{0x1D, 0x48, 0x02});
        out.write(new byte[]{0x1D, 0x68, (byte)Math.max(40, Math.min(120, height))});
        out.write(new byte[]{0x1D, 0x77, (byte)Math.max(2, Math.min(4, moduleWidth))});

        // GS k m n d... : m=73 => Code 128, longueur explicite.
        out.write(new byte[]{0x1D, 0x6B, 0x49, (byte)raw.length});
        out.write(raw);
        out.write('\n');
    }

    /**
     * QR code ESC/POS natif (modèle 2).
     */
    private static void printQr(OutputStream out, String value, int moduleSize) throws Exception {
        byte[] data = safeQr(value).getBytes(Charset.forName("UTF-8"));

        // Sélection modèle 2.
        out.write(new byte[]{0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00});
        // Taille module 1..16.
        out.write(new byte[]{0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43,
                (byte)Math.max(1, Math.min(16, moduleSize))});
        // Correction M.
        out.write(new byte[]{0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x31});

        int storeLength = data.length + 3;
        int pL = storeLength & 0xFF;
        int pH = (storeLength >> 8) & 0xFF;

        out.write(new byte[]{0x1D, 0x28, 0x6B, (byte)pL, (byte)pH, 0x31, 0x50, 0x30});
        out.write(data);

        // Impression du symbole mémorisé.
        out.write(new byte[]{0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30});
        out.write('\n');
    }

    private static String safeQr(String value) {
        if (value == null) return "";
        String v = value.replace('\r', ' ').replace('\n', ' ').trim();
        return v.length() > 220 ? v.substring(0, 220) : v;
    }

    private static BluetoothDevice findBonded(BluetoothAdapter adapter, String address) {
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null) return null;
        for (BluetoothDevice d : bonded) {
            if (address.equalsIgnoreCase(d.getAddress())) return d;
        }
        return null;
    }

    private static void write(OutputStream out, String text) throws Exception {
        out.write(safe(text).getBytes(CHARSET));
    }

    private static String safe(String s) {
        if (s == null) return "";
        // Keep common Latin chars but remove characters unsupported by cheap ESC/POS printers.
        String normalized = Normalizer.normalize(s, Normalizer.Form.NFKD)
                .replaceAll("\\p{M}+", "");
        return normalized.replace('’', '\'').replace('–', '-').replace('—', '-').replace('•', '-');
    }

    private static void left(OutputStream out) throws Exception { out.write(new byte[]{0x1B, 0x61, 0x00}); }
    private static void center(OutputStream out) throws Exception { out.write(new byte[]{0x1B, 0x61, 0x01}); }
    private static void bold(OutputStream out, boolean on) throws Exception { out.write(new byte[]{0x1B, 0x45, (byte)(on ? 1 : 0)}); }
    private static void doubleSize(OutputStream out, boolean on) throws Exception { out.write(new byte[]{0x1D, 0x21, (byte)(on ? 0x11 : 0x00)}); }

    private static String repeat(char c, int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) b.append(c);
        return b.toString();
    }

    private static String dotted(int cols) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cols; i++) b.append(i % 2 == 0 ? '.' : ' ');
        return b.toString();
    }

    private static String fitLine(String text, int cols) {
        text = safe(text).trim();
        return text.length() <= cols ? text : text.substring(0, Math.max(0, cols));
    }

    private static String twoCols(String a, String b, int cols) {
        a = safe(a); b = safe(b);
        if (a.length() + b.length() + 1 > cols) {
            int leftMax = Math.max(6, cols - b.length() - 1);
            if (a.length() > leftMax) a = a.substring(0, leftMax);
        }
        int spaces = Math.max(1, cols - a.length() - b.length());
        return a + repeat(' ', spaces) + b;
    }

    private static String[] wrap(String text, int cols) {
        text = safe(text).trim();
        if (text.length() <= cols) return new String[]{text};
        java.util.ArrayList<String> rows = new java.util.ArrayList<>();
        while (!text.isEmpty()) {
            int end = Math.min(cols, text.length());
            if (end < text.length()) {
                int space = text.lastIndexOf(' ', end);
                if (space > cols / 2) end = space;
            }
            rows.add(text.substring(0, end).trim());
            text = text.substring(end).trim();
        }
        return rows.toArray(new String[0]);
    }

    private static String money(double v) {
        // Espaces ASCII : plus fiables sur les petites imprimantes ESC/POS.
        return String.format(Locale.US, "%,.0f", v).replace(',', ' ');
    }

    private static String fmtQty(double v) {
        if (Math.abs(v - Math.rint(v)) < 0.000001) return String.format(Locale.US, "%.0f", v);
        String q = String.format(Locale.US, "%.2f", v);
        while (q.endsWith("0")) q = q.substring(0, q.length() - 1);
        if (q.endsWith(".")) q = q.substring(0, q.length() - 1);
        return q.replace('.', ',');
    }

    private BluetoothEscPosPrinter() {}
}
