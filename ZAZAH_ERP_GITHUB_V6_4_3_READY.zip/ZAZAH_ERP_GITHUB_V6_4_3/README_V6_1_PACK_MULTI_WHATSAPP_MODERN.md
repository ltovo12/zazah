# ZAZAH ERP Android SQLite — V6.1 Pack multi-produits + WhatsApp moderne

Cette version conserve la V6.0 (PIN téléphone et connexion automatique) et ajoute :

- un article de pack peut contenir plusieurs produits / variantes ;
- sélection multi-produits avec recherche dans le catalogue SQLite ;
- quantité appliquée à chaque produit du groupe ;
- déduction de stock conservée variante par variante dans le POS ;
- synchronisation MySQL ↔ SQLite du `groupe_code` ;
- anciens packs compatibles : une ancienne ligne devient automatiquement un groupe à un produit ;
- image marketing modernisée avec regroupement des produits par article ;
- bouton WhatsApp direct dans l’aperçu image (WhatsApp puis WhatsApp Business, sinon menu de partage) ;
- base SQLite version 18 ;
- application versionCode 83 / versionName 6.1-pack-multi-whatsapp-modern.

## Important côté serveur
Installer aussi la version en ligne fournie avec cette livraison. Elle migre automatiquement `pack_articles` en ajoutant `groupe_code` et synchronise ce champ avec l’application.
