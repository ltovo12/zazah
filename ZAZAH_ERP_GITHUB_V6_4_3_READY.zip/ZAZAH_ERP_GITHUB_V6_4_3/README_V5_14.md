V5.14
- correction boutons sans label dans Parametres et Historique POS
- texte boutons force en blanc
- backgroundTint neutralise pour garder le bon style
