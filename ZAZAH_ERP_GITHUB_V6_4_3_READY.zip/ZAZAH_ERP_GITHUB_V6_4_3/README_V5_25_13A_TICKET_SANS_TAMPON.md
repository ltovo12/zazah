# ZAZAH ERP Android SQLite V5.25.13A — Ticket POS sans tampon

- Conserve le format ticket POS professionnel 58 mm / 80 mm.
- Supprime complètement le bloc/tampon de statut `PAYE`, `PARTIEL` ou `EN ATTENTE` du ticket imprimé.
- Conserve le mode de paiement, les articles, sous-total, remise, TVA, livraison, total et message de fin.
- Aucun changement de base de données ni de serveur nécessaire.
