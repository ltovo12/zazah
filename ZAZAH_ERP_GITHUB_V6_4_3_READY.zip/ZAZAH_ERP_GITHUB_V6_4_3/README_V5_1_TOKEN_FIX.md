# ZAZAH ERP Android SQLite V5.1 — correction TOKEN invalide

Cette version est basée sur la V5 construite directement depuis la V4 OdooStyle_SQLFix qui fonctionne.

## Correction
- l'ancien token sauvegardé par Android n'est plus utilisé ;
- le token de synchronisation V5.1 est embarqué dans l'application ;
- `config_mobile.php` du dossier `server_patch/admin/mobile_api/` contient exactement le même token ;
- `versionCode = 6` pour permettre l'installation comme mise à jour de V5/V4 ;
- `versionName = 5.1-odoo-grand-pos-token-fix`.

## Mise à jour serveur OBLIGATOIRE
Sur InfinityFree, dans :

`/zazah/admin/mobile_api/`

remplacer au minimum :

`config_mobile.php`

par celui fourni dans :

`server_patch/admin/mobile_api/config_mobile.php`

Vous pouvez aussi recopier tout le dossier `server_patch/admin/mobile_api/` pour avoir les fichiers synchronisation cohérents.

## Important
Ne supprimez pas les ventes SQLite : elles restent en attente jusqu'à ce que le serveur accepte la synchronisation.
