# Mise à jour V5.25.20 — Recherche comme facture + liaison stock fiabilisée

Cette version aligne la gestion des packs entre Android SQLite et la version en ligne.

## Android
- Le sélecteur stock reste sous forme de fenêtre de recherche avec résultats cliquables.
- Recherche par produit, couleur, taille et code-barres.
- Les articles à stock 0 restent sélectionnables.
- Après sélection, l’ID de variante est conservé lors de l’enregistrement et le compteur lié au stock est recalculé.
- Toutes les fonctions V5.25.19 sont conservées.

Version Android : **5.25.20-recherche-facture-liaison-fix** (versionCode 51).

## V5.25.33
Ajout des modules **Utilisateurs** et **Session**. La base SQLite migre automatiquement vers la version 15. Ne désinstallez pas l'application si vous souhaitez conserver les données locales existantes.
