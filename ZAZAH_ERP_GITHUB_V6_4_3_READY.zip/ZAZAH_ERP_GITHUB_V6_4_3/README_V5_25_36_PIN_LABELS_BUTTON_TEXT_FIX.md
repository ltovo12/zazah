# V5.25.36 — PIN : noms visibles + bouton Menu visible

Corrections :
- les noms des utilisateurs dans « Configurer le PIN » sont maintenant forcés en texte sombre et gras ;
- les menus d’actions basés sur `AlertDialog.setItems()` reçoivent le même correctif de contraste ;
- le bouton « Menu principal » de l’écran Utilisateurs est forcé avec un fond clair et un texte violet visible ;
- suppression des emoji dans les boutons critiques pour éviter les rendus vides sur certains téléphones/ROM ;
- la logique PIN reste inchangée : PIN local SQLite, 4 à 8 chiffres, demandé à l’ouverture de session.
