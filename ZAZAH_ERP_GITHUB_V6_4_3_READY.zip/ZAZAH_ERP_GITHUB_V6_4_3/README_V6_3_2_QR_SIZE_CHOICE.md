# ZAZAH ERP Android SQLite V6.3.2

## Changements
- ajout du choix de format d'étiquette QR avant impression
- 2 formats disponibles : 40x30 mm et 60x40 mm
- le format barcode classique est conservé
- sur imprimante SC03h : rendu spécifique selon le format choisi
- sur autres imprimantes Bluetooth : QR standard conservé

## Choix disponibles
- Code-barres (Barcode / Code 128)
- QR code 40×30 avec texte
- QR code 60×40 avec texte

## Version
- versionCode : 105
- versionName : 6.3.2-qr-size-choice

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/BluetoothEscPosPrinter.java
- app/src/main/java/mg/zazah/erp/LabelPrintActivity.java
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
