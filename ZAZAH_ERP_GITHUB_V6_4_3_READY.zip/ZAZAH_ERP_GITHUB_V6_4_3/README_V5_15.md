V5.15
- nouveau variant : champ image URL/chemin
- mobile_variant_ops synchronise image_url
- popup stock et nouveau variant plus moderne
