V5.20
- panier POS sur une seule ligne par article
- protection retour/fermeture accidentelle avec Rester / Mettre en attente et quitter / Quitter sans sauvegarder
- base V5.19 conservee
