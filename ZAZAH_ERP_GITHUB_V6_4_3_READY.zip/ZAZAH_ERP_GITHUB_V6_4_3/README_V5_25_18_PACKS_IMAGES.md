# ZAZAH ERP Android SQLite V5.25.18 — Packs + images

Cette version part de V5.25.16 Packs Nouveau-né et ajoute la génération locale des visuels après création/modification du pack.

## Nouveau
- Pack créé puis composition ajoutée article par article.
- Champs marketing : slogan + catégorie.
- 3 formats générés depuis les données SQLite :
  - Affiche marketing 1080 × 1350
  - Carré WhatsApp / Facebook 1080 × 1080
  - Mini fiche 1200 × 800
- Aperçu immédiat avant enregistrement.
- Enregistrement PNG dans `Pictures/ZAZAH` sur Android 10+.
- Partage Android direct de l'image générée.
- Aucun service IA, aucune clé API et aucune connexion Internet ne sont requis pour créer ces visuels.
- Après modification des articles, retoucher le bouton du format régénère l'image avec la nouvelle composition.

## Base SQLite
Migration automatique V12 -> V13 :
- `packs.slogan`
- `packs.categorie`

Les anciennes données et compositions sont conservées.

## Utilisation
1. Menu `Packs Nouveau-né`.
2. Créer/modifier le pack puis enregistrer.
3. Ajouter les articles (quantité 0,5 acceptée).
4. Ouvrir le pack.
5. Choisir `Affiche`, `Carré` ou `Mini fiche`.
6. Prévisualiser puis `Enregistrer` ou `Partager`.
