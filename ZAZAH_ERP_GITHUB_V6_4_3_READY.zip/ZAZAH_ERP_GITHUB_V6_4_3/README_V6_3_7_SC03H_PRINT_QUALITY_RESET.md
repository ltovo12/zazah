# ZAZAH ERP Android SQLite V6.3.7

## SC03h - stabilité de qualité d'impression
- Réinitialisation complète avant chaque impression.
- Réapplication de la densité juste avant l'impression.
- Réaffirmation de la densité toutes les 96 lignes sur les impressions longues.
- Pause de stabilisation thermique contrôlée.
- Double reset de fin d'impression.
- Conservation des réglages d'avance papier et de toutes les corrections V6.3.6.

## Version
- versionCode : 110
- versionName : 6.3.7-sc03h-print-quality-reset

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
