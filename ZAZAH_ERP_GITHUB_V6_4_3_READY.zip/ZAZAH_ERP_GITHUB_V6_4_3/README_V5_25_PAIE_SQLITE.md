# ZAZAH ERP Android SQLite V5.25 — Paie SQLite

Base : V5.24.

## Ajouts
- Module **Paie / Salariés / Avances** accessible depuis le tableau de bord.
- Table SQLite `salaries` : matricule, nom, téléphone, email, adresse, salaire de base, allocation repas/jour, jours repas par défaut, actif/inactif.
- Table SQLite `avances` : salarié, date, montant, remarque.
- Table SQLite `paies` : mois, période, base, jours, repas, avances, net à payer.
- Table SQLite `paie_paiements` : paiements partiels séparés du net calculé.
- Statuts calculés : **EN ATTENTE / PARTIEL / PAYÉ**.
- Générer une paie, générer toutes les paies, recalculer le mois.
- Paiement : espèces, MVola, Orange Money, Airtel Money, virement, autre + référence/remarque.
- Historique des paiements.

## Règle de calcul
`Net à payer = salaire de base + allocation repas totale - avances de la période`

Les paiements ne modifient jamais le Net à payer : ils augmentent seulement le montant déjà payé et diminuent le reste.

## Migration
La base passe de version SQLite 6 à 7. Les nouvelles tables sont créées automatiquement au premier démarrage sans supprimer les ventes, clients, stock, variantes ou brouillons existants.

## Périodes personnalisées
Lors de **Générer une paie**, la date de début et la date de fin sont modifiables pour chaque salarié. Le recalcul du mois conserve ces dates. Les avances déduites sont uniquement celles comprises dans cette période.

## Important
Cette V5.25 intègre la Paie dans la base SQLite locale. La synchronisation Paie SQLite ↔ MySQL en ligne n'est pas ajoutée à ce paquet ; la synchronisation existante POS/clients/variantes/stock reste inchangée.
