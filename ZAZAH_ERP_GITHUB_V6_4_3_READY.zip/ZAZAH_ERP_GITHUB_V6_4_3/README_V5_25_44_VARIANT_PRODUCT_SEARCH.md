# V5.25.44 — Recherche produit lors de la création d’une variante

## Modification

Dans **Stock > Nouveau variant**, un champ **Rechercher un produit...** est maintenant affiché au-dessus de la sélection du produit.

- La liste des produits est filtrée instantanément pendant la saisie.
- La recherche est insensible aux majuscules/minuscules.
- Le prix par défaut du produit sélectionné est actualisé automatiquement.
- Si aucun produit ne correspond, un message clair est affiché.
- La création de variante utilise l’objet réellement sélectionné dans la liste filtrée afin d’éviter une mauvaise liaison produit/variante.

Version Android : `5.25.44-variant-product-search` — versionCode 75.
