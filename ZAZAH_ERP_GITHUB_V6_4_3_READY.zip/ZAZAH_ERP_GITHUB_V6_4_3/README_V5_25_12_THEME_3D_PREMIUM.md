# ZAZAH ERP Android SQLite V5.25.12 — Thème 3D Premium global

Base fonctionnelle : V5.25.11 Sync Avances.

## Nouveautés visuelles
- Thème global uniforme sur Accueil, POS, Stock, Clients, Paie, Avances, Salariés, Synchronisation, Paramètres et Scanner.
- Cartes et menus avec relief 3D, dégradés, bordures et ombres plus nettes.
- Accueil premium : cartes statistiques et menu principal plus profonds, tout en gardant la disposition existante.
- Boutons principaux violets 3D, validation verte 3D et actions danger rouges 3D.
- Champs et listes déroulantes plus lisibles avec fond clair, bordure renforcée et léger relief.
- Lignes de listes/cartes harmonisées avec le même thème.

## Popups / dialogs
- Fond clair distinct du corps de la page.
- Overlay sombre pour détacher le popup.
- Ombre forte et coins arrondis 3D.
- Animation douce d'ouverture / fermeture.
- Bouton X de fermeture visible sur les dialogs stylés.
- Boutons Annuler / Valider / Danger avec contraste renforcé.
- Inputs des popups forcés en texte foncé sur fond clair.
- Largeur adaptée au mobile, avec limite sur grands écrans.

## Fonctions conservées
- SQLite DB version 11.
- Paie par période propre à chaque salarié.
- Recalcul de paie avec salaire de base actuel.
- Contrainte de paie par période réelle.
- Paiements partiels.
- Synchronisation salariés / paies / avances.
- Push avances local -> serveur de la V5.25.11.
- POS, scanner, ticket Bluetooth et synchronisation existante inchangés côté logique.

## Serveur
Aucune modification serveur supplémentaire n'est nécessaire pour V5.25.12.
Gardez le correctif serveur de la V5.25.11 déjà installé.
