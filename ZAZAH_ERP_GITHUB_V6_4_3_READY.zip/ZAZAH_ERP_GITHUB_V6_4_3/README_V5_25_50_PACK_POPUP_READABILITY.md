# V5.25.50 — Lisibilité popup Packs

Correction des fenêtres **Ajouter un article** / **Modifier l’article** dans Packs Nouveau-né.

- fond du contenu forcé en graphite premium ;
- titres, sous-titres, libellés et aides en texte clair contrasté ;
- champs de saisie sombres avec texte blanc et placeholder gris ;
- correction du fond global `bg_dialog_window` afin d’éviter le texte clair sur fond blanc selon le thème ;
- conservation des boutons, de la recherche/lien stock et de toutes les fonctions précédentes.

Version Android : `5.25.50-pack-popup-readability`  
VersionCode : `81`
