# ZAZAH ERP Android SQLite V6.2.6

## Changements
- QR code d'étiquette agrandi sur format 58 mm
- hauteur d'étiquette QR augmentée pour garder une bonne lisibilité
- texte du code légèrement repositionné

## Version
- versionCode : 99
- versionName : 6.2.6-label-qr-big

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
