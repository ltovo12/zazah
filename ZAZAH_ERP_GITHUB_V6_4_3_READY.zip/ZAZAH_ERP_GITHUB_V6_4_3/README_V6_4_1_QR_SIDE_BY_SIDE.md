# ZAZAH ERP Android SQLite V6.4.1 — QR côte à côte

## Modifications
- QR 40x30 : texte à gauche, QR à droite
- QR 60x40 : texte à gauche, QR à droite
- Base : V6.4.0
- Barcode inchangé
- 1 seule avance papier de fin conservée
