# ZAZAH ERP Android SQLite V6.2.7

## POS
- compteur du nombre d’articles affiché à droite du titre PANIER
- mise à jour automatique à chaque ajout, suppression ou vidage du panier
- format : `1 article`, `2 articles`, etc.

## Version
- versionCode : 100
- versionName : 6.2.7-pos-cart-count
