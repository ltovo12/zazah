# V5.25.35 — PIN utilisateur + boutons lisibles

Corrections :
- Nouveau bouton visible **🔐 Configurer / changer le PIN** dans la page Utilisateurs.
- Choix de l'utilisateur puis saisie + confirmation d'un PIN Android de 4 à 8 chiffres.
- Le PIN reste strictement local dans SQLite et n'est pas envoyé au serveur.
- Le PIN est stocké sous forme SHA-256.
- À l'ouverture/changement de session, le PIN est demandé automatiquement si l'utilisateur est protégé.
- Les actions sur une fiche utilisateur proposent maintenant **Définir le PIN / Changer le PIN / Supprimer le PIN**.
- Correction du bouton **‹ Menu principal** dont le texte pouvait devenir invisible à cause du backgroundTint Material.
- Même correction de contraste/tint sur les boutons Session et Utilisateurs.

Version Android : `5.25.35-pin-ui-visible-buttons` (versionCode 66).
