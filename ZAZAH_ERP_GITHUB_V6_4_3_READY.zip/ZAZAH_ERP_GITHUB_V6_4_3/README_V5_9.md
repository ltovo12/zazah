V5.9
- Nouveau client synchronisé vers MySQL
- Nouveau variant synchronisé vers services_variantes
- Ajout stock synchronisé vers stocks
- File d’attente hors ligne + anti-doublon UUID
- Sync master avant ventes POS
