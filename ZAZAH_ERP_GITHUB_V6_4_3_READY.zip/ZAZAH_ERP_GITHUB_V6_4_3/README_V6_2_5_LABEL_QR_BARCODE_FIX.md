# ZAZAH ERP Android SQLite V6.2.5

Correction du module Étiquettes produits / Barcode / QR code.

## Bug corrigé
La page cherchait la colonne SQLite `stock_total` alors que `searchPackVariants()` renvoie `stock_tsena`.
Cela provoquait :
`Couldn't read row 0, col -1 from CursorWindow`.

## Changements
- lecture correcte de `stock_tsena`
- fallback sur `stock_total` pour compatibilité anciennes requêtes
- validation des index de colonnes avant lecture
- impression Barcode / QR SC03h conservée

## Version
- versionCode 98
- versionName 6.2.5-label-qr-barcode-fix

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/LabelPrintActivity.java`
- `app/build.gradle`
