V5.12
- cartes produits avec image style POS en ligne
- vignette image arrondie
- bouton Voir variantes sur chaque produit
- popup variante garde image produit
