V5.2
- recherche par produit
- variantes en popup
- paiement/options en popup
- validation en popup
- bouton valider fixe en bas
