# ZAZAH ERP Android SQLite V6.3.8

- Qualité A4 = 0x33
- Énergie AF = 20000 (0x20 0x4E)
- Ticket POS : BE = 0x00 (Image)
- Étiquette : BE = 0x03 (Label)
- Vitesse BD = 0x19 (25)
- Reset qualité avant/après conservé

VersionCode 111
VersionName 6.3.8-sc03h-iprint-profile
