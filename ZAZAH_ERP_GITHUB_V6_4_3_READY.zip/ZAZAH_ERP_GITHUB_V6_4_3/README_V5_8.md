V5.8
- image produit améliorée
- mise en attente et reprise POS
- stock ajout qty
- nouveau variant
