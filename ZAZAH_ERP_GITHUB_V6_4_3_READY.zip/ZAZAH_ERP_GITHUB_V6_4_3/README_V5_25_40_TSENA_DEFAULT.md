# ZAZAH ERP Android SQLite V5.25.40 — Tsena par défaut

## Correction
- **Tsena** devient l’emplacement sélectionné par défaut dans tous les écrans Android utilisant la liste des emplacements.
- POS : ouverture sur **Tsena**.
- Stock : ouverture sur **Tsena**.
- Création de variante / ajout de stock : utilise **Tsena** tant que l’utilisateur ne choisit pas volontairement un autre emplacement.
- Les ventes en attente conservent leur emplacement déjà enregistré lorsqu’elles sont reprises.
- Le choix est basé sur le nom `Tsena`, pas uniquement sur l’ID 1, afin de rester fiable après une synchronisation serveur.
- Si Tsena n’existe exceptionnellement pas, l’application retombe sur le premier emplacement disponible.

VersionCode : 71  
VersionName : `5.25.40-tsena-default`
