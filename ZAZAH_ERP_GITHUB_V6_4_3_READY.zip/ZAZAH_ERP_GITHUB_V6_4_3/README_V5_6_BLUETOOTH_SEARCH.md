# ZAZAH ERP V5.6 — Recherche imprimante Bluetooth

- Recherche Bluetooth depuis Paramètres
- Affiche appareils appairés et détectés
- Appairage depuis l’application pour appareils non appairés
- Android 12+ : permissions BLUETOOTH_SCAN / BLUETOOTH_CONNECT
- Android 11 et moins : permission localisation uniquement pour la découverte Bluetooth
- Impression directe ESC/POS 58/80 mm conservée
- Réimpression du dernier ticket conservée
- Token de synchronisation reste modifiable
