# ZAZAH ERP Android SQLite V5.25.11 — Sync avances bidirectionnelle

Base : V5.25.10.

Correction :
- les avances créées en SQLite local sont maintenant envoyées vers MySQL ;
- les avances en ligne continuent d'être téléchargées vers SQLite ;
- les anciennes avances locales sans server_id sont automatiquement mises en file d'attente au premier sync ;
- idempotence via op_uuid + mobile_sync_ops côté serveur pour éviter les doublons ;
- résolution du salarié via server_id, mapping du salarié créé dans le même sync, ou matricule.

DB_VERSION = 11.
Une nouvelle table locale mobile_advance_ops est créée automatiquement.

IMPORTANT : mettre à jour aussi push_masterdata.php et browser_sync.php sur le serveur.
