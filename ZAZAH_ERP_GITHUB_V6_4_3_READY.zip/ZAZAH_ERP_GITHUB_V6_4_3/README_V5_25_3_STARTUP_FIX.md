# ZAZAH ERP Android SQLite V5.25.3 — correction démarrage

- Repart de la V5.25 Paie SQLite stable.
- Garde le nouvel accueil moderne.
- Supprime totalement le composant Application personnalisé des V5.25.1/V5.25.2.
- La barre de navigation Android du bas est masquée après ouverture des écrans avec SystemUiHelper.
- PosActivity garde son système immersif existant et testé.
- Aucune modification de DatabaseHelper / SQLite par rapport à V5.25.
