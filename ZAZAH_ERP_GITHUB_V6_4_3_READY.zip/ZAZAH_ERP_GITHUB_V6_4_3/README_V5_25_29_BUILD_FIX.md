# ZAZAH ERP V5.25.29 — BUILD FIX ANDROID

Correction de `StockActivity.java` après V5.25.28.

Erreur corrigée dans Android Studio :
- `unclosed string literal` lignes 162/163
- `unclosed string literal` lignes 219/221
- les erreurs Java en cascade provoquées par ces chaînes sont supprimées.

La fonction **Changer produit** reste incluse et la correction TOKEN V5.25.28 est conservée.

Aucune modification serveur ni SQL n'est nécessaire pour ce correctif de compilation.
