# ZAZAH ERP Android V5.25.37 — Sélection utilisateur PIN

Corrections :
- le bouton **Configurer / changer le PIN** affiche maintenant réellement la liste des utilisateurs ;
- suppression du conflit Android entre `setMessage()` et `setItems()` qui masquait la liste ;
- suppression des deux boutons vides qui apparaissaient autour de **Annuler** ;
- toucher un utilisateur ouvre immédiatement l’écran **Définir / Changer le PIN** ;
- le PIN reste local dans SQLite et est demandé à l’ouverture de la session.

Flux : Utilisateurs → Configurer / changer le PIN → choisir un utilisateur → saisir le PIN deux fois → Activer le PIN → Session → choisir cet utilisateur → saisir le PIN.
