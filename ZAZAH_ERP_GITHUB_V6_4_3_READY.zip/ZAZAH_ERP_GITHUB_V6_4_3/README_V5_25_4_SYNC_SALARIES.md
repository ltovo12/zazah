# ZAZAH ERP Android SQLite V5.25.4 - Synchronisation salariés

Correction du module Paie SQLite :
- salariés Android -> MySQL (création et modification)
- salariés MySQL -> SQLite lors du catalogue
- ajout de server_id sans casser les IDs SQLite utilisés par avances/paies
- migration SQLite v7 -> v8 automatique
- les salariés V5.25 existants sont automatiquement placés dans la file de synchronisation

IMPORTANT : pour le bidirectionnel, installer aussi le correctif serveur fourni séparément :
- /zazah/admin/mobile_api/push_masterdata.php
- /zazah/admin/mobile_api/catalog.php
