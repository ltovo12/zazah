# ZAZAH ERP Android V5.25.46 — Étiquettes Barcode + QR

Ajouts :
- bouton **Impression étiquettes** dans le menu principal moderne ;
- recherche produit / couleur / taille / code-barres ;
- sélection d'une variante SQLite ;
- nombre d'étiquettes de 1 à 50 ;
- impression Bluetooth ESC/POS avec **Code 128 + QR code** ;
- nom produit, variante, prix et code imprimés ;
- largeur automatique 58 mm / 80 mm selon les paramètres ;
- une étiquette par ligne ;
- si le code-barres est vide, génération d'un code local `ZTS########` ;
- accès direct aux paramètres imprimante.

Toutes les fonctions précédentes sont conservées.
