V5.19
- une vente avec stock serveur insuffisant ne bloque plus toute la synchronisation
- clients/variants/stock et autres ventes continuent
- vente rejetee reste pending avec sync_error specifique
- catalogue est recharge meme si certaines ventes sont refusees
