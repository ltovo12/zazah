# ZAZAH ERP Android SQLite V6.3.9 — Labels Barcode + QR + Feed fin

## Ajouts
- Format barcode modernisé (sans image produit)
- Format QR 40x30 modernisé (sans contour extérieur, QR plus visible)
- Format QR 60x40 modernisé (sans contour extérieur, QR plus visible)
- Retour à la ligne / avance papier ajouté en fin d'impression d'étiquette
- Base: V6.3.8 SC03h iPrint profile

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
