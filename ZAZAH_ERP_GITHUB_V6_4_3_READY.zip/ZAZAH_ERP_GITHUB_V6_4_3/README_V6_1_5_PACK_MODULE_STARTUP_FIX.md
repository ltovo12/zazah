# ZAZAH ERP Android SQLite V6.1.5

Correctif du crash à l'ouverture du module Pack.

## Cause
La V6.1.4 utilisait les nouvelles colonnes SQLite :
- image_path
- logo_path
- whatsapp_number

mais la base restait en DB_VERSION 18. Une installation possédant déjà une base V18 n'exécutait donc aucune migration et le module Pack se fermait dès l'ouverture.

## Correction
- DB_VERSION passe de 18 à 19
- migration automatique V18 -> V19
- création automatique des colonnes marketing Pack
- auto-réparation légère dans onOpen()
- conservation des packs et données SQLite existantes

## Version application
- versionCode 88
- versionName 6.1.5-pack-module-startup-fix

Ne pas désinstaller l'ancienne application si vous souhaitez conserver la base locale.
