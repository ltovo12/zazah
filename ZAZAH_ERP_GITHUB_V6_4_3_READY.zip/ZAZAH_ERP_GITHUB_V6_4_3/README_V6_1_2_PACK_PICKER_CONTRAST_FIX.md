# V6.1.2 — Pack multi-produits : sélecteur mobile lisible

Correction visuelle du popup **Produits de l’article** montré sur mobile.

- texte des produits forcé en blanc très lisible sur fond sombre ;
- cases à cocher recolorées : gris clair non sélectionné, bleu clair sélectionné ;
- compteur de résultats/sélection plus contrasté ;
- lignes plus hautes et plus faciles à toucher ;
- séparateurs discrets entre produits ;
- hauteur de liste adaptée automatiquement à l’écran du téléphone ;
- boutons Annuler / Valider restent visibles ;
- conservation du correctif de démarrage V6.1.1, du pack multi-produits, du PIN auto et du partage WhatsApp moderne.

VersionCode : 85
VersionName : 6.1.2-pack-picker-contrast-fix
