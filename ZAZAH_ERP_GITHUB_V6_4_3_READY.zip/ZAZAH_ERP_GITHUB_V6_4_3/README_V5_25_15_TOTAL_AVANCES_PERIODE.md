# V5.25.15 — Total des avances par salarié et période

Modification Android SQLite :

- Ajout du **Total avances période** dans l'en-tête violet de l'écran **Avances salariés**.
- Le total correspond exactement aux lignes affichées après filtrage par salarié + date début + date fin.
- Mise à jour automatique quand on :
  - change de salarié ;
  - change de période ;
  - appuie sur **Afficher** ;
  - ajoute une avance ;
  - supprime une avance.
- Aucun changement du schéma SQLite n'est nécessaire.
- La synchronisation en ligne existante n'est pas modifiée.

Version Android :
- versionCode : 46
- versionName : 5.25.15-total-avances-periode
