# ZAZAH ERP V5.25.28 — TOKEN SYNC ROBUSTE

Correction du message `TOKEN invalide` pendant la synchronisation mobile.

- l'application réinitialise une seule fois un ancien token mémorisé après mise à jour ;
- bouton **Réinitialiser token ZAZAH** dans Paramètres ;
- le serveur accepte le token via `X-ZAZAH-SYNC-TOKEN`, `X-Auth-Token`, `Authorization: Bearer` et `sync_token` en secours ;
- `browser_sync.php` envoie automatiquement le token par plusieurs méthodes pour être compatible avec InfinityFree/WebView ;
- aucune vente SQLite n'est supprimée en cas d'échec.

Installation : mettre à jour l'application ET recopier `server_patch/admin/mobile_api/` sur le serveur.
