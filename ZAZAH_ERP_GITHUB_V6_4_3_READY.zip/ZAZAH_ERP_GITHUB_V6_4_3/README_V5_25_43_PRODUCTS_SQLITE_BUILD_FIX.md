# V5.25.43 - Products SQLite build fix

Correction de compilation de `ProductsActivity.java`.

Le type Android `TextView` ne possède pas la méthode `setTextStyle(int)`.
Les trois appels invalides ont été remplacés par :

```java
view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
```

Fichiers concernés :
- `app/src/main/java/mg/zazah/erp/ProductsActivity.java`
- `app/build.gradle`

Version Android :
- versionCode 74
- versionName `5.25.43-products-sqlite-build-fix`

Toutes les fonctions de la V5.25.42 sont conservées, y compris création/modification des produits SQLite.
