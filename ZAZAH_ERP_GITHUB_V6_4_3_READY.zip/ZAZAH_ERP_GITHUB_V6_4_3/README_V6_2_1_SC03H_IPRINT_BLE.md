# ZAZAH ERP Android SQLite V6.2.1

Ajout de la compatibilité imprimante SC03h / iPrint en Bluetooth Low Energy.

## Nouveautés
- recherche Bluetooth classique + BLE
- détection des imprimantes SC03h
- mode automatique SC03h/iPrint BLE ou ESC/POS
- service BLE AE30
- écriture sur AE01
- protocole 51 78 avec CRC8
- largeur bitmap 384 px
- impression tickets POS / historique
- impression étiquettes Barcode / QR
- conservation de l'ancien mode ESC/POS

## Fichiers principaux
- `app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java`
- `app/src/main/java/mg/zazah/erp/BluetoothEscPosPrinter.java`
- `app/src/main/java/mg/zazah/erp/SettingsActivity.java`
- `app/src/main/java/mg/zazah/erp/AppPrefs.java`
- `app/build.gradle`

## Utilisation
1. Allumer la SC03h.
2. Ouvrir Paramètres > imprimante ticket.
3. Appuyer sur Rechercher des imprimantes Bluetooth.
4. Sélectionner `SC03h-xxxx`.
5. Enregistrer les paramètres.
6. Imprimer depuis POS / historique / étiquettes.
