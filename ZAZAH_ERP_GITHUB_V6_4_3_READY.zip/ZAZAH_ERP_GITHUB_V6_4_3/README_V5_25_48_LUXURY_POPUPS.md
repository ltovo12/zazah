# ZAZAH ERP Android V5.25.48 — Luxury Popups

Cette version conserve toutes les fonctions précédentes et harmonise l'interface autour du style de connexion premium demandé.

## Nouveautés
- Page PIN au démarrage redessinée : grand titre ZAZAH TSENA SABOTSY, carte avec en-tête clair, corps graphite, champs sombres et bouton bleu.
- Tous les `AlertDialog` de l'application passent par `DialogUi.Builder` et reçoivent automatiquement le même style premium.
- Popups : en-tête clair, corps graphite, ombre, coins arrondis, boutons bleu/graphite/rouge, champs et listes contrastés.
- Les dialogs créés puis affichés plus tard sont également stylés grâce au hook d'attachement du builder.
- Conservation des thèmes Odoo, Hercule, Aurora 2026 et Graphite 2026.
- Conservation de l'impression étiquettes avec choix Barcode ou QR Code, Produits SQLite, recherche produit pour nouveau variant, PIN, POS, stock, clients, packs, paie, utilisateurs et synchronisation.

VersionName : `5.25.48-luxury-popups`
VersionCode : `79`
