# ZAZAH ERP Android 6.0 — PIN téléphone + connexion automatique

- Écran PIN transformé en clavier numérique intégré, style verrouillage téléphone.
- Plus besoin du clavier Android pour saisir le PIN.
- Plus de bouton « Se connecter » : dès que les chiffres saisis correspondent au PIN local, ZAZAH ERP s'ouvre automatiquement.
- PIN existants 4 à 8 chiffres conservés : aucune réinitialisation nécessaire.
- Touche ⌫ : appui court = effacer un chiffre ; appui long = vider toute la saisie.
- Retour haptique sur les touches, confirmation en cas de PIN correct et signal en cas d'erreur.
- Changer d'utilisateur et Fermer restent accessibles.
- Version application : 6.0
- versionCode : 82

## Changement d'utilisateur
Lorsqu'un utilisateur protégé par PIN est choisi depuis la page Session, l'application ouvre maintenant le même clavier PIN style téléphone. L'ancien popup avec bouton « Ouvrir » n'est plus utilisé pour les comptes protégés.
