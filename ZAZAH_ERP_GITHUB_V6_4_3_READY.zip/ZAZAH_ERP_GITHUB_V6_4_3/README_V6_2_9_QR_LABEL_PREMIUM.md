# ZAZAH ERP Android SQLite V6.2.9

## Changements
- format premium pour l'étiquette QR 58 mm
- cadre extérieur de l'étiquette
- nom produit plus grand
- cadre double autour du QR code
- message de scan en bas
- cartouche code produit mieux mis en valeur
- format barcode classique conservé

## Version
- versionCode : 102
- versionName : 6.2.9-qr-label-premium

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
