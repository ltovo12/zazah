# ZAZAH ERP Android SQLite V6.1.8

Amélioration du style image pack.

## Changements
- style encore plus rouge / blanc inspiré du modèle
- affichage de la quantité à côté du nom de chaque bloc/article
- quantité affichée entre parenthèses
- meilleure lisibilité des listes pack

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/PackImageGenerator.java`
- `app/build.gradle`
