# ZAZAH ERP Android SQLite V5.25.30 — TOKEN FORCE FIX

Correction du message `TOKEN invalide` encore présent après mise à jour.

## Correction
- `AppPrefs.token()` retourne toujours le token officiel commun au serveur ;
- toute ancienne valeur stockée dans SharedPreferences est automatiquement remplacée ;
- le champ Token dans Paramètres est maintenant en lecture seule ;
- l'enregistrement des paramètres ne peut plus sauvegarder un mauvais token ;
- le server_patch inclus utilise exactement le même token.

## Important
Le serveur doit utiliser les fichiers `admin/mobile_api/bootstrap.php`, `browser_sync.php` et `config_mobile.php` fournis dans `server_patch`.

Après mise à jour de l'application, il n'est plus nécessaire de saisir ou réinitialiser le token manuellement.
