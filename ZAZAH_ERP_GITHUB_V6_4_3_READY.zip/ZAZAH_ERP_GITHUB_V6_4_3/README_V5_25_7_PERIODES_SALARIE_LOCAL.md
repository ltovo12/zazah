# ZAZAH ERP Android SQLite V5.25.7

## Avances salariés — périodes comme ERP web

- Ajout d'une liste **Période du salarié** dans l'écran Avances.
- Après sélection d'un salarié, toutes ses périodes de paie disponibles sont chargées depuis SQLite.
- Affichage lisible : `18/08/2026 au 17/09/2026`.
- La période la plus récente est sélectionnée automatiquement.
- Date début / Date fin sont remplies automatiquement avec les valeurs SQLite (`AAAA-MM-JJ`).
- La liste d'avances est re-filtrée automatiquement.
- Indication du nombre de périodes disponibles pour le salarié.
- Si aucune paie n'existe encore : mois courant utilisé en secours.
- Compatible avec la synchronisation Paie V5.25.5/V5.25.6.
