V5.23
- refonte reelle des popups POS
- cartes arrondies, fond transparent, titres integres
- variantes, panier, paiement, attente, nouveau client, confirmations
