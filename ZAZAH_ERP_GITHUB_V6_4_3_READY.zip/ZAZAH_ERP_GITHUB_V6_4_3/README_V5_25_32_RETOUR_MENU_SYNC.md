# ZAZAH ERP Android SQLite V5.25.32

## Nouveau
- Ajout du bouton **‹ Menu principal** dans la fenêtre Synchronisation.
- Le bouton reste visible dans l’en-tête, même quand la page de synchronisation WebView est longue.
- Il ouvre explicitement `MainActivity` et ferme `SyncActivity`.
- Toutes les corrections V5.25.31 (synchronisation bidirectionnelle des packs) et V5.25.30 (token) sont conservées.

## Fichiers modifiés
- `app/src/main/res/layout/activity_sync.xml`
- `app/src/main/java/mg/zazah/erp/SyncActivity.java`
- `app/build.gradle`
- `app/src/main/res/layout/activity_settings.xml`
