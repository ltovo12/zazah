ZAZAH ERP Android SQLite V5.3

Base: V5.2 popup POS + token fix V5.1.

Nouveautés:
- recherche affiche seulement le produit
- variantes dans popup moderne
- photo produit/variante dans le popup si image_url disponible
- ajout immédiat au panier après sélection
- Annuler/Vider, Options et Valider visibles en bas
- validation reste en popup
- paiement/options reste en popup
- synchronisation/token V5.1 conservés
