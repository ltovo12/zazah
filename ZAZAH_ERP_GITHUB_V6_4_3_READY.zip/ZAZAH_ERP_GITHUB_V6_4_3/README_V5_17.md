V5.17
- monnaie a rendre visible POS/paiement/confirmation/historique
- paiement especes total par defaut mais modifiable
- nouveau client moderne : nom complet, contact, adresse
- nouveau client directement depuis popup paiement POS
