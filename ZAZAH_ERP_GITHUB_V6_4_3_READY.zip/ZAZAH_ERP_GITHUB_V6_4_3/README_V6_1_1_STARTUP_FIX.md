# ZAZAH ERP Android / SQLite V6.1.1 — Startup Fix

Correction du crash au démarrage de la V6.1 sur une base SQLite existante V17.

## Cause
La migration V17 -> V18 créait l'index `idx_pack_articles_group` avant d'ajouter la colonne `groupe_code`. SQLite levait une exception dès l'ouverture de la base et Android fermait l'application.

## Correction
- ajout de `groupe_code` avant création des index du pack ;
- conservation du DB_VERSION 18 pour relancer proprement la migration après le rollback du crash ;
- version Android passée à 6.1.1 / versionCode 84 ;
- aucune suppression de données ;
- pack multi-produits, WhatsApp moderne et PIN V6.0 conservés.
