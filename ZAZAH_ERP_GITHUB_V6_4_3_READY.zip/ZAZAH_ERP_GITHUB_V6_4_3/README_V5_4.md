ZAZAH ERP Android SQLite V5.4

- Remise, TVA et Livraison affichées côte à côte dans le popup Paiement / Options.
- Résumé POS : Sous-total, Remise, TVA et Livraison visibles sur la même ligne.
- Token de synchronisation de nouveau modifiable dans Paramètres, comme en V4.
- Le token Android doit rester identique à ZAZAH_MOBILE_TOKEN dans server_patch/admin/mobile_api/config_mobile.php.
- Toutes les fonctions V5.3 sont conservées.
