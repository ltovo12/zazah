# ZAZAH ERP Android SQLite V5.25.10

Correction du blocage `UNIQUE constraint failed: paies.salarie_id, paies.mois_paie`.

- Base SQLite : version 10.
- Migration automatique depuis V9 sans effacer les paies ni les paiements.
- Suppression de l’ancienne unicité `(salarie_id, mois_paie)`.
- Nouvelle unicité : `(salarie_id, periode_debut, periode_fin)`.
- Recalcul par période propre : le salaire de base est relu depuis `salaries`.
- Import serveur et génération locale identifient une paie par dates exactes de période.
- `mois_paie` reste seulement un champ de regroupement/compatibilité.
