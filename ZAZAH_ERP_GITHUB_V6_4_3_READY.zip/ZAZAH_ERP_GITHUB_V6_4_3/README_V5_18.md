V5.18
- réparation automatique des clients SQLite local_only sans mobile_client_ops
- POS portrait : cartes produits compactes, plus de lignes visibles
- panier agrandi
- paysage : panier plus large
- correctif serveur client_list/password/client_meta fourni séparément
