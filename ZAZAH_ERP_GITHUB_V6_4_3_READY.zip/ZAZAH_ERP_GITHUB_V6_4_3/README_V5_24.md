V5.24
- boutons de popup toujours visibles
- Appliquer/Modifier/Valider violet + texte blanc
- Annuler/Fermer fond clair
- Supprimer/Quitter style danger
- fond blanc arrondi couvre aussi la barre des actions
