V5.16
- nouveau variant: couleur sélectionnable comme en ligne + Autre couleur
- aperçu couleur
- ESPÈCES propose automatiquement le total mais Montant reçu reste modifiable
- montant vide en ESPÈCES = total lors de validation directe
