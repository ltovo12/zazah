# ZAZAH ERP Android V5.25.47

## Étiquettes : choix Barcode ou QR code
- Au clic sur **Imprimer l’étiquette**, l’application demande maintenant le type de code à imprimer.
- Deux choix : **Code-barres / Code 128** ou **QR code**.
- Une série d’étiquettes imprime uniquement le type choisi, au lieu d’imprimer les deux systématiquement.
- Le nom, la variante, le prix et le code produit restent présents selon le format.
- Compatible avec l’imprimante Bluetooth configurée en 58 mm / 80 mm.

## Écran PIN au démarrage : nouvelle présentation luxe
- En-tête premium cohérent avec le nouveau menu principal.
- Carte utilisateur avec avatar initial, nom, identifiant et rôle.
- Champ PIN plus grand et plus lisible.
- Bouton **Afficher / Masquer** le PIN.
- Bouton principal de déverrouillage renforcé.
- Actions Changer d’utilisateur / Fermer l’application conservées.
- Compatible avec les thèmes Odoo, Hercule, Aurora 2026 et Graphite 2026.

Version Android : `5.25.47-label-code-choice-luxury-pin`
VersionCode : `78`
