# ZAZAH ERP Android / SQLite V6.1.3 — Pack stock Tsena

## Correction
- Dans **Packs > Produits de l'article**, le stock affiché provient maintenant **uniquement de l'emplacement Tsena**.
- Le stock Dépôt et Home n'est plus additionné dans ce sélecteur.
- La recherche de Tsena se fait par le nom de l'emplacement, donc elle reste correcte même si son ID change après synchronisation.
- Les variantes avec stock Tsena = 0 restent visibles pour permettre de préparer les packs à l'avance.
- Le libellé affiche clairement `stock Tsena X`.

Version Android : `6.1.3-pack-stock-tsena`  
VersionCode : `86`
