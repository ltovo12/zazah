# ZAZAH ERP V6.4.3 — GitHub Build APK

Cette version est prête pour GitHub Actions.

## Installation dans GitHub

1. Ouvrez votre dépôt `ZAZAH-ERP-Android`.
2. Envoyez le contenu de ce dossier à la racine du dépôt.
3. Vérifiez que `.github/workflows/build-apk.yml` est présent.
4. Ouvrez `Actions`.
5. Choisissez `Build ZAZAH ERP APK`.
6. Appuyez sur `Run workflow`.
7. Après le build vert, ouvrez le build et téléchargez l'Artifact `ZAZAH-ERP-V6.4.3-APK`.

## APK généré

`ZAZAH_ERP_V6.4.3.apk`

## Configuration

- Java 17
- Android SDK 35
- Build Tools 35.0.0
- Gradle 8.9
- versionCode 116
- versionName 6.4.3-qr-vertical-text

## QR V6.4.3

- Texte vertical à gauche
- Grand QR à droite
- QR 40x30 et QR 60x40
- 1 avance papier en fin d'étiquette
