# ZAZAH ERP Android SQLite V5.25.13 — Ticket POS Pro 58/80 mm

## Impression POS
- Mise en page ESC/POS dédiée aux tickets thermiques.
- 58 mm : 32 colonnes.
- 80 mm : 48 colonnes.
- En-tête compact ZAZAH TSENA SABOTSY.
- Numéro, date et client.
- Articles : désignation + quantité x prix + total ligne.
- Sous-total, remise, TVA et livraison uniquement lorsqu’ils s’appliquent.
- TOTAL très visible en double taille.
- Mode de paiement.
- Tampon PAYE / PARTIEL / EN ATTENTE.
- Note et message de remerciement.
- Quantités fractionnaires conservées (ex. 0,5).
- Montants imprimés avec espaces ASCII pour éviter les caractères incompatibles sur les imprimantes ESC/POS économiques.

## Compatibilité
Cette version reprend la V5.25.12A et conserve le thème 3D Premium, la paie par période et la synchronisation des avances.
VersionCode : 43.
