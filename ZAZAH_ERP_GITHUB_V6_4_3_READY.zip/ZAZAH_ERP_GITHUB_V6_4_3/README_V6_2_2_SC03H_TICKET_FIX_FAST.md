# ZAZAH ERP Android SQLite V6.2.2

Corrections pour l'imprimante SC03h / iPrint BLE.

## Changements
- correction du message bas de ticket mal encodé (mojibake UTF-8)
- liste produits plus grande et plus lisible sur SC03h
- affichage des packs comme le ticket ERP en ligne :
  - nom du pack + prix global une seule fois
  - composants du pack en dessous avec uniquement la quantité
- numéro de ticket local au format `ZTS00001`, `ZTS00002`, etc.
- optimisation de la vitesse BLE :
  - priorité de connexion élevée
  - temporisation par trame réduite
  - pauses moins fréquentes
- ancien mode ESC/POS conservé

## Version
- versionCode: 95
- versionName: 6.2.2-sc03h-ticket-fix-fast

## Fichiers principaux modifiés
- `app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java`
- `app/build.gradle`

Note : la vitesse physique du moteur et de la tête thermique reste limitée par le matériel.
