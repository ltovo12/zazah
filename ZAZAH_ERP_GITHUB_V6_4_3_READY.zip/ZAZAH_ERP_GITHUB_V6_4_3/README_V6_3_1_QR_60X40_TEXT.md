# ZAZAH ERP Android SQLite V6.3.1

## Changements
- étiquette QR configurée en format 60x40 mm avec texte
- disposition moderne : texte à gauche, QR à droite
- informations incluses : nom produit, variante, prix, code et mention scanner
- format barcode classique conservé

## Version
- versionCode : 104
- versionName : 6.3.1-qr-60x40-text

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
