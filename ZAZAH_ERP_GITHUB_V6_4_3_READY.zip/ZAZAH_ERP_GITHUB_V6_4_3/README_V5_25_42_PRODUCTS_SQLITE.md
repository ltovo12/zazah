# ZAZAH ERP Android SQLite V5.25.42 — Produits SQLite

Ajouts :
- nouvel écran **Produits SQLite** accessible depuis le menu principal et depuis Stock ;
- création d'un produit hors ligne : nom, prix, image, statut ;
- modification d'un produit existant directement dans SQLite ;
- option à la création pour générer automatiquement une variante par défaut utilisable dans le POS ;
- stock initial optionnel placé à **Tsena** ;
- recherche produits, nombre de variantes, stock total et origine affichés dans la liste ;
- les produits locaux utilisent des IDs négatifs pour éviter les collisions avec le serveur ;
- les créations/modifications locales sont protégées pendant le téléchargement du catalogue ;
- les variantes locales négatives et leur stock ne sont plus effacés par un pull catalogue ;
- une variante attachée à un produit purement local reste locale et n'est pas envoyée au serveur.

Important : cette version ajoute la gestion **SQLite locale** des produits. Elle ne pousse pas encore les créations/modifications de produits vers MySQL. Les produits serveur modifiés sur le téléphone sont conservés comme surcharge locale SQLite.

Version Android : `5.25.42-products-sqlite` — `versionCode 73`.
