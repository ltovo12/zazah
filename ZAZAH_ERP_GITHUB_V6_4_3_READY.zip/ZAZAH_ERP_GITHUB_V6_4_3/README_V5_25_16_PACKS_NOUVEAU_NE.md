# ZAZAH ERP Android SQLite V5.25.16 — Packs Nouveau-né

## Nouveau module
- Écran **Packs Nouveau-né** depuis l'accueil.
- 3 packs initiaux modifiables :
  - Pack Nouveau-né Classique — 350 000 Ar
  - Pack Nouveau-né Confort — 600 000 Ar
  - Pack Nouveau-né Premium — 850 000 Ar
- Composition modifiable au fur et à mesure : ajout, modification, suppression, quantité 0,5 acceptée, prix unitaire de détail.
- Un article peut rester **libre** puis être **lié à une variante du catalogue/stock** plus tard.
- Le prix de vente du pack reste indépendant et modifiable.
- Le total du détail est calculé automatiquement à partir des lignes du pack.

## POS
- Nouveau bouton **Packs** dans le POS portrait et paysage.
- Un pack est vendable quand toutes ses lignes sont liées au catalogue/stock.
- À l'ajout, sa composition est ajoutée au panier et le prix du pack est réparti sur les articles.
- La vente continue donc d'utiliser les variantes normales : le stock SQLite est déduit normalement et les lignes de vente restent compatibles avec la synchronisation des ventes existante.
- Le stock est contrôlé selon l'emplacement actuellement sélectionné dans le POS.

## SQLite
- Base passée en version 12.
- Nouvelles tables locales : `packs` et `pack_articles`.
- La migration conserve les données existantes.
- Les définitions de packs sont locales Android dans cette version ; les ventes de packs utilisent les variantes existantes et continuent à passer par le flux de vente habituel.

## Listes initiales
Les noms clairement lisibles du carnet ont été préchargés (Triangle, Cape, Couverture, Pélisse, Chaussons/Moufles, Bonnet, Bavoir, Baignoire, Sortie de bain, Lange, Layette, etc.). Les prix de détail peuvent être complétés au fur et à mesure depuis l'écran de gestion.
