# ZAZAH ERP Android SQLite V5 — Grand POS

Base utilisée : ZAZAH_ERP_Android_SQLite_V4_OdooStyle_SQLFix (fichier utilisateur confirmé fonctionnel).

Modifications V5 :
- conservation du code V4 (SQLite, synchronisation, scanner, calculs, enregistrement des ventes) ;
- liste produits agrandie ;
- panier agrandi ;
- options de paiement repliables ;
- total toujours visible ;
- affichage paysage autorisé ;
- paysage : produits à gauche et panier à droite ;
- versionCode 5 / versionName 5.0-odoo-grand-pos.
