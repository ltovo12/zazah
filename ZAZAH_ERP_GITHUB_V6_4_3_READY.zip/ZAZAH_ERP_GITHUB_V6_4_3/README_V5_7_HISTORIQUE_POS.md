ZAZAH ERP Android SQLite V5.7

- Historique POS local, plus récent en premier
- Recherche par numéro, client, date, paiement ou statut
- Détail complet d’une vente dans une popup
- Réimpression d’un ancien ticket avec l’imprimante Bluetooth ESC/POS sélectionnée
- Accès Historique depuis l’accueil et directement depuis le POS
- Conservation recherche Bluetooth 58/80 mm, token modifiable et impression auto
