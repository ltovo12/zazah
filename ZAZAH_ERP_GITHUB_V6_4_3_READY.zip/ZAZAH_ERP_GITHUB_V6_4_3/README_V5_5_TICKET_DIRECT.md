V5.5
- impression ticket directe Bluetooth ESC/POS après validation
- choix imprimante appairée dans Paramètres
- largeur 58/80 mm
- impression automatique activable
- ticket avec remise, TVA, livraison, total, reçu, paiement et statut
- token reste modifiable comme V4
