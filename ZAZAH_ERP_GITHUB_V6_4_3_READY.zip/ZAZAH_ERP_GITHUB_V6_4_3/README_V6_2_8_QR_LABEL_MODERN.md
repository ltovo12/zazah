# ZAZAH ERP Android SQLite V6.2.8

## Changements
- nouveau format moderne pour l'étiquette QR code 58 mm
- en-tête ZAZAH TSENA SABOTSY
- nom produit, variante et prix mieux espacés
- QR code bien centré et plus valorisé
- texte de scan et code en bas mieux présentés
- format barcode classique conservé

## Version
- versionCode : 101
- versionName : 6.2.8-qr-label-modern

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
