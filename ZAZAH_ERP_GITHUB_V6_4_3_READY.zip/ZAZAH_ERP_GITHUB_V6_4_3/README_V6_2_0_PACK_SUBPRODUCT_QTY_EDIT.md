# ZAZAH ERP Android SQLite V6.2.0

## Changements
- la quantité n'apparaît plus sur le titre de l'article/groupe dans l'image pack
- la quantité apparaît seulement sur chaque sous-produit
- possibilité de définir une quantité différente pour chaque sous-produit dans l'édition
- la quantité générale reste seulement pour le cas d'un article libre (sans produit lié)
- image pack adaptée pour afficher uniquement la quantité des sous-produits

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/PackActivity.java`
- `app/src/main/java/mg/zazah/erp/DatabaseHelper.java`
- `app/src/main/java/mg/zazah/erp/PackImageGenerator.java`
- `app/build.gradle`
