V5.11
- Barre navigation Android cachee dans POS conservee
- Respect de la barre d etat en haut (pas de chevauchement)
- Libelles Historique / Scanner / Reprendre visibles
- Remise / TVA / Livraison vides par defaut pour afficher les placeholders
- Les calculs continuent de traiter un champ vide comme 0
