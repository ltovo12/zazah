# ZAZAH V5.25.20 — Recherche comme facture + liaison stock

La version en ligne utilise maintenant une fenêtre de sélection similaire à l’ajout produit de la facture. La version Android garde son sélecteur de stock avec recherche et résultats cliquables.
