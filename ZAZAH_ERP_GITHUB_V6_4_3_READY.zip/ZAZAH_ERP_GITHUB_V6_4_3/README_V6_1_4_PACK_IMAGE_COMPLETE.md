# ZAZAH ERP Android SQLite V6.1.4

Améliorations appliquées à la version SQLite / Android pour le module Packs.

## Ajouts principaux
- application des améliorations récentes du module image pack sur SQLite
- format carré amélioré pour afficher toute la liste du pack
- agrandissement automatique du carré si le pack contient beaucoup d'articles
- ajout de champs pack : image marketing, logo, numéro WhatsApp
- sélection image/logo depuis la galerie Android
- affichage du WhatsApp dans le visuel marketing
- partage WhatsApp avec légende améliorée
- enregistrement de l'image dans Pictures/ZAZAH

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/DatabaseHelper.java`
- `app/src/main/java/mg/zazah/erp/PackActivity.java`
- `app/src/main/java/mg/zazah/erp/PackImageGenerator.java`
- `app/build.gradle`
