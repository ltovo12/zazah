# ZAZAH ERP Android SQLite V6.4.0

## Étiquettes
- Barcode modernisé, proche de l’aperçu montré
- QR 40x30 modernisé, sans texte technique
- QR 60x40 modernisé, sans texte technique
- Pas d’image produit
- 1 seule avance papier en fin d’étiquette
- Profil SC03h iPrint V6.3.8 conservé

## Version
- versionCode 113
- versionName 6.4.0-label-preview-match-feed1
