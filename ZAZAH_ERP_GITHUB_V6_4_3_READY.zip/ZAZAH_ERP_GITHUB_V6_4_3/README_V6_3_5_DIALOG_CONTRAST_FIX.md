# ZAZAH ERP Android SQLite V6.3.5

## Corrections
- Fenêtre POS Paiement / Options : contraste corrigé.
- Texte et placeholders des champs rendus lisibles.
- Sélecteurs Client / Mode de paiement / Statut rendus lisibles.
- Montant à payer renforcé.
- Fenêtre Ajouter stock : champ quantité et texte corrigés avec le même contraste.
- Toutes les fonctions V6.3.4 sont conservées.

## Version
- versionCode : 108
- versionName : 6.3.5-dialog-contrast-fix
