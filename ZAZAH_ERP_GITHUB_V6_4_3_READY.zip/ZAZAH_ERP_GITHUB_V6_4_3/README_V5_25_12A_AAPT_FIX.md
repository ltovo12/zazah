# ZAZAH ERP Android SQLite V5.25.12a

Correctif de compilation AAPT du thème 3D Premium.

- Correction du style `ZAZAH.Dialog.Animation` : parent explicite `@android:style/Animation.Dialog`.
- Supprime l’erreur `resource style/ZAZAH.Dialog not found`.
- Thème 3D global conservé.
- VersionCode porté à 42 pour permettre la mise à jour au-dessus de V5.25.11 (41).
- Aucune modification de la base SQLite ni de la logique de synchronisation.
