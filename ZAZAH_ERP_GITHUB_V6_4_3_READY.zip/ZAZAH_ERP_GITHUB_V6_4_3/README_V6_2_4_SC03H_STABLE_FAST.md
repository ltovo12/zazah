# ZAZAH ERP Android SQLite V6.2.4 — SC03h Stable Fast

## Objectif
Éviter les échecs d'envoi au milieu d'une impression SC03h / iPrint BLE tout en conservant une vitesse correcte.

## Changements
- délai entre les trames porté à ~12 ms pour stabiliser le buffer BLE
- pause de 28 ms toutes les 24 lignes imprimées
- jusqu'à 4 tentatives automatiques sur une trame refusée par Android
- délai progressif entre les tentatives
- petite stabilisation après connexion / MTU
- priorité BLE élevée conservée
- corrections précédentes du ticket et de l'encodage conservées

## Version
- versionCode 97
- versionName 6.2.4-sc03h-stable-fast

## Fichier principal modifié
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
