# ZAZAH ERP Android SQLite V5.25.14

## Ticket POS relié aux paramètres en ligne

- Le serveur lit `system_info.meta_field = msg` et envoie ce message pendant la synchronisation.
- Android conserve le dernier message synchronisé dans SQLite : il reste imprimable hors ligne.
- L’en-tête utilise aussi le nom, l’adresse et le téléphone de `system_info` quand ils existent.
- Le ticket affiche `TICKET DE CAISSE` et n’imprime plus la mention technique 58/80 mm.
- Aucun tampon PAYÉ/PARTIEL/EN ATTENTE n’est imprimé.
- Le format papier reste automatiquement 58 mm (32 colonnes) ou 80 mm (48 colonnes).

## Serveur
Remplacer `admin/mobile_api/catalog.php` par celui fourni dans `server_patch`. Les autres endpoints V5.25.11+ restent inchangés.

## Utilisation
1. Modifier le message dans Paramètres en ligne (`msg`).
2. Sur Android : Synchronisation > Synchroniser maintenant.
3. Le prochain ticket utilise le nouveau message, même ensuite hors ligne.
