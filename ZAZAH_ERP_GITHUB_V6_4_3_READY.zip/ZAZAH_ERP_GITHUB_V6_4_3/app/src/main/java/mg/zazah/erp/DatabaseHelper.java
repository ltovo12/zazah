package mg.zazah.erp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.HashSet;
import java.util.UUID;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "zazah_mobile.sqlite";
    public static final int DB_VERSION = 19;

    public DatabaseHelper(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
        db.enableWriteAheadLogging();
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
        db.execSQL("CREATE TABLE emplacements(id INTEGER PRIMARY KEY,nom TEXT NOT NULL)");
        db.execSQL("CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER UNIQUE,fullname TEXT NOT NULL,contact TEXT,address TEXT,local_only INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE produits(id INTEGER PRIMARY KEY,name TEXT NOT NULL,price REAL DEFAULT 0,status INTEGER DEFAULT 1,image_url TEXT,local_dirty INTEGER DEFAULT 0,local_updated_at TEXT)");
        db.execSQL("CREATE TABLE variantes(id INTEGER PRIMARY KEY,service_id INTEGER NOT NULL,couleur TEXT,taille TEXT,code_barre TEXT,prix REAL DEFAULT 0,image_url TEXT)");
        db.execSQL("CREATE TABLE stocks(variante_id INTEGER NOT NULL,emplacement_id INTEGER NOT NULL,quantite REAL DEFAULT 0,PRIMARY KEY(variante_id,emplacement_id))");
        db.execSQL("CREATE TABLE ventes_locales(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,uuid TEXT UNIQUE NOT NULL,num_vente TEXT UNIQUE NOT NULL,date_vente TEXT NOT NULL," +
                "client_id INTEGER,emplacement_id INTEGER NOT NULL,sous_total REAL DEFAULT 0,remise REAL DEFAULT 0,taux_tva REAL DEFAULT 0," +
                "montant_tva REAL DEFAULT 0,frais_livraison REAL DEFAULT 0,montant_total REAL DEFAULT 0,montant_recu REAL DEFAULT 0," +
                "monnaie_rendue REAL DEFAULT 0,mode_paiement TEXT,statut_paiement TEXT DEFAULT 'EN_ATTENTE',commentaire TEXT," +
                "sync_status TEXT DEFAULT 'pending',server_id INTEGER,sync_error TEXT)");
        db.execSQL("CREATE TABLE vente_lignes_locales(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,vente_id INTEGER NOT NULL,variante_id INTEGER NOT NULL,designation TEXT," +
                "quantite REAL,prix_unitaire REAL,total_ligne REAL,FOREIGN KEY(vente_id) REFERENCES ventes_locales(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE pos_drafts(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,draft_code TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL," +
                "client_id INTEGER,emplacement_id INTEGER NOT NULL,remise REAL DEFAULT 0,taux_tva REAL DEFAULT 0," +
                "frais_livraison REAL DEFAULT 0,montant_recu REAL DEFAULT 0,mode_paiement TEXT,statut_paiement TEXT DEFAULT 'EN_ATTENTE',commentaire TEXT)");
        db.execSQL("CREATE TABLE pos_draft_lines(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,draft_id INTEGER NOT NULL,variante_id INTEGER NOT NULL,designation TEXT," +
                "quantite REAL,prix_unitaire REAL,FOREIGN KEY(draft_id) REFERENCES pos_drafts(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE mobile_client_ops(op_uuid TEXT PRIMARY KEY,local_client_id INTEGER NOT NULL,fullname TEXT NOT NULL,contact TEXT,address TEXT,created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE mobile_variant_ops(op_uuid TEXT PRIMARY KEY,local_variant_id INTEGER NOT NULL,service_id INTEGER NOT NULL,couleur TEXT,taille TEXT,code_barre TEXT,prix REAL DEFAULT 0,image_url TEXT,created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE mobile_stock_ops(op_uuid TEXT PRIMARY KEY,variante_id INTEGER NOT NULL,emplacement_id INTEGER NOT NULL,quantite REAL NOT NULL,created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE mobile_salary_ops(op_uuid TEXT PRIMARY KEY,local_salary_id INTEGER NOT NULL,matricule TEXT,nom TEXT NOT NULL,telephone TEXT,email TEXT,address TEXT,salaire_base REAL DEFAULT 0,allocation_repas_jour REAL DEFAULT 0,jours_repas_defaut REAL DEFAULT 26,actif INTEGER DEFAULT 1,created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE mobile_advance_ops(op_uuid TEXT PRIMARY KEY,local_advance_id INTEGER NOT NULL UNIQUE,salarie_local_id INTEGER NOT NULL,date_avance TEXT NOT NULL,montant REAL NOT NULL,remarque TEXT,created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE mobile_pack_ops(op_uuid TEXT PRIMARY KEY,local_pack_id INTEGER NOT NULL,server_id INTEGER DEFAULT 0,action TEXT NOT NULL DEFAULT 'UPSERT',created_at TEXT NOT NULL)");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mobile_pack_local ON mobile_pack_ops(local_pack_id)");
        db.execSQL("CREATE TABLE mobile_user_ops(op_uuid TEXT PRIMARY KEY,local_user_id INTEGER NOT NULL,server_id INTEGER DEFAULT 0,action TEXT NOT NULL DEFAULT 'UPSERT',firstname TEXT,lastname TEXT,username TEXT,role INTEGER DEFAULT 2,active INTEGER DEFAULT 1,password_md5 TEXT,created_at TEXT NOT NULL)");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mobile_user_local ON mobile_user_ops(local_user_id)");
        db.execSQL("CREATE INDEX idx_var_code ON variantes(code_barre)");
        db.execSQL("CREATE INDEX idx_sync ON ventes_locales(sync_status)");
        db.execSQL("CREATE INDEX idx_product_name ON produits(name)");
        db.execSQL("CREATE INDEX idx_draft_updated ON pos_drafts(updated_at)");
        createPayrollTables(db);
        createPackTables(db);
        seedNewbornPacks(db);
        createUserTables(db);
        seedEmplacements(db);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            try { db.execSQL("ALTER TABLE ventes_locales ADD COLUMN frais_livraison REAL DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE ventes_locales ADD COLUMN statut_paiement TEXT DEFAULT 'EN_ATTENTE'"); } catch (Exception ignored) {}
        }
        if (oldVersion < 3) {
            try { db.execSQL("ALTER TABLE produits ADD COLUMN image_url TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE variantes ADD COLUMN image_url TEXT"); } catch (Exception ignored) {}
        }
        if (oldVersion < 4) {
            try { db.execSQL("CREATE TABLE pos_drafts(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,draft_code TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL," +
                    "client_id INTEGER,emplacement_id INTEGER NOT NULL,remise REAL DEFAULT 0,taux_tva REAL DEFAULT 0," +
                    "frais_livraison REAL DEFAULT 0,montant_recu REAL DEFAULT 0,mode_paiement TEXT,statut_paiement TEXT DEFAULT 'EN_ATTENTE',commentaire TEXT)"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE TABLE pos_draft_lines(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,draft_id INTEGER NOT NULL,variante_id INTEGER NOT NULL,designation TEXT," +
                    "quantite REAL,prix_unitaire REAL,FOREIGN KEY(draft_id) REFERENCES pos_drafts(id) ON DELETE CASCADE)"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE INDEX idx_draft_updated ON pos_drafts(updated_at)"); } catch (Exception ignored) {}
        }
        if (oldVersion < 5) {
            try { db.execSQL("CREATE TABLE mobile_client_ops(op_uuid TEXT PRIMARY KEY,local_client_id INTEGER NOT NULL,fullname TEXT NOT NULL,contact TEXT,address TEXT,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE TABLE mobile_variant_ops(op_uuid TEXT PRIMARY KEY,local_variant_id INTEGER NOT NULL,service_id INTEGER NOT NULL,couleur TEXT,taille TEXT,code_barre TEXT,prix REAL DEFAULT 0,image_url TEXT,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE TABLE mobile_stock_ops(op_uuid TEXT PRIMARY KEY,variante_id INTEGER NOT NULL,emplacement_id INTEGER NOT NULL,quantite REAL NOT NULL,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
        }
        if (oldVersion < 7) {
            createPayrollTables(db);
        }
        if (oldVersion < 8) {
            try { db.execSQL("ALTER TABLE salaries ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE salaries ADD COLUMN local_only INTEGER DEFAULT 1"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_salaries_server_id ON salaries(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE TABLE IF NOT EXISTS mobile_salary_ops(op_uuid TEXT PRIMARY KEY,local_salary_id INTEGER NOT NULL,matricule TEXT,nom TEXT NOT NULL,telephone TEXT,email TEXT,address TEXT,salaire_base REAL DEFAULT 0,allocation_repas_jour REAL DEFAULT 0,jours_repas_defaut REAL DEFAULT 26,actif INTEGER DEFAULT 1,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
        }
        if (oldVersion < 9) {
            try { db.execSQL("ALTER TABLE avances ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE paies ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE paie_paiements ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_avances_server_id ON avances(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paies_server_id ON paies(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paie_paiements_server_id ON paie_paiements(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
        }
        if (oldVersion < 10) {
            migratePayrollPeriodUniquenessV10(db);
        }
        if (oldVersion < 11) {
            try { db.execSQL("CREATE TABLE IF NOT EXISTS mobile_advance_ops(op_uuid TEXT PRIMARY KEY,local_advance_id INTEGER NOT NULL UNIQUE,salarie_local_id INTEGER NOT NULL,date_avance TEXT NOT NULL,montant REAL NOT NULL,remarque TEXT,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
        }
        if (oldVersion < 12) {
            createPackTables(db);
            seedNewbornPacks(db);
        }
        if (oldVersion < 13) {
            createPackTables(db);
            try { db.execSQL("ALTER TABLE packs ADD COLUMN slogan TEXT DEFAULT ''"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE packs ADD COLUMN categorie TEXT DEFAULT 'Nouveau-né'"); } catch (Exception ignored) {}
        }
        if (oldVersion < 14) {
            createPackTables(db);
            try { db.execSQL("ALTER TABLE packs ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE packs ADD COLUMN local_only INTEGER DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_packs_server_id ON packs(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE TABLE IF NOT EXISTS mobile_pack_ops(op_uuid TEXT PRIMARY KEY,local_pack_id INTEGER NOT NULL,server_id INTEGER DEFAULT 0,action TEXT NOT NULL DEFAULT 'UPSERT',created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mobile_pack_local ON mobile_pack_ops(local_pack_id)"); } catch (Exception ignored) {}
            // Les 3 packs standards seront rapprochés du serveur par leur nom lors du premier catalogue.
            try { db.execSQL("UPDATE packs SET local_only=0 WHERE LOWER(TRIM(nom)) IN ('pack nouveau-né classique','pack nouveau-né confort','pack nouveau-né premium')"); } catch (Exception ignored) {}
            // Les autres packs déjà créés localement doivent être envoyés au serveur.
            try {
                db.execSQL("INSERT OR IGNORE INTO mobile_pack_ops(op_uuid,local_pack_id,server_id,action,created_at) " +
                        "SELECT lower(hex(randomblob(16))),id,COALESCE(server_id,0),'UPSERT',datetime('now','localtime') " +
                        "FROM packs WHERE COALESCE(local_only,1)=1");
            } catch (Exception ignored) {}
        }
        if (oldVersion < 15) {
            createUserTables(db);
        }
        if (oldVersion < 16) {
            createUserTables(db);
            try { db.execSQL("ALTER TABLE app_users ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE app_users ADD COLUMN local_only INTEGER DEFAULT 1"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_app_users_server_id ON app_users(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE TABLE IF NOT EXISTS mobile_user_ops(op_uuid TEXT PRIMARY KEY,local_user_id INTEGER NOT NULL,server_id INTEGER DEFAULT 0,action TEXT NOT NULL DEFAULT 'UPSERT',firstname TEXT,lastname TEXT,username TEXT,role INTEGER DEFAULT 2,active INTEGER DEFAULT 1,password_md5 TEXT,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mobile_user_local ON mobile_user_ops(local_user_id)"); } catch (Exception ignored) {}
        }
        if (oldVersion < 17) {
            try { db.execSQL("ALTER TABLE produits ADD COLUMN local_dirty INTEGER DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE produits ADD COLUMN local_updated_at TEXT"); } catch (Exception ignored) {}
        }
        if (oldVersion < 18) {
            // IMPORTANT: sur une base V17 existante, la table pack_articles existe déjà
            // sans groupe_code. Il faut ajouter la colonne AVANT de créer l'index qui l'utilise,
            // sinon l'application plante au démarrage pendant la migration SQLite.
            try { db.execSQL("ALTER TABLE pack_articles ADD COLUMN groupe_code TEXT NOT NULL DEFAULT ''"); } catch (Exception ignored) {}
            createPackTables(db);
            try { db.execSQL("UPDATE pack_articles SET groupe_code='A'||id WHERE COALESCE(TRIM(groupe_code),'')='' "); } catch (Exception ignored) {}
            try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_pack_articles_group ON pack_articles(pack_id,groupe_code,ordre,id)"); } catch (Exception ignored) {}
        }
        if (oldVersion < 19) {
            // V19 : champs marketing Pack. La V6.1.4 avait ajouté ces champs au code
            // sans augmenter DB_VERSION, donc une base V18 existante ne les créait pas.
            createPackTables(db);
            try { db.execSQL("ALTER TABLE packs ADD COLUMN image_path TEXT DEFAULT ''"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE packs ADD COLUMN logo_path TEXT DEFAULT ''"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE packs ADD COLUMN whatsapp_number TEXT DEFAULT ''"); } catch (Exception ignored) {}
        }
        seedEmplacements(db);
    }

    @Override public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        // Auto-réparation légère : garantit que les colonnes Pack récentes existent
        // même si une ancienne installation a été mise à jour depuis une build intermédiaire.
        try { createPackTables(db); } catch (Exception ignored) {}
    }


    private void createUserTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "firstname TEXT NOT NULL DEFAULT ''," +
                "lastname TEXT NOT NULL DEFAULT ''," +
                "username TEXT NOT NULL COLLATE NOCASE UNIQUE," +
                "role INTEGER NOT NULL DEFAULT 2," +
                "pin_hash TEXT NOT NULL DEFAULT ''," +
                "active INTEGER NOT NULL DEFAULT 1," +
                "server_id INTEGER," +
                "local_only INTEGER NOT NULL DEFAULT 1," +
                "created_at TEXT NOT NULL," +
                "updated_at TEXT NOT NULL)");
        try { db.execSQL("ALTER TABLE app_users ADD COLUMN server_id INTEGER"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE app_users ADD COLUMN local_only INTEGER DEFAULT 1"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_app_users_name ON app_users(lastname,firstname,username)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_app_users_active ON app_users(active)");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_app_users_server_id ON app_users(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE TABLE IF NOT EXISTS mobile_user_ops(op_uuid TEXT PRIMARY KEY,local_user_id INTEGER NOT NULL,server_id INTEGER DEFAULT 0,action TEXT NOT NULL DEFAULT 'UPSERT',firstname TEXT,lastname TEXT,username TEXT,role INTEGER DEFAULT 2,active INTEGER DEFAULT 1,password_md5 TEXT,created_at TEXT NOT NULL)"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mobile_user_local ON mobile_user_ops(local_user_id)"); } catch (Exception ignored) {}

        Cursor c = db.rawQuery("SELECT COUNT(*) FROM app_users", null);
        int count = c.moveToFirst() ? c.getInt(0) : 0;
        c.close();
        if (count == 0) {
            ContentValues v = new ContentValues();
            v.put("firstname", "Administrateur");
            v.put("lastname", "");
            v.put("username", "admin");
            v.put("role", 1);
            v.put("pin_hash", "");
            v.put("active", 1);
            v.put("local_only", 1);
            v.put("created_at", now());
            v.put("updated_at", now());
            db.insert("app_users", null, v);
        }
    }

    private void createPayrollTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS salaries(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER UNIQUE,matricule TEXT UNIQUE,nom TEXT NOT NULL,telephone TEXT,email TEXT,address TEXT," +
                "salaire_base REAL DEFAULT 0,allocation_repas_jour REAL DEFAULT 0,jours_repas_defaut REAL DEFAULT 26,actif INTEGER DEFAULT 1,local_only INTEGER DEFAULT 1,created_at TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS avances(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER,salarie_id INTEGER NOT NULL,date_avance TEXT NOT NULL,montant REAL NOT NULL DEFAULT 0,remarque TEXT,created_at TEXT," +
                "FOREIGN KEY(salarie_id) REFERENCES salaries(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE IF NOT EXISTS paies(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER,salarie_id INTEGER NOT NULL,mois_paie TEXT NOT NULL,periode_debut TEXT NOT NULL,periode_fin TEXT NOT NULL," +
                "salaire_base REAL NOT NULL DEFAULT 0,jours_travailles REAL DEFAULT 0,allocation_repas_jour REAL DEFAULT 0,jours_repas REAL DEFAULT 0," +
                "allocation_repas_total REAL DEFAULT 0,avance REAL DEFAULT 0,net_a_payer REAL DEFAULT 0,remarque TEXT,created_at TEXT,updated_at TEXT," +
                "UNIQUE(salarie_id,periode_debut,periode_fin),FOREIGN KEY(salarie_id) REFERENCES salaries(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE IF NOT EXISTS paie_paiements(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER,paie_id INTEGER NOT NULL,montant REAL NOT NULL DEFAULT 0,date_paiement TEXT NOT NULL," +
                "mode_paiement TEXT NOT NULL DEFAULT 'ESPECES',reference TEXT,remarque TEXT,created_at TEXT," +
                "FOREIGN KEY(paie_id) REFERENCES paies(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE IF NOT EXISTS mobile_salary_ops(op_uuid TEXT PRIMARY KEY,local_salary_id INTEGER NOT NULL,matricule TEXT,nom TEXT NOT NULL,telephone TEXT,email TEXT,address TEXT,salaire_base REAL DEFAULT 0,allocation_repas_jour REAL DEFAULT 0,jours_repas_defaut REAL DEFAULT 26,actif INTEGER DEFAULT 1,created_at TEXT NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_salaries_nom ON salaries(nom)");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_salaries_server_id ON salaries(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_avances_salarie_date ON avances(salarie_id,date_avance)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_paies_mois ON paies(mois_paie)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_paie_paiements_paie ON paie_paiements(paie_id)");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_avances_server_id ON avances(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paies_server_id ON paies(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paie_paiements_server_id ON paie_paiements(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
    }

    /**
     * V10 : une paie est unique par salarié + période réelle, et non plus par mois.
     * La migration reconstruit paies + paie_paiements en conservant les IDs afin
     * de préserver tous les paiements partiels existants.
     */
    private void migratePayrollPeriodUniquenessV10(SQLiteDatabase db) {
        Cursor schema = null;
        boolean oldMonthlyUnique = false;
        try {
            schema = db.rawQuery(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name='paies' LIMIT 1",
                    null
            );
            if (schema.moveToFirst()) {
                String sql = schema.getString(0);
                if (sql != null) {
                    String compact = sql.replace(" ", "").replace("\n", "").toLowerCase(Locale.ROOT);
                    oldMonthlyUnique = compact.contains("unique(salarie_id,mois_paie)");
                }
            }
        } finally {
            if (schema != null) schema.close();
        }

        if (!oldMonthlyUnique) {
            try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paies_periode_unique ON paies(salarie_id,periode_debut,periode_fin)"); } catch (Exception ignored) {}
            return;
        }

        // Les indexes nommés suivent la table lors d'un RENAME et empêcheraient
        // leur recréation sur la nouvelle table : on les enlève avant reconstruction.
        try { db.execSQL("DROP INDEX IF EXISTS idx_paies_mois"); } catch (Exception ignored) {}
        try { db.execSQL("DROP INDEX IF EXISTS idx_paies_server_id"); } catch (Exception ignored) {}
        try { db.execSQL("DROP INDEX IF EXISTS idx_paie_paiements_paie"); } catch (Exception ignored) {}
        try { db.execSQL("DROP INDEX IF EXISTS idx_paie_paiements_server_id"); } catch (Exception ignored) {}

        db.execSQL("ALTER TABLE paie_paiements RENAME TO paie_paiements_v9");
        db.execSQL("ALTER TABLE paies RENAME TO paies_v9");

        db.execSQL("CREATE TABLE paies(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER,salarie_id INTEGER NOT NULL,mois_paie TEXT NOT NULL,periode_debut TEXT NOT NULL,periode_fin TEXT NOT NULL," +
                "salaire_base REAL NOT NULL DEFAULT 0,jours_travailles REAL DEFAULT 0,allocation_repas_jour REAL DEFAULT 0,jours_repas REAL DEFAULT 0," +
                "allocation_repas_total REAL DEFAULT 0,avance REAL DEFAULT 0,net_a_payer REAL DEFAULT 0,remarque TEXT,created_at TEXT,updated_at TEXT," +
                "UNIQUE(salarie_id,periode_debut,periode_fin),FOREIGN KEY(salarie_id) REFERENCES salaries(id) ON DELETE CASCADE)");

        db.execSQL("INSERT INTO paies(" +
                "id,server_id,salarie_id,mois_paie,periode_debut,periode_fin,salaire_base,jours_travailles,allocation_repas_jour,jours_repas," +
                "allocation_repas_total,avance,net_a_payer,remarque,created_at,updated_at" +
                ") SELECT id,server_id,salarie_id,mois_paie,periode_debut,periode_fin,salaire_base,jours_travailles,allocation_repas_jour,jours_repas," +
                "allocation_repas_total,avance,net_a_payer,remarque,created_at,updated_at FROM paies_v9");

        db.execSQL("CREATE TABLE paie_paiements(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER,paie_id INTEGER NOT NULL,montant REAL NOT NULL DEFAULT 0,date_paiement TEXT NOT NULL," +
                "mode_paiement TEXT NOT NULL DEFAULT 'ESPECES',reference TEXT,remarque TEXT,created_at TEXT," +
                "FOREIGN KEY(paie_id) REFERENCES paies(id) ON DELETE CASCADE)");

        db.execSQL("INSERT INTO paie_paiements(" +
                "id,server_id,paie_id,montant,date_paiement,mode_paiement,reference,remarque,created_at" +
                ") SELECT id,server_id,paie_id,montant,date_paiement,mode_paiement,reference,remarque,created_at FROM paie_paiements_v9");

        db.execSQL("DROP TABLE paie_paiements_v9");
        db.execSQL("DROP TABLE paies_v9");

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_paies_mois ON paies(mois_paie)");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paies_periode_unique ON paies(salarie_id,periode_debut,periode_fin)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_paie_paiements_paie ON paie_paiements(paie_id)");
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paies_server_id ON paies(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
        try { db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_paie_paiements_server_id ON paie_paiements(server_id) WHERE server_id IS NOT NULL"); } catch (Exception ignored) {}
    }

    private void createPackTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS packs(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,server_id INTEGER UNIQUE,nom TEXT NOT NULL,description TEXT,slogan TEXT DEFAULT '',categorie TEXT DEFAULT 'Nouveau-né',prix_vente REAL DEFAULT 0," +
                "image_path TEXT DEFAULT '',logo_path TEXT DEFAULT '',whatsapp_number TEXT DEFAULT '',actif INTEGER DEFAULT 1,local_only INTEGER DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        try { db.execSQL("ALTER TABLE packs ADD COLUMN image_path TEXT DEFAULT ''"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE packs ADD COLUMN logo_path TEXT DEFAULT ''"); } catch (Exception ignored) {}
        try { db.execSQL("ALTER TABLE packs ADD COLUMN whatsapp_number TEXT DEFAULT ''"); } catch (Exception ignored) {}
        db.execSQL("CREATE TABLE IF NOT EXISTS pack_articles(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,pack_id INTEGER NOT NULL,groupe_code TEXT NOT NULL DEFAULT '',variante_id INTEGER,nom_article TEXT NOT NULL," +
                "quantite REAL DEFAULT 1,prix_unitaire REAL DEFAULT 0,ordre INTEGER DEFAULT 0," +
                "FOREIGN KEY(pack_id) REFERENCES packs(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pack_articles_pack ON pack_articles(pack_id,ordre,id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pack_articles_group ON pack_articles(pack_id,groupe_code,ordre,id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pack_articles_variant ON pack_articles(variante_id)");
    }

    private void seedNewbornPacks(SQLiteDatabase db) {
        createPackTables(db);
        if (DatabaseUtilsCompat.count(db, "packs") > 0) return;
        long classique = insertSeedPack(db, "Pack Nouveau-né Classique", 350000,
                "Essentiel pour bébé", "Nouveau-né",
                "Liste initiale du carnet. Les articles peuvent être modifiés, complétés et liés au stock au fur et à mesure.");
        seedPackItems(db, classique, new String[]{
                "Triangle|2", "Cape|3", "Couverture|1", "Pélisse|1", "Chaussons et moufles|1",
                "Bonnet|1", "Bavoir|1", "Baignoire|1", "Sortie de bain|1", "Lange|1", "Layette|1"
        });

        long confort = insertSeedPack(db, "Pack Nouveau-né Confort", 600000,
                "Plus de douceur pour bébé", "Nouveau-né",
                "Liste initiale du carnet. À ajuster librement selon les arrivages et les besoins du client.");
        seedPackItems(db, confort, new String[]{
                "Triangle|1", "Cape|2", "Couverture|1", "Pélisse|1", "Chaussons|1", "Bonnet|1",
                "Bavoir|1", "Baignoire|1", "Sortie de bain|1", "Lange|1", "Layette|1", "Mouchoir|1", "Biberon bébé|1"
        });

        long premium = insertSeedPack(db, "Pack Nouveau-né Premium", 850000,
                "Le plus complet pour bébé", "Nouveau-né",
                "Liste initiale du carnet. Complétez les vêtements et accessoires premium au fur et à mesure.");
        seedPackItems(db, premium, new String[]{
                "Triangle|1", "Cape|2", "Couverture|1", "Pélisse|1", "Chaussons|1", "Bonnet|1",
                "Bavoir|1", "Baignoire|1", "Sortie de bain|1", "Lange|1", "Layette|1"
        });
    }

    private long insertSeedPack(SQLiteDatabase db, String name, double price, String slogan, String categorie, String description) {
        ContentValues v = new ContentValues();
        v.put("nom", name); v.put("description", description); v.put("slogan", slogan); v.put("categorie", categorie); v.put("prix_vente", price); v.put("actif", 1);
        v.put("local_only", 0);
        v.put("created_at", now()); v.put("updated_at", now());
        return db.insertOrThrow("packs", null, v);
    }

    private void seedPackItems(SQLiteDatabase db, long packId, String[] rows) {
        int order = 1;
        for (String row : rows) {
            String[] parts = row.split("\\|", 2);
            ContentValues v = new ContentValues();
            v.put("pack_id", packId); v.put("groupe_code", "SEED_" + packId + "_" + order); v.put("nom_article", parts[0]);
            double qty = 1;
            if (parts.length > 1) try { qty = Double.parseDouble(parts[1]); } catch (Exception ignored) {}
            v.put("quantite", qty); v.put("prix_unitaire", 0); v.put("ordre", order++);
            db.insertOrThrow("pack_articles", null, v);
        }
    }

    private void seedEmplacements(SQLiteDatabase db) {
        if (DatabaseUtilsCompat.count(db, "emplacements") == 0) {
            db.execSQL("INSERT INTO emplacements(id,nom) VALUES(1,'Tsena'),(2,'Depot'),(3,'Home')");
        }
    }

    public Cursor emplacements() {
        // Tsena doit toujours apparaître en premier dans tous les sélecteurs d'emplacement.
        return getReadableDatabase().rawQuery(
                "SELECT id,nom FROM emplacements " +
                "ORDER BY CASE WHEN LOWER(TRIM(nom))='tsena' THEN 0 ELSE 1 END, id", null);
    }

    /**
     * Emplacement par défaut global de l'application.
     * On recherche Tsena par son nom afin de rester correct même si son ID serveur change.
     */
    public long defaultEmplacementId() {
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery(
                    "SELECT id FROM emplacements " +
                    "ORDER BY CASE WHEN LOWER(TRIM(nom))='tsena' THEN 0 ELSE 1 END, id LIMIT 1", null);
            if (c.moveToFirst()) return c.getLong(0);
        } finally {
            if (c != null) c.close();
        }
        return 1L;
    }

    public Cursor clients() {
        return getReadableDatabase().rawQuery("SELECT id,server_id,fullname,COALESCE(contact,''),COALESCE(address,''),local_only FROM clients ORDER BY fullname", null);
    }

    public synchronized long addLocalClient(String name, String contact) {
        return addLocalClient(name, contact, "");
    }

    public synchronized long addLocalClient(String name, String contact, String address) {
        String fullName = name == null ? "" : name.trim();
        if (fullName.isEmpty()) throw new IllegalArgumentException("Nom complet obligatoire.");
        String phone = contact == null ? "" : contact.trim();
        String addr = address == null ? "" : address.trim();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("fullname", fullName);
            v.put("contact", phone);
            v.put("address", addr);
            v.put("local_only", 1);
            long id = db.insertOrThrow("clients", null, v);

            ContentValues op = new ContentValues();
            op.put("op_uuid", UUID.randomUUID().toString());
            op.put("local_client_id", id);
            op.put("fullname", fullName);
            op.put("contact", phone);
            op.put("address", addr);
            op.put("created_at", now());
            db.insertOrThrow("mobile_client_ops", null, op);
            db.setTransactionSuccessful();
            return id;
        } finally { db.endTransaction(); }
    }

    public synchronized void updateLocalClient(long clientId, String name, String contact, String address) {
        String fullName = name == null ? "" : name.trim();
        if (clientId <= 0) throw new IllegalArgumentException("Client invalide.");
        if (fullName.isEmpty()) throw new IllegalArgumentException("Nom complet obligatoire.");
        String phone = contact == null ? "" : contact.trim();
        String addr = address == null ? "" : address.trim();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor current = db.rawQuery("SELECT id FROM clients WHERE id=?", new String[]{String.valueOf(clientId)});
            boolean exists = current.moveToFirst();
            current.close();
            if (!exists) throw new IllegalArgumentException("Client introuvable.");

            ContentValues v = new ContentValues();
            v.put("fullname", fullName);
            v.put("contact", phone);
            v.put("address", addr);
            v.put("local_only", 1);
            db.update("clients", v, "id=?", new String[]{String.valueOf(clientId)});

            // On ne garde qu'une opération client par client avec les dernières valeurs.
            db.delete("mobile_client_ops", "local_client_id=?", new String[]{String.valueOf(clientId)});
            ContentValues op = new ContentValues();
            op.put("op_uuid", UUID.randomUUID().toString());
            op.put("local_client_id", clientId);
            op.put("fullname", fullName);
            op.put("contact", phone);
            op.put("address", addr);
            op.put("created_at", now());
            db.insertOrThrow("mobile_client_ops", null, op);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    /**
     * Liste de gestion du catalogue SQLite. Les produits locaux ont un ID négatif.
     * local_dirty=1 protège les créations/modifications locales pendant un pull catalogue.
     */
    public Cursor productsManage(String q) {
        String term = q == null ? "" : q.trim();
        String like = "%" + term + "%";
        return getReadableDatabase().rawQuery(
                "SELECT p.id,p.name,COALESCE(p.price,0),COALESCE(p.status,1),COALESCE(p.image_url,'')," +
                "COALESCE(p.local_dirty,0),COUNT(DISTINCT v.id),COALESCE(SUM(COALESCE(st.quantite,0)),0) " +
                "FROM produits p LEFT JOIN variantes v ON v.service_id=p.id " +
                "LEFT JOIN stocks st ON st.variante_id=v.id " +
                "WHERE (?='' OR p.name LIKE ?) " +
                "GROUP BY p.id,p.name,p.price,p.status,p.image_url,p.local_dirty " +
                "ORDER BY COALESCE(p.status,1) DESC,p.name COLLATE NOCASE",
                new String[]{term, like});
    }

    public Cursor productById(long productId) {
        return getReadableDatabase().rawQuery(
                "SELECT id,name,COALESCE(price,0),COALESCE(status,1),COALESCE(image_url,''),COALESCE(local_dirty,0) " +
                "FROM produits WHERE id=? LIMIT 1",
                new String[]{String.valueOf(productId)});
    }

    public synchronized long createLocalProduct(String name, double price, String imageUrl,
                                                boolean active, boolean createDefaultVariant,
                                                double initialQty) throws Exception {
        String productName = safe(name);
        if (productName.isEmpty()) throw new Exception("Nom du produit obligatoire.");
        if (price < 0) throw new Exception("Prix invalide.");
        initialQty = roundHalf(initialQty);
        if (initialQty < 0) throw new Exception("Stock initial invalide.");

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor duplicate = db.rawQuery(
                    "SELECT id FROM produits WHERE LOWER(TRIM(name))=LOWER(TRIM(?)) LIMIT 1",
                    new String[]{productName});
            boolean exists = duplicate.moveToFirst();
            duplicate.close();
            if (exists) throw new Exception("Un produit avec ce nom existe déjà.");

            long productId = nextLocalProductId(db);
            ContentValues v = new ContentValues();
            v.put("id", productId);
            v.put("name", productName);
            v.put("price", Math.max(0, price));
            v.put("status", active ? 1 : 0);
            v.put("image_url", safe(imageUrl));
            v.put("local_dirty", 1);
            v.put("local_updated_at", now());
            db.insertOrThrow("produits", null, v);

            if (createDefaultVariant) {
                long variantId = nextLocalVariantId(db);
                ContentValues vv = new ContentValues();
                vv.put("id", variantId);
                vv.put("service_id", productId);
                vv.put("couleur", "");
                vv.put("taille", "");
                vv.put("code_barre", "");
                // 0 => le POS utilise automatiquement le prix du produit.
                vv.put("prix", 0);
                vv.put("image_url", safe(imageUrl));
                db.insertOrThrow("variantes", null, vv);

                if (initialQty > 0) {
                    ContentValues st = new ContentValues();
                    st.put("variante_id", variantId);
                    st.put("emplacement_id", defaultEmplacementId());
                    st.put("quantite", initialQty);
                    db.insertOrThrow("stocks", null, st);
                }
            }

            db.setTransactionSuccessful();
            return productId;
        } finally {
            db.endTransaction();
        }
    }

    public synchronized void updateLocalProduct(long productId, String name, double price,
                                                String imageUrl, boolean active) throws Exception {
        if (productId == 0) throw new Exception("Produit invalide.");
        String productName = safe(name);
        if (productName.isEmpty()) throw new Exception("Nom du produit obligatoire.");
        if (price < 0) throw new Exception("Prix invalide.");

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor exists = db.rawQuery("SELECT id FROM produits WHERE id=? LIMIT 1",
                    new String[]{String.valueOf(productId)});
            boolean ok = exists.moveToFirst();
            exists.close();
            if (!ok) throw new Exception("Produit introuvable.");

            Cursor duplicate = db.rawQuery(
                    "SELECT id FROM produits WHERE id<>? AND LOWER(TRIM(name))=LOWER(TRIM(?)) LIMIT 1",
                    new String[]{String.valueOf(productId), productName});
            boolean dup = duplicate.moveToFirst();
            duplicate.close();
            if (dup) throw new Exception("Un autre produit porte déjà ce nom.");

            ContentValues v = new ContentValues();
            v.put("name", productName);
            v.put("price", Math.max(0, price));
            v.put("status", active ? 1 : 0);
            v.put("image_url", safe(imageUrl));
            v.put("local_dirty", 1);
            v.put("local_updated_at", now());
            if (db.update("produits", v, "id=?", new String[]{String.valueOf(productId)}) < 1) {
                throw new Exception("Modification du produit impossible.");
            }

            // Les variantes qui réutilisent l'image produit gardent leur propre image si elle existe.
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public synchronized void ensureDefaultVariantForLocalProduct(long productId, double initialQty) throws Exception {
        initialQty = roundHalf(initialQty);
        if (initialQty < 0) throw new Exception("Stock initial invalide.");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor p = db.rawQuery("SELECT id,image_url FROM produits WHERE id=? LIMIT 1",
                    new String[]{String.valueOf(productId)});
            if (!p.moveToFirst()) { p.close(); throw new Exception("Produit introuvable."); }
            String image = p.getString(1); p.close();

            Cursor c = db.rawQuery("SELECT id FROM variantes WHERE service_id=? LIMIT 1",
                    new String[]{String.valueOf(productId)});
            if (c.moveToFirst()) { c.close(); throw new Exception("Ce produit possède déjà une variante."); }
            c.close();

            long variantId = nextLocalVariantId(db);
            ContentValues vv = new ContentValues();
            vv.put("id", variantId); vv.put("service_id", productId); vv.put("couleur", ""); vv.put("taille", "");
            vv.put("code_barre", ""); vv.put("prix", 0); vv.put("image_url", safe(image));
            db.insertOrThrow("variantes", null, vv);
            if (initialQty > 0) {
                ContentValues st = new ContentValues();
                st.put("variante_id", variantId); st.put("emplacement_id", defaultEmplacementId()); st.put("quantite", initialQty);
                db.insertOrThrow("stocks", null, st);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private long nextLocalProductId(SQLiteDatabase db) {
        Cursor c = db.rawQuery("SELECT MIN(id) FROM produits", null);
        long id = -1;
        if (c.moveToFirst() && !c.isNull(0)) {
            long min = c.getLong(0);
            id = min <= 0 ? min - 1 : -1;
        }
        c.close();
        return id;
    }

    public Cursor productsSimple() {
        return getReadableDatabase().rawQuery(
                "SELECT id,name,COALESCE(price,0),COALESCE(image_url,'') FROM produits WHERE status=1 ORDER BY name", null);
    }

    public Cursor searchVariants(String q, long empId, int limit) {
        String term = q == null ? "" : q.trim();
        String like = "%" + term + "%";
        return getReadableDatabase().rawQuery(
            "SELECT v.id AS variante_id,p.name AS produit,COALESCE(v.couleur,'') couleur,COALESCE(v.taille,'') taille," +
            "COALESCE(v.code_barre,'') code_barre,CASE WHEN COALESCE(v.prix,0)>0 THEN v.prix ELSE p.price END prix_vente," +
            "COALESCE(s.quantite,0) stock_disponible,p.id AS product_id,COALESCE(NULLIF(v.image_url,''),NULLIF(p.image_url,''),'') AS image_url " +
            "FROM variantes v JOIN produits p ON p.id=v.service_id " +
            "LEFT JOIN stocks s ON s.variante_id=v.id AND s.emplacement_id=? " +
            "WHERE p.status=1 AND (?='' OR p.name LIKE ? OR COALESCE(v.couleur,'') LIKE ? OR COALESCE(v.taille,'') LIKE ? OR COALESCE(v.code_barre,'') LIKE ?) " +
            "ORDER BY p.name,v.couleur,v.taille LIMIT " + Math.max(1, Math.min(200, limit)),
            new String[]{String.valueOf(empId), term, like, like, like, like});
    }


    /**
     * Recherche dédiée aux packs : le stock affiché est UNIQUEMENT celui de Tsena.
     * On passe par le nom de l'emplacement afin de rester correct même si son ID
     * change après une synchronisation MySQL -> SQLite.
     * Les variantes à stock 0 à Tsena restent visibles et sélectionnables.
     */
    public Cursor searchPackVariants(String q, int limit) {
        String term = q == null ? "" : q.trim();
        String like = "%" + term + "%";
        int safeLimit = Math.max(1, Math.min(300, limit));
        return getReadableDatabase().rawQuery(
                "SELECT v.id AS variante_id,p.name AS produit,COALESCE(v.couleur,'') couleur,COALESCE(v.taille,'') taille," +
                "COALESCE(v.code_barre,'') code_barre,CASE WHEN COALESCE(v.prix,0)>0 THEN v.prix ELSE p.price END prix_vente," +
                "COALESCE((SELECT SUM(COALESCE(st.quantite,0)) FROM stocks st " +
                "JOIN emplacements e ON e.id=st.emplacement_id " +
                "WHERE st.variante_id=v.id AND LOWER(TRIM(e.nom))='tsena'),0) stock_tsena,p.id AS product_id," +
                "COALESCE(NULLIF(v.image_url,''),NULLIF(p.image_url,''),'') AS image_url " +
                "FROM variantes v JOIN produits p ON p.id=v.service_id " +
                "WHERE p.status=1 AND (?='' OR p.name LIKE ? OR COALESCE(v.couleur,'') LIKE ? OR " +
                "COALESCE(v.taille,'') LIKE ? OR COALESCE(v.code_barre,'') LIKE ?) " +
                "ORDER BY p.name,v.couleur,v.taille,v.id LIMIT " + safeLimit,
                new String[]{term, like, like, like, like}
        );
    }

    public boolean packVariantExists(long variantId) {
        if (variantId <= 0) return false;
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT 1 FROM variantes WHERE id=? LIMIT 1",
                new String[]{String.valueOf(variantId)}
        );
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    public String packVariantLabel(long variantId) {
        if (variantId <= 0) return "";
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT p.name,COALESCE(v.couleur,''),COALESCE(v.taille,''),COALESCE(v.code_barre,'')," +
                "COALESCE((SELECT SUM(st.quantite) FROM stocks st WHERE st.variante_id=v.id),0) " +
                "FROM variantes v JOIN produits p ON p.id=v.service_id WHERE v.id=? LIMIT 1",
                new String[]{String.valueOf(variantId)}
        );
        if (!c.moveToFirst()) {
            c.close();
            return "";
        }
        StringBuilder out = new StringBuilder(c.getString(0));
        String color = c.getString(1);
        String size = c.getString(2);
        String code = c.getString(3);
        double stock = c.getDouble(4);
        if (color != null && !color.trim().isEmpty()) out.append(" • ").append(color);
        if (size != null && !size.trim().isEmpty()) out.append(" • taille ").append(size);
        if (code != null && !code.trim().isEmpty()) out.append(" • ").append(code);
        out.append(" • stock total ").append(packQtyText(stock));
        c.close();
        return out.toString();
    }

    private String packQtyText(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.00001) return String.valueOf((long)Math.rint(value));
        return String.format(java.util.Locale.FRANCE, "%.1f", value);
    }

    public Cursor searchProducts(String q, long empId, int limit) {
        String term = q == null ? "" : q.trim();
        String like = "%" + term + "%";
        return getReadableDatabase().rawQuery(
            "SELECT p.id,p.name,COUNT(DISTINCT v.id) variant_count,COALESCE(SUM(COALESCE(s.quantite,0)),0) total_stock," +
            "COALESCE(NULLIF(p.image_url,''),'') image_url " +
            "FROM produits p " +
            "LEFT JOIN variantes v ON v.service_id=p.id " +
            "LEFT JOIN stocks s ON s.variante_id=v.id AND s.emplacement_id=? " +
            "WHERE p.status=1 AND (?='' OR p.name LIKE ? OR EXISTS (" +
            "SELECT 1 FROM variantes vv WHERE vv.service_id=p.id AND (COALESCE(vv.couleur,'') LIKE ? OR COALESCE(vv.taille,'') LIKE ? OR COALESCE(vv.code_barre,'') LIKE ?))) " +
            "GROUP BY p.id,p.name,p.image_url " +
            "ORDER BY p.name LIMIT " + Math.max(1, Math.min(200, limit)),
            new String[]{String.valueOf(empId), term, like, like, like, like}
        );
    }

    public Cursor variantsByProduct(long productId, long empId, int limit) {
        return getReadableDatabase().rawQuery(
            "SELECT v.id AS variante_id,p.name AS produit,COALESCE(v.couleur,'') couleur,COALESCE(v.taille,'') taille," +
            "COALESCE(v.code_barre,'') code_barre,CASE WHEN COALESCE(v.prix,0)>0 THEN v.prix ELSE p.price END prix_vente," +
            "COALESCE(s.quantite,0) stock_disponible,p.id AS product_id,COALESCE(NULLIF(v.image_url,''),NULLIF(p.image_url,''),'') AS image_url " +
            "FROM variantes v JOIN produits p ON p.id=v.service_id " +
            "LEFT JOIN stocks s ON s.variante_id=v.id AND s.emplacement_id=? " +
            "WHERE p.status=1 AND p.id=? " +
            "ORDER BY v.couleur,v.taille LIMIT " + Math.max(1, Math.min(200, limit)),
            new String[]{String.valueOf(empId), String.valueOf(productId)}
        );
    }

    public Cursor stock(String q, long empId) { return searchVariants(q, empId, 500); }

    public synchronized long addStock(long varianteId, long emplacementId, double qtyToAdd) throws Exception {
        qtyToAdd = roundHalf(qtyToAdd);
        if (qtyToAdd <= 0) throw new Exception("Quantité invalide.");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor c = db.rawQuery("SELECT quantite FROM stocks WHERE variante_id=? AND emplacement_id=?",
                    new String[]{String.valueOf(varianteId), String.valueOf(emplacementId)});
            if (c.moveToFirst()) {
                db.execSQL("UPDATE stocks SET quantite=quantite+? WHERE variante_id=? AND emplacement_id=?",
                        new Object[]{qtyToAdd, varianteId, emplacementId});
            } else {
                ContentValues v = new ContentValues();
                v.put("variante_id", varianteId);
                v.put("emplacement_id", emplacementId);
                v.put("quantite", qtyToAdd);
                db.insertOrThrow("stocks", null, v);
            }
            c.close();
            if (isVariantSyncable(db, varianteId)) {
                ContentValues op = new ContentValues();
                op.put("op_uuid", UUID.randomUUID().toString());
                op.put("variante_id", varianteId);
                op.put("emplacement_id", emplacementId);
                op.put("quantite", qtyToAdd);
                op.put("created_at", now());
                db.insertOrThrow("mobile_stock_ops", null, op);
            }
            db.setTransactionSuccessful();
            return varianteId;
        } finally { db.endTransaction(); }
    }

    public synchronized long createVariant(long productId, String couleur, String taille, String codeBarre,
                                           double prix, double initialQty, long emplacementId, String imageUrl) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor p = db.rawQuery("SELECT COUNT(*) FROM produits WHERE id=?", new String[]{String.valueOf(productId)});
            boolean ok = p.moveToFirst() && p.getLong(0) > 0;
            p.close();
            if (!ok) throw new Exception("Produit introuvable.");

            long variantId = nextLocalVariantId(db);
            ContentValues v = new ContentValues();
            v.put("id", variantId);
            v.put("service_id", productId);
            v.put("couleur", safe(couleur));
            v.put("taille", safe(taille));
            v.put("code_barre", safe(codeBarre));
            v.put("prix", Math.max(0, prix));
            v.put("image_url", safe(imageUrl));
            db.insertOrThrow("variantes", null, v);

            if (productId > 0) {
                ContentValues vop = new ContentValues();
                vop.put("op_uuid", UUID.randomUUID().toString());
                vop.put("local_variant_id", variantId);
                vop.put("service_id", productId);
                vop.put("couleur", safe(couleur));
                vop.put("taille", safe(taille));
                vop.put("code_barre", safe(codeBarre));
                vop.put("prix", Math.max(0, prix));
                vop.put("image_url", safe(imageUrl));
                vop.put("created_at", now());
                db.insertOrThrow("mobile_variant_ops", null, vop);
            }

            if (initialQty > 0) {
                double q = roundHalf(initialQty);
                ContentValues s = new ContentValues();
                s.put("variante_id", variantId);
                s.put("emplacement_id", emplacementId);
                s.put("quantite", q);
                db.insertOrThrow("stocks", null, s);

                if (productId > 0) {
                    ContentValues sop = new ContentValues();
                    sop.put("op_uuid", UUID.randomUUID().toString());
                    sop.put("variante_id", variantId);
                    sop.put("emplacement_id", emplacementId);
                    sop.put("quantite", q);
                    sop.put("created_at", now());
                    db.insertOrThrow("mobile_stock_ops", null, sop);
                }
            }

            db.setTransactionSuccessful();
            return variantId;
        } finally { db.endTransaction(); }
    }

    public synchronized void moveVariantProduct(long variantId, long newProductId) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor product = db.rawQuery(
                    "SELECT id FROM produits WHERE id=? AND COALESCE(status,1)=1 LIMIT 1",
                    new String[]{String.valueOf(newProductId)});
            boolean productOk = product.moveToFirst();
            product.close();
            if (!productOk) throw new Exception("Produit destination introuvable.");

            Cursor cur = db.rawQuery(
                    "SELECT service_id,COALESCE(couleur,''),COALESCE(taille,''),COALESCE(code_barre,''),COALESCE(prix,0),COALESCE(image_url,'') " +
                    "FROM variantes WHERE id=? LIMIT 1",
                    new String[]{String.valueOf(variantId)});
            if (!cur.moveToFirst()) {
                cur.close();
                throw new Exception("Variante introuvable.");
            }

            long oldProductId = cur.getLong(0);
            String couleur = cur.getString(1);
            String taille = cur.getString(2);
            String code = cur.getString(3);
            double prix = cur.getDouble(4);
            String image = cur.getString(5);
            cur.close();

            if (oldProductId == newProductId) {
                throw new Exception("Cette variante appartient déjà à ce produit.");
            }
            if (newProductId < 0 && variantId > 0) {
                throw new Exception("Une variante déjà liée au serveur ne peut pas être déplacée vers un produit SQLite local. Créez une nouvelle variante locale pour ce produit.");
            }

            Cursor dup = db.rawQuery(
                    "SELECT id FROM variantes WHERE service_id=? AND id<>? " +
                    "AND LOWER(TRIM(COALESCE(couleur,'')))=LOWER(TRIM(?)) " +
                    "AND LOWER(TRIM(COALESCE(taille,'')))=LOWER(TRIM(?)) LIMIT 1",
                    new String[]{String.valueOf(newProductId), String.valueOf(variantId), couleur, taille});
            boolean duplicate = dup.moveToFirst();
            dup.close();
            if (duplicate) {
                throw new Exception("Une variante avec la même couleur et la même taille existe déjà dans ce produit.");
            }

            ContentValues values = new ContentValues();
            values.put("service_id", newProductId);
            int changed = db.update("variantes", values, "id=?", new String[]{String.valueOf(variantId)});
            if (changed < 1) throw new Exception("Déplacement de la variante impossible.");

            // Une seule opération en attente par variante. Pour un ID positif, le serveur
            // l'interprète comme une modification. Pour un ID négatif, il reste une création locale.
            db.delete("mobile_variant_ops", "local_variant_id=?", new String[]{String.valueOf(variantId)});

            if (newProductId > 0) {
                ContentValues op = new ContentValues();
                op.put("op_uuid", UUID.randomUUID().toString());
                op.put("local_variant_id", variantId);
                op.put("service_id", newProductId);
                op.put("couleur", safe(couleur));
                op.put("taille", safe(taille));
                op.put("code_barre", safe(code));
                op.put("prix", Math.max(0, prix));
                op.put("image_url", safe(image));
                op.put("created_at", now());
                db.insertOrThrow("mobile_variant_ops", null, op);
            }

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private boolean isVariantSyncable(SQLiteDatabase db, long variantId) {
        Cursor c = db.rawQuery("SELECT service_id FROM variantes WHERE id=? LIMIT 1",
                new String[]{String.valueOf(variantId)});
        boolean syncable = c.moveToFirst() && c.getLong(0) > 0;
        c.close();
        return syncable;
    }

    private long nextLocalVariantId(SQLiteDatabase db) {
        Cursor c = db.rawQuery("SELECT MIN(id) FROM variantes", null);
        long id = -1;
        if (c.moveToFirst() && !c.isNull(0)) {
            long min = c.getLong(0);
            id = min <= 0 ? min - 1 : -1;
        }
        c.close();
        return id;
    }

    private static String safe(String v) {
        return v == null ? "" : v.trim();
    }

    public synchronized long saveDraft(long currentDraftId, JSONObject h, JSONArray lines) throws Exception {
        if (lines == null || lines.length() == 0) throw new Exception("Panier vide.");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long draftId = currentDraftId;
            String now = now();
            if (draftId > 0) {
                ContentValues v = new ContentValues();
                fillDraftValues(v, h, now, false);
                db.update("pos_drafts", v, "id=?", new String[]{String.valueOf(draftId)});
                db.delete("pos_draft_lines", "draft_id=?", new String[]{String.valueOf(draftId)});
            } else {
                ContentValues v = new ContentValues();
                v.put("draft_code", "ATT-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new Date()));
                fillDraftValues(v, h, now, true);
                draftId = db.insertOrThrow("pos_drafts", null, v);
            }
            for (int i = 0; i < lines.length(); i++) {
                JSONObject x = lines.getJSONObject(i);
                ContentValues lv = new ContentValues();
                lv.put("draft_id", draftId);
                lv.put("variante_id", x.getLong("variante_id"));
                lv.put("designation", x.optString("designation", ""));
                lv.put("quantite", roundHalf(x.optDouble("quantite", 0)));
                lv.put("prix_unitaire", Math.max(0, x.optDouble("prix", 0)));
                db.insertOrThrow("pos_draft_lines", null, lv);
            }
            db.setTransactionSuccessful();
            return draftId;
        } finally { db.endTransaction(); }
    }

    private void fillDraftValues(ContentValues v, JSONObject h, String now, boolean includeCreated) {
        if (includeCreated) v.put("created_at", now);
        v.put("updated_at", now);
        if (!h.isNull("client_id") && h.optLong("client_id", 0) > 0) v.put("client_id", h.optLong("client_id", 0));
        else v.putNull("client_id");
        v.put("emplacement_id", h.optLong("emplacement_id", defaultEmplacementId()));
        v.put("remise", h.optDouble("remise", 0));
        v.put("taux_tva", h.optDouble("taux_tva", 0));
        v.put("frais_livraison", h.optDouble("frais_livraison", 0));
        v.put("montant_recu", h.optDouble("montant_recu", 0));
        v.put("mode_paiement", h.optString("mode_paiement", "ESPECES"));
        v.put("statut_paiement", normalizeStatus(h.optString("statut_paiement", "")));
        v.put("commentaire", h.optString("commentaire", ""));
    }

    public Cursor draftHistory() {
        return getReadableDatabase().rawQuery(
                "SELECT d.id,d.draft_code,d.updated_at,COUNT(l.id) item_count,COALESCE(SUM(l.quantite*l.prix_unitaire),0) amount " +
                "FROM pos_drafts d LEFT JOIN pos_draft_lines l ON l.draft_id=d.id " +
                "GROUP BY d.id,d.draft_code,d.updated_at ORDER BY d.updated_at DESC", null);
    }

    public JSONObject draftHeader(long draftId) throws Exception {
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM pos_drafts WHERE id=?",
                new String[]{String.valueOf(draftId)});
        if (!c.moveToFirst()) { c.close(); throw new Exception("Vente en attente introuvable"); }
        JSONObject o = cursorObject(c);
        c.close();
        return o;
    }

    public JSONArray draftLines(long draftId) throws Exception {
        JSONArray lines = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT variante_id,designation,quantite,prix_unitaire AS prix FROM pos_draft_lines WHERE draft_id=? ORDER BY id",
                new String[]{String.valueOf(draftId)});
        while (c.moveToNext()) lines.put(cursorObject(c));
        c.close();
        return lines;
    }

    public void deleteDraft(long draftId) {
        getWritableDatabase().delete("pos_drafts", "id=?", new String[]{String.valueOf(draftId)});
    }

    public synchronized long saveSale(JSONObject h, JSONArray lines) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            if (lines.length() == 0) throw new Exception("Panier vide.");
            double subtotal = 0;
            boolean localOnlySale = false;
            for (int i=0;i<lines.length();i++) {
                JSONObject x = lines.getJSONObject(i);
                long vid = x.getLong("variante_id");
                if (!isVariantSyncable(db, vid)) localOnlySale = true;
                double qty = roundHalf(x.getDouble("quantite"));
                double price = Math.max(0, x.getDouble("prix"));
                if (qty < 0.5) throw new Exception("Quantité minimale : 0,5.");
                Cursor c = db.rawQuery("SELECT COALESCE(quantite,0) q FROM stocks WHERE variante_id=? AND emplacement_id=?",
                        new String[]{String.valueOf(vid), String.valueOf(h.getLong("emplacement_id"))});
                double stock = c.moveToFirst() ? c.getDouble(0) : 0;
                c.close();
                if (qty > stock + 0.00001) throw new Exception("Stock insuffisant pour " + x.optString("designation"));
                subtotal += qty * price;
                x.put("quantite", qty);
                x.put("total_ligne", round2(qty * price));
            }
            subtotal = round2(subtotal);
            double remise = Math.min(subtotal, Math.max(0, h.optDouble("remise",0)));
            double tva = Math.max(0, Math.min(100, h.optDouble("taux_tva",0)));
            double mtva = round2(subtotal * tva / 100.0);
            double livraison = Math.max(0, h.optDouble("frais_livraison",0));
            double total = round2(Math.max(0, subtotal + mtva - remise + livraison));
            double received = Math.max(0, h.optDouble("montant_recu",0));
            String status = normalizeStatus(h.optString("statut_paiement",""));
            if (received <= 0.00001) status = "EN_ATTENTE";
            else if (received + 0.00001 < total) status = "PARTIEL";
            else status = "PAYE";

            String uuid = UUID.randomUUID().toString();
            String num = "MOB-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new Date()) +
                    "-" + uuid.substring(0,6).toUpperCase(Locale.ROOT);

            ContentValues v = new ContentValues();
            v.put("uuid", uuid); v.put("num_vente", num); v.put("date_vente", now());
            if (!h.isNull("client_id") && h.optLong("client_id",0)>0) v.put("client_id", h.optLong("client_id"));
            v.put("emplacement_id", h.getLong("emplacement_id"));
            v.put("sous_total", subtotal); v.put("remise", remise); v.put("taux_tva", tva);
            v.put("montant_tva", mtva); v.put("frais_livraison", livraison); v.put("montant_total", total);
            v.put("montant_recu", received); v.put("monnaie_rendue", Math.max(0, round2(received-total)));
            v.put("mode_paiement", h.optString("mode_paiement","ESPECES"));
            v.put("statut_paiement", status); v.put("commentaire", h.optString("commentaire",""));
            if (localOnlySale) v.put("sync_status", "local_only");
            long saleId = db.insertOrThrow("ventes_locales", null, v);

            for (int i=0;i<lines.length();i++) {
                JSONObject x = lines.getJSONObject(i);
                ContentValues lv = new ContentValues();
                lv.put("vente_id", saleId); lv.put("variante_id", x.getLong("variante_id"));
                lv.put("designation", x.optString("designation",""));
                lv.put("quantite", x.getDouble("quantite")); lv.put("prix_unitaire", x.getDouble("prix"));
                lv.put("total_ligne", x.getDouble("total_ligne"));
                db.insertOrThrow("vente_lignes_locales", null, lv);
                db.execSQL("UPDATE stocks SET quantite=quantite-? WHERE variante_id=? AND emplacement_id=?",
                        new Object[]{x.getDouble("quantite"), x.getLong("variante_id"), h.getLong("emplacement_id")});
            }
            db.setTransactionSuccessful();
            return saleId;
        } finally { db.endTransaction(); }
    }

    public JSONObject saleReceipt(long saleId) throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM ventes_locales WHERE id=?", new String[]{String.valueOf(saleId)});
        if (!c.moveToFirst()) { c.close(); throw new Exception("Vente introuvable"); }
        JSONObject o = cursorObject(c); c.close();
        return o;
    }

    public JSONArray saleLines(long saleId) throws Exception {
        JSONArray lines = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT variante_id,designation,quantite,prix_unitaire AS prix,total_ligne FROM vente_lignes_locales WHERE vente_id=? ORDER BY id",
                new String[]{String.valueOf(saleId)});
        while (c.moveToNext()) lines.put(cursorObject(c));
        c.close();
        return lines;
    }

    public long lastSaleId() {
        Cursor c = getReadableDatabase().rawQuery("SELECT id FROM ventes_locales ORDER BY id DESC LIMIT 1", null);
        long id = c.moveToFirst() ? c.getLong(0) : 0;
        c.close();
        return id;
    }

    public Cursor salesHistory(String q, int limit) {
        String term = q == null ? "" : q.trim();
        String like = "%" + term + "%";
        return getReadableDatabase().rawQuery(
                "SELECT v.id,v.num_vente,v.date_vente,COALESCE(c.fullname,'Client comptoir') client_name," +
                "v.montant_total,v.montant_recu,v.statut_paiement,v.mode_paiement,v.sync_status " +
                "FROM ventes_locales v LEFT JOIN clients c ON c.id=v.client_id " +
                "WHERE (?='' OR v.num_vente LIKE ? OR v.date_vente LIKE ? OR COALESCE(c.fullname,'') LIKE ? " +
                "OR COALESCE(v.mode_paiement,'') LIKE ? OR COALESCE(v.statut_paiement,'') LIKE ?) " +
                "ORDER BY v.id DESC LIMIT " + Math.max(1, Math.min(500, limit)),
                new String[]{term, like, like, like, like, like}
        );
    }

    /**
     * Répare les anciens clients SQLite restés local_only=1 mais dont
     * l'opération mobile_client_ops n'existe plus/ n'existait pas encore.
     * Cela permet de synchroniser aussi les clients créés avec d'anciennes V5.x.
     */
    private void ensurePendingClientOps(SQLiteDatabase db) {
        Cursor c = db.rawQuery(
                "SELECT c.id,c.fullname,COALESCE(c.contact,''),COALESCE(c.address,'') " +
                "FROM clients c " +
                "WHERE c.local_only=1 AND COALESCE(c.server_id,0)=0 " +
                "AND NOT EXISTS (SELECT 1 FROM mobile_client_ops o WHERE o.local_client_id=c.id)",
                null);
        try {
            while (c.moveToNext()) {
                ContentValues op = new ContentValues();
                op.put("op_uuid", UUID.randomUUID().toString());
                op.put("local_client_id", c.getLong(0));
                op.put("fullname", c.getString(1));
                op.put("contact", c.getString(2));
                op.put("address", c.getString(3));
                op.put("created_at", now());
                db.insertWithOnConflict("mobile_client_ops", null, op, SQLiteDatabase.CONFLICT_IGNORE);
            }
        } finally {
            c.close();
        }
    }

    private void enqueueSalaryOp(SQLiteDatabase db, long localId) {
        if (localId <= 0) return;
        Cursor c = db.rawQuery(
                "SELECT COALESCE(matricule,''),nom,COALESCE(telephone,''),COALESCE(email,''),COALESCE(address,'')," +
                "COALESCE(salaire_base,0),COALESCE(allocation_repas_jour,0),COALESCE(jours_repas_defaut,26),COALESCE(actif,1) FROM salaries WHERE id=?",
                new String[]{String.valueOf(localId)});
        try {
            if (!c.moveToFirst()) return;
            db.delete("mobile_salary_ops", "local_salary_id=?", new String[]{String.valueOf(localId)});
            ContentValues op = new ContentValues();
            op.put("op_uuid", UUID.randomUUID().toString());
            op.put("local_salary_id", localId);
            op.put("matricule", c.getString(0));
            op.put("nom", c.getString(1));
            op.put("telephone", c.getString(2));
            op.put("email", c.getString(3));
            op.put("address", c.getString(4));
            op.put("salaire_base", c.getDouble(5));
            op.put("allocation_repas_jour", c.getDouble(6));
            op.put("jours_repas_defaut", c.getDouble(7));
            op.put("actif", c.getInt(8));
            op.put("created_at", now());
            db.insertOrThrow("mobile_salary_ops", null, op);
        } finally { c.close(); }
    }

    /** Synchronise aussi les salariés créés avec la V5.25 avant l'ajout de la file salaire. */
    private void ensurePendingSalaryOps(SQLiteDatabase db) {
        Cursor c = db.rawQuery(
                "SELECT s.id FROM salaries s WHERE COALESCE(s.local_only,1)=1 AND COALESCE(s.server_id,0)=0 " +
                "AND NOT EXISTS (SELECT 1 FROM mobile_salary_ops o WHERE o.local_salary_id=s.id)", null);
        try {
            while (c.moveToNext()) enqueueSalaryOp(db, c.getLong(0));
        } finally { c.close(); }
    }

    private void enqueueAdvanceOp(SQLiteDatabase db, long advanceId) {
        if (advanceId <= 0) return;
        Cursor c = db.rawQuery(
                "SELECT a.salarie_id,a.date_avance,COALESCE(a.montant,0),COALESCE(a.remarque,'') " +
                "FROM avances a WHERE a.id=?",
                new String[]{String.valueOf(advanceId)});
        try {
            if (!c.moveToFirst()) return;
            db.delete("mobile_advance_ops", "local_advance_id=?", new String[]{String.valueOf(advanceId)});
            ContentValues op = new ContentValues();
            op.put("op_uuid", UUID.randomUUID().toString());
            op.put("local_advance_id", advanceId);
            op.put("salarie_local_id", c.getLong(0));
            op.put("date_avance", c.getString(1));
            op.put("montant", c.getDouble(2));
            op.put("remarque", c.getString(3));
            op.put("created_at", now());
            db.insertOrThrow("mobile_advance_ops", null, op);
        } finally { c.close(); }
    }

    /** Ajoute automatiquement les anciennes avances locales jamais envoyées. */
    private void ensurePendingAdvanceOps(SQLiteDatabase db) {
        Cursor c = db.rawQuery(
                "SELECT a.id FROM avances a WHERE COALESCE(a.server_id,0)=0 " +
                "AND NOT EXISTS (SELECT 1 FROM mobile_advance_ops o WHERE o.local_advance_id=a.id)", null);
        try {
            while (c.moveToNext()) enqueueAdvanceOp(db, c.getLong(0));
        } finally { c.close(); }
    }


    /**
     * Met le pack complet dans la file de synchronisation.
     * Une seule opération est conservée par pack : le dernier état gagne.
     */
    private void enqueuePackOp(SQLiteDatabase db, long packId, String action) {
        if (packId <= 0) return;
        String act = "DELETE".equalsIgnoreCase(action) ? "DELETE" : "UPSERT";
        long serverId = 0;
        Cursor c = db.rawQuery("SELECT COALESCE(server_id,0) FROM packs WHERE id=? LIMIT 1",
                new String[]{String.valueOf(packId)});
        if (c.moveToFirst()) serverId = c.getLong(0);
        c.close();

        // Si le pack a déjà une opération, récupérer son server_id avant de la remplacer
        // (utile pour une suppression juste après une création/modification locale).
        c = db.rawQuery("SELECT COALESCE(server_id,0) FROM mobile_pack_ops WHERE local_pack_id=? LIMIT 1",
                new String[]{String.valueOf(packId)});
        if (c.moveToFirst() && serverId <= 0) serverId = c.getLong(0);
        c.close();

        db.delete("mobile_pack_ops", "local_pack_id=?", new String[]{String.valueOf(packId)});
        ContentValues op = new ContentValues();
        op.put("op_uuid", UUID.randomUUID().toString());
        op.put("local_pack_id", packId);
        op.put("server_id", serverId);
        op.put("action", act);
        op.put("created_at", now());
        db.insertOrThrow("mobile_pack_ops", null, op);
    }

    /** Rattrape automatiquement un pack local modifié qui n'aurait pas encore d'opération. */
    private void ensurePendingPackOps(SQLiteDatabase db) {
        Cursor c = db.rawQuery(
                "SELECT p.id FROM packs p WHERE COALESCE(p.local_only,0)=1 " +
                "AND NOT EXISTS (SELECT 1 FROM mobile_pack_ops o WHERE o.local_pack_id=p.id)", null);
        try {
            while (c.moveToNext()) enqueuePackOp(db, c.getLong(0), "UPSERT");
        } finally { c.close(); }
    }

    private JSONArray pendingPackOpsJson(SQLiteDatabase db) throws Exception {
        JSONArray packs = new JSONArray();
        Cursor ops = db.rawQuery(
                "SELECT op_uuid,local_pack_id,COALESCE(server_id,0),COALESCE(action,'UPSERT') " +
                "FROM mobile_pack_ops ORDER BY created_at", null);
        try {
            while (ops.moveToNext()) {
                String opUuid = ops.getString(0);
                long localPackId = ops.getLong(1);
                long opServerId = ops.getLong(2);
                String action = ops.getString(3);

                JSONObject x = new JSONObject();
                x.put("op_uuid", opUuid);
                x.put("local_id", localPackId);
                x.put("server_id", opServerId);
                x.put("action", action);

                if ("DELETE".equalsIgnoreCase(action)) {
                    packs.put(x);
                    continue;
                }

                Cursor p = db.rawQuery(
                        "SELECT COALESCE(server_id,0),nom,COALESCE(description,''),COALESCE(slogan,'')," +
                        "COALESCE(categorie,'Nouveau-né'),COALESCE(prix_vente,0),COALESCE(actif,1) " +
                        "FROM packs WHERE id=? LIMIT 1",
                        new String[]{String.valueOf(localPackId)});
                if (!p.moveToFirst()) {
                    p.close();
                    // Pack supprimé entre-temps : convertir l'opération en suppression.
                    x.put("action", "DELETE");
                    packs.put(x);
                    continue;
                }
                long serverId = p.getLong(0);
                if (serverId > 0) x.put("server_id", serverId);
                x.put("nom", p.getString(1));
                x.put("description", p.getString(2));
                x.put("slogan", p.getString(3));
                x.put("categorie", p.getString(4));
                x.put("prix_vente", p.getDouble(5));
                x.put("actif", p.getInt(6));
                p.close();

                JSONArray articles = new JSONArray();
                Cursor a = db.rawQuery(
                        "SELECT COALESCE(variante_id,0),nom_article,COALESCE(quantite,1)," +
                        "COALESCE(prix_unitaire,0),COALESCE(ordre,0)," +
                        "CASE WHEN COALESCE(TRIM(groupe_code),'')='' THEN 'A'||id ELSE groupe_code END " +
                        "FROM pack_articles WHERE pack_id=? ORDER BY ordre,id",
                        new String[]{String.valueOf(localPackId)});
                try {
                    while (a.moveToNext()) {
                        JSONObject item = new JSONObject();
                        item.put("variante_id", a.getLong(0));
                        item.put("nom_article", a.getString(1));
                        item.put("quantite", a.getDouble(2));
                        item.put("prix_unitaire", a.getDouble(3));
                        item.put("ordre", a.getInt(4));
                        item.put("groupe_code", a.getString(5));
                        articles.put(item);
                    }
                } finally { a.close(); }
                x.put("articles", articles);
                packs.put(x);
            }
        } finally { ops.close(); }
        return packs;
    }

    public JSONObject pendingMasterData() throws Exception {
        SQLiteDatabase syncDb = getWritableDatabase();
        ensurePendingClientOps(syncDb);
        ensurePendingSalaryOps(syncDb);
        ensurePendingAdvanceOps(syncDb);
        ensurePendingPackOps(syncDb);
        JSONObject out = new JSONObject();
        JSONArray clients = new JSONArray();
        Cursor c = syncDb.rawQuery(
                "SELECT o.op_uuid,o.local_client_id,o.fullname,COALESCE(o.contact,''),COALESCE(o.address,''),COALESCE(c.server_id,0) " +
                "FROM mobile_client_ops o LEFT JOIN clients c ON c.id=o.local_client_id ORDER BY o.created_at", null);
        while (c.moveToNext()) {
            JSONObject x = new JSONObject();
            x.put("op_uuid", c.getString(0));
            x.put("local_id", c.getLong(1));
            x.put("fullname", c.getString(2));
            x.put("contact", c.getString(3));
            x.put("address", c.getString(4));
            x.put("server_id", c.getLong(5));
            clients.put(x);
        }
        c.close();

        JSONArray variants = new JSONArray();
        c = syncDb.rawQuery(
                "SELECT op_uuid,local_variant_id,service_id,COALESCE(couleur,''),COALESCE(taille,''),COALESCE(code_barre,''),COALESCE(prix,0),COALESCE(image_url,'') FROM mobile_variant_ops ORDER BY created_at", null);
        while (c.moveToNext()) {
            JSONObject x = new JSONObject();
            x.put("op_uuid", c.getString(0));
            x.put("local_id", c.getLong(1));
            x.put("service_id", c.getLong(2));
            x.put("couleur", c.getString(3));
            x.put("taille", c.getString(4));
            x.put("code_barre", c.getString(5));
            x.put("prix", c.getDouble(6));
            x.put("image_url", c.getString(7));
            variants.put(x);
        }
        c.close();

        JSONArray stocks = new JSONArray();
        c = syncDb.rawQuery(
                "SELECT op_uuid,variante_id,emplacement_id,quantite FROM mobile_stock_ops ORDER BY created_at", null);
        while (c.moveToNext()) {
            JSONObject x = new JSONObject();
            x.put("op_uuid", c.getString(0));
            x.put("variante_id", c.getLong(1));
            x.put("emplacement_id", c.getLong(2));
            x.put("quantite", c.getDouble(3));
            stocks.put(x);
        }
        c.close();

        JSONArray salaries = new JSONArray();
        c = syncDb.rawQuery(
                "SELECT o.op_uuid,o.local_salary_id,COALESCE(o.matricule,''),o.nom,COALESCE(o.telephone,''),COALESCE(o.email,''),COALESCE(o.address,'')," +
                "COALESCE(o.salaire_base,0),COALESCE(o.allocation_repas_jour,0),COALESCE(o.jours_repas_defaut,26),COALESCE(o.actif,1),COALESCE(s.server_id,0) " +
                "FROM mobile_salary_ops o LEFT JOIN salaries s ON s.id=o.local_salary_id ORDER BY o.created_at", null);
        while (c.moveToNext()) {
            JSONObject x = new JSONObject();
            x.put("op_uuid", c.getString(0));
            x.put("local_id", c.getLong(1));
            x.put("matricule", c.getString(2));
            x.put("nom", c.getString(3));
            x.put("telephone", c.getString(4));
            x.put("email", c.getString(5));
            x.put("address", c.getString(6));
            x.put("salaire_base", c.getDouble(7));
            x.put("allocation_repas_jour", c.getDouble(8));
            x.put("jours_repas_defaut", c.getDouble(9));
            x.put("actif", c.getInt(10));
            x.put("server_id", c.getLong(11));
            salaries.put(x);
        }
        c.close();

        JSONArray advances = new JSONArray();
        c = syncDb.rawQuery(
                "SELECT o.op_uuid,o.local_advance_id,o.salarie_local_id,o.date_avance,o.montant,COALESCE(o.remarque,'')," +
                "COALESCE(a.server_id,0),COALESCE(s.server_id,0),COALESCE(s.matricule,'') " +
                "FROM mobile_advance_ops o " +
                "LEFT JOIN avances a ON a.id=o.local_advance_id " +
                "LEFT JOIN salaries s ON s.id=o.salarie_local_id ORDER BY o.created_at", null);
        while (c.moveToNext()) {
            JSONObject x = new JSONObject();
            x.put("op_uuid", c.getString(0));
            x.put("local_id", c.getLong(1));
            x.put("salarie_local_id", c.getLong(2));
            x.put("date_avance", c.getString(3));
            x.put("montant", c.getDouble(4));
            x.put("remarque", c.getString(5));
            x.put("server_id", c.getLong(6));
            x.put("salarie_server_id", c.getLong(7));
            x.put("matricule", c.getString(8));
            advances.put(x);
        }
        c.close();

        JSONArray users = new JSONArray();
        c = syncDb.rawQuery("SELECT op_uuid,local_user_id,COALESCE(server_id,0),action,COALESCE(firstname,''),COALESCE(lastname,''),COALESCE(username,''),COALESCE(role,2),COALESCE(active,1),COALESCE(password_md5,'') FROM mobile_user_ops ORDER BY created_at", null);
        while (c.moveToNext()) {
            JSONObject x = new JSONObject();
            x.put("op_uuid", c.getString(0)); x.put("local_id", c.getLong(1)); x.put("server_id", c.getLong(2)); x.put("action", c.getString(3));
            x.put("firstname", c.getString(4)); x.put("lastname", c.getString(5)); x.put("username", c.getString(6)); x.put("type", c.getInt(7)); x.put("active", c.getInt(8)); x.put("password_md5", c.getString(9));
            users.put(x);
        }
        c.close();
        out.put("clients", clients);
        out.put("users", users);
        out.put("salaries", salaries);
        out.put("avances", advances);
        out.put("variants", variants);
        out.put("stocks", stocks);
        out.put("packs", pendingPackOpsJson(syncDb));
        return out;
    }

    public int pendingMasterCount() {
        SQLiteDatabase db = getWritableDatabase();
        ensurePendingClientOps(db);
        ensurePendingSalaryOps(db);
        ensurePendingAdvanceOps(db);
        ensurePendingPackOps(db);
        long a = DatabaseUtilsCompat.count(db, "mobile_client_ops");
        long b = DatabaseUtilsCompat.count(db, "mobile_variant_ops");
        long c = DatabaseUtilsCompat.count(db, "mobile_stock_ops");
        long d = DatabaseUtilsCompat.count(db, "mobile_salary_ops");
        long e = DatabaseUtilsCompat.count(db, "mobile_advance_ops");
        long f = DatabaseUtilsCompat.count(db, "mobile_pack_ops");
        long g = DatabaseUtilsCompat.count(db, "mobile_user_ops");
        return (int)(a + b + c + d + e + f + g);
    }

    public synchronized void applyMasterDataSync(JSONObject response) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            JSONArray clients = response.optJSONArray("clients");
            if (clients != null) {
                for (int i = 0; i < clients.length(); i++) {
                    JSONObject x = clients.getJSONObject(i);
                    long localId = x.optLong("local_id", 0);
                    long serverId = x.optLong("server_id", 0);
                    String opUuid = x.optString("op_uuid", "");
                    if (localId > 0 && serverId > 0) {
                        ContentValues v = new ContentValues();
                        v.put("server_id", serverId);
                        v.put("local_only", 0);
                        db.update("clients", v, "id=?", new String[]{String.valueOf(localId)});
                    }
                    if (!opUuid.isEmpty()) db.delete("mobile_client_ops", "op_uuid=?", new String[]{opUuid});
                }
            }

            JSONArray users = response.optJSONArray("users");
            if (users != null) {
                for (int i = 0; i < users.length(); i++) {
                    JSONObject x = users.getJSONObject(i); long localId=x.optLong("local_id",0), serverId=x.optLong("server_id",0); String opUuid=x.optString("op_uuid","");
                    if (localId>0 && serverId>0 && !"DELETE".equalsIgnoreCase(x.optString("action","UPSERT"))) { ContentValues v=new ContentValues(); v.put("server_id",serverId); v.put("local_only",0); db.update("app_users",v,"id=?",new String[]{String.valueOf(localId)}); }
                    if(!opUuid.isEmpty()) db.delete("mobile_user_ops","op_uuid=?",new String[]{opUuid});
                }
            }

            JSONArray salaries = response.optJSONArray("salaries");
            if (salaries != null) {
                for (int i = 0; i < salaries.length(); i++) {
                    JSONObject x = salaries.getJSONObject(i);
                    long localId = x.optLong("local_id", 0);
                    long serverId = x.optLong("server_id", 0);
                    String opUuid = x.optString("op_uuid", "");
                    if (localId > 0 && serverId > 0) {
                        ContentValues v = new ContentValues();
                        v.put("server_id", serverId);
                        v.put("local_only", 0);
                        db.update("salaries", v, "id=?", new String[]{String.valueOf(localId)});
                    }
                    if (!opUuid.isEmpty()) db.delete("mobile_salary_ops", "op_uuid=?", new String[]{opUuid});
                }
            }

            JSONArray advances = response.optJSONArray("avances");
            if (advances != null) {
                for (int i = 0; i < advances.length(); i++) {
                    JSONObject x = advances.getJSONObject(i);
                    long localId = x.optLong("local_id", 0);
                    long serverId = x.optLong("server_id", 0);
                    String opUuid = x.optString("op_uuid", "");
                    if (localId > 0 && serverId > 0) {
                        ContentValues v = new ContentValues();
                        v.put("server_id", serverId);
                        db.update("avances", v, "id=?", new String[]{String.valueOf(localId)});
                    }
                    if (!opUuid.isEmpty()) db.delete("mobile_advance_ops", "op_uuid=?", new String[]{opUuid});
                }
            }

            JSONArray variants = response.optJSONArray("variants");
            if (variants != null) {
                for (int i = 0; i < variants.length(); i++) {
                    JSONObject x = variants.getJSONObject(i);
                    long localId = x.optLong("local_id", 0);
                    long serverId = x.optLong("server_id", 0);
                    String opUuid = x.optString("op_uuid", "");
                    if (localId != 0 && serverId > 0 && localId != serverId) {
                        remapVariantId(db, localId, serverId);
                    }
                    if (!opUuid.isEmpty()) db.delete("mobile_variant_ops", "op_uuid=?", new String[]{opUuid});
                }
            }

            JSONArray stocks = response.optJSONArray("stocks");
            if (stocks != null) {
                for (int i = 0; i < stocks.length(); i++) {
                    String opUuid = stocks.getJSONObject(i).optString("op_uuid", "");
                    if (!opUuid.isEmpty()) db.delete("mobile_stock_ops", "op_uuid=?", new String[]{opUuid});
                }
            }

            JSONArray packs = response.optJSONArray("packs");
            if (packs != null) {
                for (int i = 0; i < packs.length(); i++) {
                    JSONObject x = packs.getJSONObject(i);
                    long localId = x.optLong("local_id", 0);
                    long serverId = x.optLong("server_id", 0);
                    String action = x.optString("action", "UPSERT");
                    String opUuid = x.optString("op_uuid", "");
                    if (!"DELETE".equalsIgnoreCase(action) && localId > 0 && serverId > 0) {
                        ContentValues v = new ContentValues();
                        v.put("server_id", serverId);
                        v.put("local_only", 0);
                        db.update("packs", v, "id=?", new String[]{String.valueOf(localId)});
                    }
                    if (!opUuid.isEmpty()) db.delete("mobile_pack_ops", "op_uuid=?", new String[]{opUuid});
                }
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private void remapVariantId(SQLiteDatabase db, long localId, long serverId) {
        Cursor exists = db.rawQuery("SELECT id FROM variantes WHERE id=?", new String[]{String.valueOf(serverId)});
        boolean serverExists = exists.moveToFirst();
        exists.close();

        if (serverExists) {
            Cursor ls = db.rawQuery("SELECT emplacement_id,quantite FROM stocks WHERE variante_id=?",
                    new String[]{String.valueOf(localId)});
            while (ls.moveToNext()) {
                long emp = ls.getLong(0);
                double qty = ls.getDouble(1);
                Cursor ts = db.rawQuery("SELECT quantite FROM stocks WHERE variante_id=? AND emplacement_id=?",
                        new String[]{String.valueOf(serverId), String.valueOf(emp)});
                if (ts.moveToFirst()) {
                    db.execSQL("UPDATE stocks SET quantite=quantite+? WHERE variante_id=? AND emplacement_id=?",
                            new Object[]{qty, serverId, emp});
                    db.delete("stocks", "variante_id=? AND emplacement_id=?",
                            new String[]{String.valueOf(localId), String.valueOf(emp)});
                } else {
                    ContentValues sv = new ContentValues();
                    sv.put("variante_id", serverId);
                    db.update("stocks", sv, "variante_id=? AND emplacement_id=?",
                            new String[]{String.valueOf(localId), String.valueOf(emp)});
                }
                ts.close();
            }
            ls.close();
            db.delete("variantes", "id=?", new String[]{String.valueOf(localId)});
        } else {
            ContentValues v = new ContentValues();
            v.put("id", serverId);
            db.update("variantes", v, "id=?", new String[]{String.valueOf(localId)});
            db.execSQL("UPDATE stocks SET variante_id=? WHERE variante_id=?", new Object[]{serverId, localId});
        }
        db.execSQL("UPDATE vente_lignes_locales SET variante_id=? WHERE variante_id=?", new Object[]{serverId, localId});
        db.execSQL("UPDATE pos_draft_lines SET variante_id=? WHERE variante_id=?", new Object[]{serverId, localId});
        db.execSQL("UPDATE pack_articles SET variante_id=? WHERE variante_id=?", new Object[]{serverId, localId});
        db.execSQL("UPDATE mobile_stock_ops SET variante_id=? WHERE variante_id=?", new Object[]{serverId, localId});
    }

    public JSONArray pendingSales() throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        JSONArray arr = new JSONArray();
        Cursor c = db.rawQuery("SELECT * FROM ventes_locales WHERE sync_status='pending' ORDER BY id LIMIT 100", null);
        while (c.moveToNext()) {
            JSONObject s = cursorObject(c);
            long saleId = s.getLong("id");
            long clientLocal = s.optLong("client_id",0);
            if (clientLocal > 0) {
                Cursor cl = db.rawQuery("SELECT server_id,fullname,contact,address FROM clients WHERE id=?",
                        new String[]{String.valueOf(clientLocal)});
                if (cl.moveToFirst()) {
                    if (!cl.isNull(0)) s.put("client_server_id", cl.getLong(0));
                    s.put("client_name", cl.getString(1));
                    s.put("client_contact", cl.getString(2));
                    s.put("client_address", cl.getString(3));
                }
                cl.close();
            }
            JSONArray lines = new JSONArray();
            Cursor l = db.rawQuery("SELECT variante_id,designation,quantite,prix_unitaire AS prix,total_ligne FROM vente_lignes_locales WHERE vente_id=? ORDER BY id",
                    new String[]{String.valueOf(saleId)});
            while (l.moveToNext()) lines.put(cursorObject(l));
            l.close();
            s.put("lignes", lines);
            arr.put(s);
        }
        c.close();
        return arr;
    }

    public void markSynced(JSONArray accepted) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        for (int i=0;i<accepted.length();i++) {
            JSONObject a = accepted.getJSONObject(i);
            ContentValues v = new ContentValues();
            v.put("sync_status","synced");
            v.put("server_id", a.optLong("server_id",0));
            v.putNull("sync_error");
            db.update("ventes_locales", v, "uuid=?", new String[]{a.getString("uuid")});
        }
    }

    public void markSaleErrors(JSONArray rejected) throws Exception {
        if (rejected == null) return;
        SQLiteDatabase db = getWritableDatabase();
        for (int i = 0; i < rejected.length(); i++) {
            JSONObject x = rejected.getJSONObject(i);
            String uuid = x.optString("uuid", "").trim();
            String error = x.optString("error", "Synchronisation refusée").trim();
            if (uuid.isEmpty()) continue;
            ContentValues v = new ContentValues();
            v.put("sync_error", error);
            db.update("ventes_locales", v, "uuid=? AND sync_status='pending'", new String[]{uuid});
        }
    }

    public void clearSaleErrors(JSONArray accepted) throws Exception {
        if (accepted == null) return;
        SQLiteDatabase db = getWritableDatabase();
        for (int i = 0; i < accepted.length(); i++) {
            String uuid = accepted.getJSONObject(i).optString("uuid", "").trim();
            if (uuid.isEmpty()) continue;
            ContentValues v = new ContentValues();
            v.putNull("sync_error");
            db.update("ventes_locales", v, "uuid=?", new String[]{uuid});
        }
    }

    public void markSyncError(String message) {
        ContentValues v = new ContentValues();
        v.put("sync_error", message);
        getWritableDatabase().update("ventes_locales", v, "sync_status='pending'", null);
    }

    public int pendingCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM ventes_locales WHERE sync_status='pending'", null);
        int n = c.moveToFirst()?c.getInt(0):0; c.close(); return n;
    }

    public int productCount() { return (int) DatabaseUtilsCompat.count(getReadableDatabase(),"produits"); }
    public double stockTotal() {
        Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(quantite),0) FROM stocks",null);
        double n=c.moveToFirst()?c.getDouble(0):0;c.close();return n;
    }

    // ========================= PACKS NOUVEAU-NE SQLITE =========================
    public int packCount() { return (int) DatabaseUtilsCompat.count(getReadableDatabase(), "packs"); }

    public Cursor packs(String q) {
        String term = q == null ? "" : q.trim();
        String like = "%" + term + "%";
        return getReadableDatabase().rawQuery(
                "SELECT p.id,p.nom,COALESCE(p.prix_vente,0),COALESCE(p.description,''),COALESCE(p.actif,1)," +
                "COUNT(DISTINCT CASE WHEN pa.id IS NULL THEN NULL WHEN COALESCE(TRIM(pa.groupe_code),'')='' THEN 'A'||pa.id ELSE pa.groupe_code END) item_count," +
                "COUNT(DISTINCT CASE WHEN pa.variante_id IS NOT NULL AND pa.variante_id>0 THEN CASE WHEN COALESCE(TRIM(pa.groupe_code),'')='' THEN 'A'||pa.id ELSE pa.groupe_code END END) linked_count," +
                "COALESCE(SUM(COALESCE(pa.quantite,0)*COALESCE(pa.prix_unitaire,0)),0) detail_total," +
                "COALESCE(p.slogan,''),COALESCE(p.categorie,'Nouveau-né'),COALESCE(p.image_path,''),COALESCE(p.logo_path,''),COALESCE(p.whatsapp_number,'') " +
                "FROM packs p LEFT JOIN pack_articles pa ON pa.pack_id=p.id " +
                "WHERE (?='' OR p.nom LIKE ? OR COALESCE(p.description,'') LIKE ?) " +
                "GROUP BY p.id,p.nom,p.prix_vente,p.description,p.actif ORDER BY p.actif DESC,p.prix_vente,p.nom",
                new String[]{term, like, like});
    }

    public JSONObject packHeader(long packId) throws Exception {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT p.id,p.nom,COALESCE(p.prix_vente,0) prix_vente,COALESCE(p.description,'') description,COALESCE(p.actif,1) actif," +
                "COUNT(DISTINCT CASE WHEN pa.id IS NULL THEN NULL WHEN COALESCE(TRIM(pa.groupe_code),'')='' THEN 'A'||pa.id ELSE pa.groupe_code END) item_count," +
                "COUNT(DISTINCT CASE WHEN pa.variante_id IS NOT NULL AND pa.variante_id>0 THEN CASE WHEN COALESCE(TRIM(pa.groupe_code),'')='' THEN 'A'||pa.id ELSE pa.groupe_code END END) linked_count," +
                "COALESCE(SUM(COALESCE(pa.quantite,0)*COALESCE(pa.prix_unitaire,0)),0) detail_total," +
                "COALESCE(p.slogan,'') slogan,COALESCE(p.categorie,'Nouveau-né') categorie,COALESCE(p.image_path,'') image_path,COALESCE(p.logo_path,'') logo_path,COALESCE(p.whatsapp_number,'') whatsapp_number " +
                "FROM packs p LEFT JOIN pack_articles pa ON pa.pack_id=p.id WHERE p.id=? GROUP BY p.id",
                new String[]{String.valueOf(packId)});
        if (!c.moveToFirst()) { c.close(); throw new Exception("Pack introuvable."); }
        JSONObject out = cursorObject(c); c.close(); return out;
    }

    public Cursor packArticles(long packId) {
        return getReadableDatabase().rawQuery(
                "SELECT pa.id,pa.pack_id,COALESCE(pa.variante_id,0) variante_id,pa.nom_article,COALESCE(pa.quantite,1) quantite," +
                "COALESCE(pa.prix_unitaire,0) prix_unitaire,COALESCE(p.name,'') produit,COALESCE(v.couleur,'') couleur," +
                "COALESCE(v.taille,'') taille,COALESCE(v.code_barre,'') code_barre," +
                "CASE WHEN COALESCE(TRIM(pa.groupe_code),'')='' THEN 'A'||pa.id ELSE pa.groupe_code END groupe_code " +
                "FROM pack_articles pa LEFT JOIN variantes v ON v.id=pa.variante_id LEFT JOIN produits p ON p.id=v.service_id " +
                "WHERE pa.pack_id=? ORDER BY pa.ordre,pa.id",
                new String[]{String.valueOf(packId)});
    }

    public Cursor packComponents(long packId, long emplacementId) {
        return getReadableDatabase().rawQuery(
                "SELECT pa.id,pa.variante_id,pa.nom_article,COALESCE(pa.quantite,1) quantite,COALESCE(pa.prix_unitaire,0) prix_pack," +
                "p.name,COALESCE(v.couleur,'') couleur,COALESCE(v.taille,'') taille," +
                "CASE WHEN COALESCE(v.prix,0)>0 THEN v.prix ELSE p.price END prix_catalogue,COALESCE(s.quantite,0) stock_disponible " +
                "FROM pack_articles pa JOIN variantes v ON v.id=pa.variante_id JOIN produits p ON p.id=v.service_id " +
                "LEFT JOIN stocks s ON s.variante_id=v.id AND s.emplacement_id=? WHERE pa.pack_id=? ORDER BY pa.ordre,pa.id",
                new String[]{String.valueOf(emplacementId), String.valueOf(packId)});
    }

    public int packUnlinkedCount(long packId) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(DISTINCT CASE WHEN COALESCE(TRIM(groupe_code),'')='' THEN 'A'||id ELSE groupe_code END) " +
                "FROM pack_articles WHERE pack_id=? AND (variante_id IS NULL OR variante_id<=0)",
                new String[]{String.valueOf(packId)});
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }

    public int packLinkedComponentCount(long packId) {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM pack_articles WHERE pack_id=? AND variante_id IS NOT NULL AND variante_id>0",
                new String[]{String.valueOf(packId)});
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }

    public synchronized long createPack(String name, double price, String slogan, String categorie, String description, String imagePath, String logoPath, String whatsappNumber, boolean active) throws Exception {
        String n = safe(name).trim();
        if (n.isEmpty()) throw new Exception("Nom du pack obligatoire.");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("nom", n); v.put("prix_vente", Math.max(0, price)); v.put("slogan", safe(slogan));
            v.put("categorie", safe(categorie).trim().isEmpty() ? "Nouveau-né" : safe(categorie).trim()); v.put("description", safe(description));
            v.put("image_path", safe(imagePath)); v.put("logo_path", safe(logoPath)); v.put("whatsapp_number", safe(whatsappNumber));
            v.put("actif", active ? 1 : 0); v.put("local_only", 1); v.put("created_at", now()); v.put("updated_at", now());
            long id = db.insertOrThrow("packs", null, v);
            enqueuePackOp(db, id, "UPSERT");
            db.setTransactionSuccessful();
            return id;
        } finally { db.endTransaction(); }
    }

    public synchronized void updatePack(long packId, String name, double price, String slogan, String categorie, String description, String imagePath, String logoPath, String whatsappNumber, boolean active) throws Exception {
        String n = safe(name).trim();
        if (n.isEmpty()) throw new Exception("Nom du pack obligatoire.");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("nom", n); v.put("prix_vente", Math.max(0, price)); v.put("slogan", safe(slogan));
            v.put("categorie", safe(categorie).trim().isEmpty() ? "Nouveau-né" : safe(categorie).trim()); v.put("description", safe(description));
            v.put("image_path", safe(imagePath)); v.put("logo_path", safe(logoPath)); v.put("whatsapp_number", safe(whatsappNumber));
            v.put("actif", active ? 1 : 0); v.put("local_only", 1); v.put("updated_at", now());
            int changed = db.update("packs", v, "id=?", new String[]{String.valueOf(packId)});
            if (changed <= 0) throw new Exception("Pack introuvable.");
            enqueuePackOp(db, packId, "UPSERT");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void deletePack(long packId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            enqueuePackOp(db, packId, "DELETE");
            db.delete("packs", "id=?", new String[]{String.valueOf(packId)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized long addPackArticle(long packId, long variantId, String name, double qty, double unitPrice) throws Exception {
        String n = safe(name).trim();
        if (n.isEmpty()) throw new Exception("Nom de l'article obligatoire.");
        qty = roundHalf(qty);
        if (qty < 0.5) throw new Exception("Quantité minimale : 0,5.");
        if (variantId > 0 && !packVariantExists(variantId)) {
            throw new Exception("La variante choisie n'existe pas dans le catalogue local. Synchronisez le catalogue puis réessayez.");
        }
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT COALESCE(MAX(ordre),0)+1 FROM pack_articles WHERE pack_id=?", new String[]{String.valueOf(packId)});
        int order = c.moveToFirst() ? c.getInt(0) : 1; c.close();
        ContentValues v = new ContentValues();
        v.put("pack_id", packId); v.put("groupe_code", "G" + UUID.randomUUID().toString()); if (variantId > 0) v.put("variante_id", variantId); else v.putNull("variante_id");
        v.put("nom_article", n); v.put("quantite", qty); v.put("prix_unitaire", Math.max(0, unitPrice)); v.put("ordre", order);
        long id = db.insertOrThrow("pack_articles", null, v);
        verifyPackArticleSaved(db, id, packId, variantId, qty, Math.max(0, unitPrice));
        touchPack(db, packId); return id;
    }

    public synchronized void updatePackArticle(long itemId, long packId, long variantId, String name, double qty, double unitPrice) throws Exception {
        String n = safe(name).trim();
        if (n.isEmpty()) throw new Exception("Nom de l'article obligatoire.");
        qty = roundHalf(qty);
        if (qty < 0.5) throw new Exception("Quantité minimale : 0,5.");
        if (variantId > 0 && !packVariantExists(variantId)) {
            throw new Exception("La variante choisie n'existe pas dans le catalogue local. Synchronisez le catalogue puis réessayez.");
        }
        ContentValues v = new ContentValues();
        if (variantId > 0) v.put("variante_id", variantId); else v.putNull("variante_id");
        v.put("nom_article", n); v.put("quantite", qty); v.put("prix_unitaire", Math.max(0, unitPrice));
        SQLiteDatabase db = getWritableDatabase();
        int changed = db.update("pack_articles", v, "id=? AND pack_id=?", new String[]{String.valueOf(itemId), String.valueOf(packId)});
        if (changed <= 0) throw new Exception("Article du pack introuvable : aucune modification enregistrée.");
        verifyPackArticleSaved(db, itemId, packId, variantId, qty, Math.max(0, unitPrice));
        touchPack(db, packId);
    }

    /**
     * Crée ou remplace un article de pack pouvant contenir plusieurs produits/variantes.
     * Toutes les lignes partagent le même groupe_code : le POS continue ainsi à déduire
     * chaque variante séparément, tandis que l'interface et l'image les présentent comme
     * un seul article composé.
     */
    public synchronized String savePackArticleGroup(long packId, String groupCode, String name,
                                                    java.util.List<Long> variantIds, java.util.Map<Long, Double> qtyByVariant,
                                                    double freeQty, double freeUnitPrice) throws Exception {
        String n = safe(name).trim();
        if (n.isEmpty()) throw new Exception("Nom de l'article obligatoire.");
        freeQty = roundHalf(freeQty);
        if (freeQty < 0.5) freeQty = 1;
        String code = safe(groupCode).trim();
        if (code.isEmpty()) code = "G" + UUID.randomUUID().toString();

        java.util.ArrayList<Long> ids = new java.util.ArrayList<>();
        if (variantIds != null) {
            for (Long id : variantIds) {
                long v = id == null ? 0 : id;
                if (v <= 0 || ids.contains(v)) continue;
                if (!packVariantExists(v)) throw new Exception("Une variante choisie n'existe plus dans le catalogue local.");
                ids.add(v);
            }
        }

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            int order = 1;
            Cursor oc = db.rawQuery(
                    "SELECT MIN(ordre) FROM pack_articles WHERE pack_id=? AND groupe_code=?",
                    new String[]{String.valueOf(packId), code});
            if (oc.moveToFirst() && !oc.isNull(0)) order = Math.max(1, oc.getInt(0));
            else {
                oc.close();
                oc = db.rawQuery("SELECT COALESCE(MAX(ordre),0)+1 FROM pack_articles WHERE pack_id=?",
                        new String[]{String.valueOf(packId)});
                if (oc.moveToFirst()) order = Math.max(1, oc.getInt(0));
            }
            oc.close();

            db.delete("pack_articles", "pack_id=? AND groupe_code=?",
                    new String[]{String.valueOf(packId), code});

            if (ids.isEmpty()) {
                ContentValues v = new ContentValues();
                v.put("pack_id", packId); v.put("groupe_code", code); v.putNull("variante_id");
                v.put("nom_article", n); v.put("quantite", freeQty);
                v.put("prix_unitaire", Math.max(0, freeUnitPrice)); v.put("ordre", order);
                db.insertOrThrow("pack_articles", null, v);
            } else {
                for (Long variantId : ids) {
                    double catalogPrice = packVariantPrice(db, variantId);
                    double lineQty = freeQty;
                    if (qtyByVariant != null && qtyByVariant.containsKey(variantId)) {
                        Double qv = qtyByVariant.get(variantId);
                        if (qv != null) lineQty = roundHalf(qv);
                    }
                    if (lineQty < 0.5) lineQty = 1;
                    ContentValues v = new ContentValues();
                    v.put("pack_id", packId); v.put("groupe_code", code); v.put("variante_id", variantId);
                    v.put("nom_article", n); v.put("quantite", lineQty);
                    v.put("prix_unitaire", Math.max(0, catalogPrice)); v.put("ordre", order);
                    db.insertOrThrow("pack_articles", null, v);
                }
            }
            touchPack(db, packId);
            db.setTransactionSuccessful();
            return code;
        } finally { db.endTransaction(); }
    }

    private double packVariantPrice(SQLiteDatabase db, long variantId) {
        Cursor c = db.rawQuery(
                "SELECT CASE WHEN COALESCE(v.prix,0)>0 THEN v.prix ELSE COALESCE(p.price,0) END " +
                "FROM variantes v LEFT JOIN produits p ON p.id=v.service_id WHERE v.id=? LIMIT 1",
                new String[]{String.valueOf(variantId)});
        double price = c.moveToFirst() ? c.getDouble(0) : 0;
        c.close();
        return Math.max(0, price);
    }

    public void deletePackArticleGroup(long packId, String groupCode) {
        String code = safe(groupCode).trim();
        if (code.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        db.delete("pack_articles", "pack_id=? AND groupe_code=?",
                new String[]{String.valueOf(packId), code});
        touchPack(db, packId);
    }

    private void verifyPackArticleSaved(SQLiteDatabase db, long itemId, long packId, long variantId, double qty, double unitPrice) throws Exception {
        Cursor c = db.rawQuery(
                "SELECT COALESCE(variante_id,0),COALESCE(quantite,0),COALESCE(prix_unitaire,0) FROM pack_articles WHERE id=? AND pack_id=? LIMIT 1",
                new String[]{String.valueOf(itemId), String.valueOf(packId)});
        if (!c.moveToFirst()) { c.close(); throw new Exception("Impossible de relire l'article après enregistrement."); }
        long savedVariant = c.getLong(0);
        double savedQty = c.getDouble(1);
        double savedPrice = c.getDouble(2);
        c.close();
        long expectedVariant = variantId > 0 ? variantId : 0;
        if (savedVariant != expectedVariant) throw new Exception("La liaison au stock n'a pas été enregistrée.");
        if (Math.abs(savedQty - qty) > 0.001) throw new Exception("La quantité n'a pas été enregistrée correctement.");
        if (Math.abs(savedPrice - unitPrice) > 0.01) throw new Exception("Le prix n'a pas été enregistré correctement.");
    }

    public void deletePackArticle(long itemId, long packId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("pack_articles", "id=? AND pack_id=?", new String[]{String.valueOf(itemId), String.valueOf(packId)});
        touchPack(db, packId);
    }

    private void touchPack(SQLiteDatabase db, long packId) {
        ContentValues v = new ContentValues();
        v.put("updated_at", now());
        v.put("local_only", 1);
        db.update("packs", v, "id=?", new String[]{String.valueOf(packId)});
        enqueuePackOp(db, packId, "UPSERT");
    }

    public void applyCatalog(JSONObject data) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            JSONArray emps=data.optJSONArray("emplacements");
            JSONArray clients=data.optJSONArray("clients");
            JSONArray users=data.optJSONArray("users");
            JSONArray products=data.optJSONArray("produits");
            JSONArray variants=data.optJSONArray("variantes");
            JSONArray stocks=data.optJSONArray("stocks");
            if (users != null) {
                HashSet<Long> receivedUserIds = new HashSet<>();
                for (int i=0;i<users.length();i++) {
                    JSONObject x=users.getJSONObject(i); long sid=x.optLong("id",0); if(sid<=0) continue; receivedUserIds.add(sid);
                    long localId=0; Cursor uc=db.rawQuery("SELECT id FROM app_users WHERE server_id=? LIMIT 1",new String[]{String.valueOf(sid)}); if(uc.moveToFirst()) localId=uc.getLong(0); uc.close();
                    if(localId<=0){ String un=x.optString("username","").trim(); uc=db.rawQuery("SELECT id FROM app_users WHERE COALESCE(server_id,0)=0 AND LOWER(TRIM(username))=LOWER(TRIM(?)) LIMIT 1",new String[]{un}); if(uc.moveToFirst()) localId=uc.getLong(0); uc.close(); }
                    if(localId>0){ uc=db.rawQuery("SELECT 1 FROM mobile_user_ops WHERE local_user_id=? LIMIT 1",new String[]{String.valueOf(localId)}); boolean pending=uc.moveToFirst(); uc.close(); if(pending) continue; }
                    ContentValues uv=new ContentValues(); uv.put("server_id",sid); uv.put("local_only",0); uv.put("firstname",x.optString("firstname","")); uv.put("lastname",x.optString("lastname","")); uv.put("username",x.optString("username","user"+sid)); uv.put("role",x.optInt("type",2)==1?1:2); uv.put("active",x.optInt("active",1)==0?0:1); uv.put("updated_at",now());
                    if(localId>0) db.update("app_users",uv,"id=?",new String[]{String.valueOf(localId)}); else { uv.put("pin_hash",""); uv.put("created_at",now()); db.insertOrThrow("app_users",null,uv); }
                }
                Cursor linkedUsers=db.rawQuery("SELECT id,server_id FROM app_users WHERE COALESCE(server_id,0)>0",null);
                while(linkedUsers.moveToNext()){ long lid=linkedUsers.getLong(0), sid=linkedUsers.getLong(1); if(receivedUserIds.contains(sid)) continue; Cursor pend=db.rawQuery("SELECT 1 FROM mobile_user_ops WHERE local_user_id=? LIMIT 1",new String[]{String.valueOf(lid)}); boolean hp=pend.moveToFirst(); pend.close(); if(!hp) db.delete("app_users","id=?",new String[]{String.valueOf(lid)}); }
                linkedUsers.close();
            }

            JSONArray salaries=data.optJSONArray("salaries");
            JSONArray advances=data.optJSONArray("avances");
            JSONArray payrolls=data.optJSONArray("paies");
            JSONArray payrollPayments=data.optJSONArray("paie_paiements");
            JSONArray packs=data.optJSONArray("packs");
            JSONArray packArticles=data.optJSONArray("pack_articles");
            JSONObject systemInfo=data.optJSONObject("system_info");

            if (systemInfo != null) {
                putSetting(db, "ticket_company_name", systemInfo.optString("name", ""));
                putSetting(db, "ticket_company_address", systemInfo.optString("address", ""));
                putSetting(db, "ticket_company_phone", systemInfo.optString("phone", ""));
                putSetting(db, "ticket_company_nif", systemInfo.optString("nif", ""));
                putSetting(db, "ticket_company_stat", systemInfo.optString("stat", ""));
                putSetting(db, "ticket_message", systemInfo.optString("msg", ""));
            }

            if (emps!=null) {
                db.delete("emplacements",null,null);
                for(int i=0;i<emps.length();i++){JSONObject x=emps.getJSONObject(i);ContentValues v=new ContentValues();
                    v.put("id",x.getLong("id"));v.put("nom",x.optString("nom","Emplacement"));db.insertWithOnConflict("emplacements",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
            }
            if (clients!=null) {
                for(int i=0;i<clients.length();i++){JSONObject x=clients.getJSONObject(i);ContentValues v=new ContentValues();
                    v.put("server_id",x.getLong("id"));v.put("fullname",x.optString("fullname","Client"));
                    v.put("contact",x.optString("contact",""));v.put("address",x.optString("address",""));v.put("local_only",0);
                    Cursor old=db.rawQuery("SELECT id FROM clients WHERE server_id=?",new String[]{String.valueOf(x.getLong("id"))});
                    if(old.moveToFirst()) db.update("clients",v,"id=?",new String[]{String.valueOf(old.getLong(0))});
                    else db.insert("clients",null,v); old.close();}
            }
            if (products!=null) {
                // Les produits serveur non modifiés localement sont rafraîchis.
                // Les produits locaux (ID négatif) et les modifications SQLite (local_dirty=1)
                // sont conservés afin qu'une synchronisation ne les efface pas.
                db.delete("produits", "id>0 AND COALESCE(local_dirty,0)=0", null);
                for(int i=0;i<products.length();i++){
                    JSONObject x=products.getJSONObject(i);
                    long serverProductId=x.getLong("id");
                    Cursor keep=db.rawQuery("SELECT COALESCE(local_dirty,0) FROM produits WHERE id=? LIMIT 1",
                            new String[]{String.valueOf(serverProductId)});
                    boolean localOverride=keep.moveToFirst() && keep.getInt(0)==1;
                    keep.close();
                    if(localOverride) continue;
                    ContentValues v=new ContentValues();
                    v.put("id",serverProductId);v.put("name",x.optString("name","Produit"));v.put("price",x.optDouble("price",0));
                    v.put("status",x.optInt("status",1));v.put("image_url",x.optString("image_url",""));v.put("local_dirty",0);v.put("local_updated_at","");
                    db.insertWithOnConflict("produits",null,v,SQLiteDatabase.CONFLICT_REPLACE);
                }
            }
            if (variants!=null) {
                // Les variantes locales négatives restent disponibles hors ligne.
                db.delete("stocks", "variante_id>0", null);
                db.delete("variantes", "id>0", null);
                for(int i=0;i<variants.length();i++){JSONObject x=variants.getJSONObject(i);ContentValues v=new ContentValues();
                    v.put("id",x.getLong("id"));v.put("service_id",x.getLong("service_id"));v.put("couleur",x.optString("couleur",""));
                    v.put("taille",x.optString("taille",""));v.put("code_barre",x.optString("code_barre",""));v.put("prix",x.optDouble("prix",0));
                    v.put("image_url",x.optString("image_url",""));db.insertWithOnConflict("variantes",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
            }
            if (stocks!=null) {
                for(int i=0;i<stocks.length();i++){JSONObject x=stocks.getJSONObject(i);ContentValues v=new ContentValues();
                    v.put("variante_id",x.getLong("variante_id"));v.put("emplacement_id",x.getLong("emplacement_id"));v.put("quantite",x.optDouble("quantite",0));
                    db.insertWithOnConflict("stocks",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
            }
            if (salaries!=null) {
                for(int i=0;i<salaries.length();i++){
                    JSONObject x=salaries.getJSONObject(i);
                    long serverId=x.optLong("id",x.optLong("server_id",0));
                    if(serverId<=0) continue;
                    String mat=x.optString("matricule","").trim();
                    long localId=0;
                    Cursor old=db.rawQuery("SELECT id FROM salaries WHERE server_id=?",new String[]{String.valueOf(serverId)});
                    if(old.moveToFirst()) localId=old.getLong(0);
                    old.close();
                    if(localId<=0 && !mat.isEmpty()){
                        old=db.rawQuery("SELECT id FROM salaries WHERE matricule=?",new String[]{mat});
                        if(old.moveToFirst()) localId=old.getLong(0);
                        old.close();
                    }
                    if(localId>0){
                        Cursor pending=db.rawQuery("SELECT 1 FROM mobile_salary_ops WHERE local_salary_id=? LIMIT 1",new String[]{String.valueOf(localId)});
                        boolean hasPending=pending.moveToFirst(); pending.close();
                        if(hasPending) continue;
                    }
                    ContentValues v=new ContentValues();
                    v.put("server_id",serverId);
                    if(mat.isEmpty()) v.putNull("matricule"); else v.put("matricule",mat);
                    v.put("nom",x.optString("nom","Salarié"));
                    v.put("telephone",x.optString("telephone",x.optString("contact","")));
                    v.put("email",x.optString("email",""));
                    v.put("address",x.optString("address",x.optString("adresse","")));
                    v.put("salaire_base",x.optDouble("salaire_base",0));
                    v.put("allocation_repas_jour",x.optDouble("allocation_repas_jour",x.optDouble("allocation_repas",0)));
                    v.put("jours_repas_defaut",x.optDouble("jours_repas_defaut",26));
                    v.put("actif",x.optInt("actif",x.optInt("status",1)));
                    v.put("local_only",0);
                    if(localId>0) db.update("salaries",v,"id=?",new String[]{String.valueOf(localId)});
                    else db.insertWithOnConflict("salaries",null,v,SQLiteDatabase.CONFLICT_REPLACE);
                }
            }

            if (advances != null) {
                for (int i = 0; i < advances.length(); i++) {
                    JSONObject x = advances.getJSONObject(i);
                    long serverId = x.optLong("id", x.optLong("server_id", 0));
                    long salaryServerId = x.optLong("salarie_id", 0);
                    if (serverId <= 0 || salaryServerId <= 0) continue;
                    long localSalaryId = localSalaryIdForServer(db, salaryServerId);
                    if (localSalaryId <= 0) continue;
                    String date = x.optString("date_avance", "").trim();
                    double amount = x.optDouble("montant", 0);
                    if (date.isEmpty() || amount <= 0) continue;

                    long localAdvanceId = 0;
                    Cursor old = db.rawQuery("SELECT id FROM avances WHERE server_id=? LIMIT 1", new String[]{String.valueOf(serverId)});
                    if (old.moveToFirst()) localAdvanceId = old.getLong(0);
                    old.close();
                    if (localAdvanceId <= 0) {
                        old = db.rawQuery("SELECT id FROM avances WHERE salarie_id=? AND date_avance=? AND ABS(montant-?)<0.01 AND server_id IS NULL ORDER BY id LIMIT 1",
                                new String[]{String.valueOf(localSalaryId), date, String.valueOf(amount)});
                        if (old.moveToFirst()) localAdvanceId = old.getLong(0);
                        old.close();
                    }
                    ContentValues v = new ContentValues();
                    v.put("server_id", serverId);
                    v.put("salarie_id", localSalaryId);
                    v.put("date_avance", date);
                    v.put("montant", round2(amount));
                    v.put("remarque", x.optString("remarque", ""));
                    v.put("created_at", x.optString("created_at", x.optString("date_creation", now())));
                    if (localAdvanceId > 0) db.update("avances", v, "id=?", new String[]{String.valueOf(localAdvanceId)});
                    else db.insertOrThrow("avances", null, v);
                }
            }

            if (payrolls != null) {
                for (int i = 0; i < payrolls.length(); i++) {
                    JSONObject x = payrolls.getJSONObject(i);
                    long serverId = x.optLong("id", x.optLong("server_id", 0));
                    long salaryServerId = x.optLong("salarie_id", 0);
                    if (serverId <= 0 || salaryServerId <= 0) continue;
                    long localSalaryId = localSalaryIdForServer(db, salaryServerId);
                    if (localSalaryId <= 0) continue;
                    String month = x.optString("mois_paie", "").trim();
                    if (!month.matches("\\d{4}-\\d{2}")) month = "";
                    String start = x.optString("periode_debut", "").trim();
                    String end = x.optString("periode_fin", "").trim();
                    if (month.isEmpty() && start.length() >= 7) month = start.substring(0, 7);
                    if (month.isEmpty()) continue;
                    if (start.isEmpty() || end.isEmpty()) {
                        String[] period = monthPeriod(month);
                        if (start.isEmpty()) start = period[0];
                        if (end.isEmpty()) end = period[1];
                    }

                    long localPayrollId = 0;
                    Cursor old = db.rawQuery("SELECT id FROM paies WHERE server_id=? LIMIT 1", new String[]{String.valueOf(serverId)});
                    if (old.moveToFirst()) localPayrollId = old.getLong(0);
                    old.close();
                    if (localPayrollId <= 0) {
                        old = db.rawQuery(
                                "SELECT id FROM paies WHERE salarie_id=? AND periode_debut=? AND periode_fin=? LIMIT 1",
                                new String[]{String.valueOf(localSalaryId), start, end}
                        );
                        if (old.moveToFirst()) localPayrollId = old.getLong(0);
                        old.close();
                    }
                    ContentValues v = new ContentValues();
                    v.put("server_id", serverId);
                    v.put("salarie_id", localSalaryId);
                    v.put("mois_paie", month);
                    v.put("periode_debut", start);
                    v.put("periode_fin", end);
                    v.put("salaire_base", x.optDouble("salaire_base", 0));
                    v.put("jours_travailles", x.optDouble("jours_travailles", 0));
                    v.put("allocation_repas_jour", x.optDouble("allocation_repas_jour", 0));
                    v.put("jours_repas", x.optDouble("jours_repas", x.optDouble("jours_travailles", 0)));
                    v.put("allocation_repas_total", x.optDouble("allocation_repas_total", 0));
                    v.put("avance", x.optDouble("avance", 0));
                    v.put("net_a_payer", x.optDouble("net_a_payer", 0));
                    v.put("remarque", x.optString("remarque", ""));
                    v.put("created_at", x.optString("created_at", x.optString("date_creation", now())));
                    v.put("updated_at", x.optString("updated_at", x.optString("date_modification", now())));
                    if (localPayrollId > 0) db.update("paies", v, "id=?", new String[]{String.valueOf(localPayrollId)});
                    else db.insertOrThrow("paies", null, v);
                }
            }

            if (payrollPayments != null) {
                for (int i = 0; i < payrollPayments.length(); i++) {
                    JSONObject x = payrollPayments.getJSONObject(i);
                    long serverId = x.optLong("id", x.optLong("server_id", 0));
                    long payrollServerId = x.optLong("paie_id", 0);
                    if (serverId <= 0 || payrollServerId <= 0) continue;
                    long localPayrollId = localPayrollIdForServer(db, payrollServerId);
                    if (localPayrollId <= 0) continue;
                    String date = x.optString("date_paiement", "").trim();
                    double amount = x.optDouble("montant", 0);
                    if (date.isEmpty() || amount <= 0) continue;

                    long localPaymentId = 0;
                    Cursor old = db.rawQuery("SELECT id FROM paie_paiements WHERE server_id=? LIMIT 1", new String[]{String.valueOf(serverId)});
                    if (old.moveToFirst()) localPaymentId = old.getLong(0);
                    old.close();
                    if (localPaymentId <= 0) {
                        old = db.rawQuery("SELECT id FROM paie_paiements WHERE paie_id=? AND date_paiement=? AND ABS(montant-?)<0.01 AND server_id IS NULL ORDER BY id LIMIT 1",
                                new String[]{String.valueOf(localPayrollId), date, String.valueOf(amount)});
                        if (old.moveToFirst()) localPaymentId = old.getLong(0);
                        old.close();
                    }
                    ContentValues v = new ContentValues();
                    v.put("server_id", serverId);
                    v.put("paie_id", localPayrollId);
                    v.put("montant", round2(amount));
                    v.put("date_paiement", date);
                    v.put("mode_paiement", x.optString("mode_paiement", "ESPECES"));
                    v.put("reference", x.optString("reference", ""));
                    v.put("remarque", x.optString("remarque", ""));
                    v.put("created_at", x.optString("created_at", x.optString("date_creation", now())));
                    if (localPaymentId > 0) db.update("paie_paiements", v, "id=?", new String[]{String.valueOf(localPaymentId)});
                    else db.insertOrThrow("paie_paiements", null, v);
                }
            }

            // Packs : le serveur est appliqué après les variantes afin que les liaisons
            // variante_id soient déjà disponibles dans SQLite.
            applyPackCatalog(db, packs, packArticles);

            seedEmplacements(db);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }



    /**
     * Synchronisation serveur -> SQLite des packs et de toute leur composition.
     * Les IDs MySQL sont conservés dans packs.server_id ; l'ID SQLite local reste libre.
     * Un pack local en attente n'est jamais écrasé avant son envoi.
     */
    private void applyPackCatalog(SQLiteDatabase db, JSONArray serverPacks, JSONArray serverArticles) throws Exception {
        if (serverPacks == null) return;
        if (serverArticles == null) serverArticles = new JSONArray();

        HashSet<Long> receivedServerIds = new HashSet<>();

        for (int i = 0; i < serverPacks.length(); i++) {
            JSONObject sp = serverPacks.getJSONObject(i);
            long serverId = sp.optLong("id", 0);
            if (serverId <= 0) continue;
            receivedServerIds.add(serverId);

            long localId = 0;
            Cursor c = db.rawQuery("SELECT id FROM packs WHERE server_id=? LIMIT 1",
                    new String[]{String.valueOf(serverId)});
            if (c.moveToFirst()) localId = c.getLong(0);
            c.close();

            // Premier passage après migration : rapprocher les packs standards
            // déjà présents en SQLite avec le pack MySQL portant le même nom.
            if (localId <= 0) {
                String name = sp.optString("nom", "").trim();
                c = db.rawQuery(
                        "SELECT p.id FROM packs p WHERE COALESCE(p.server_id,0)=0 " +
                        "AND TRIM(p.nom)=TRIM(?) COLLATE NOCASE " +
                        "AND NOT EXISTS (SELECT 1 FROM mobile_pack_ops o WHERE o.local_pack_id=p.id) " +
                        "ORDER BY p.id LIMIT 1",
                        new String[]{name});
                if (c.moveToFirst()) localId = c.getLong(0);
                c.close();
            }

            // Ne jamais écraser une modification SQLite qui attend encore d'être envoyée.
            if (localId > 0) {
                c = db.rawQuery("SELECT 1 FROM mobile_pack_ops WHERE local_pack_id=? LIMIT 1",
                        new String[]{String.valueOf(localId)});
                boolean pending = c.moveToFirst();
                c.close();
                if (pending) continue;
            }

            ContentValues pv = new ContentValues();
            pv.put("server_id", serverId);
            pv.put("nom", sp.optString("nom", "Pack"));
            pv.put("description", sp.optString("description", ""));
            pv.put("slogan", sp.optString("slogan", ""));
            String category = sp.optString("categorie", "Nouveau-né").trim();
            pv.put("categorie", category.isEmpty() ? "Nouveau-né" : category);
            pv.put("prix_vente", Math.max(0, sp.optDouble("prix_vente", 0)));
            pv.put("actif", sp.optInt("actif", 1) == 0 ? 0 : 1);
            pv.put("local_only", 0);
            pv.put("created_at", sp.optString("created_at", now()));
            pv.put("updated_at", sp.optString("updated_at", now()));

            if (localId > 0) {
                db.update("packs", pv, "id=?", new String[]{String.valueOf(localId)});
            } else {
                localId = db.insertOrThrow("packs", null, pv);
            }

            // La composition du serveur remplace exactement la composition locale
            // une fois que le pack local n'a plus d'opération en attente.
            db.delete("pack_articles", "pack_id=?", new String[]{String.valueOf(localId)});
            for (int j = 0; j < serverArticles.length(); j++) {
                JSONObject sa = serverArticles.getJSONObject(j);
                if (sa.optLong("pack_id", 0) != serverId) continue;

                ContentValues av = new ContentValues();
                av.put("pack_id", localId);
                String groupCode = sa.optString("groupe_code", "").trim();
                if (groupCode.isEmpty()) groupCode = "S" + serverId + "_" + sa.optLong("id", j + 1);
                av.put("groupe_code", groupCode);
                long variantId = sa.optLong("variante_id", 0);
                if (variantId > 0) av.put("variante_id", variantId); else av.putNull("variante_id");
                av.put("nom_article", sa.optString("nom_article", "Article"));
                double qty = roundHalf(sa.optDouble("quantite", 1));
                av.put("quantite", qty < 0.5 ? 0.5 : qty);
                av.put("prix_unitaire", Math.max(0, sa.optDouble("prix_unitaire", 0)));
                av.put("ordre", sa.optInt("ordre", j + 1));
                db.insertOrThrow("pack_articles", null, av);
            }
        }

        // Un pack déjà synchronisé qui n'existe plus en MySQL doit également
        // disparaître d'Android, sauf s'il comporte une modification locale en attente.
        Cursor linked = db.rawQuery(
                "SELECT id,server_id FROM packs WHERE COALESCE(server_id,0)>0", null);
        try {
            while (linked.moveToNext()) {
                long localId = linked.getLong(0);
                long serverId = linked.getLong(1);
                if (receivedServerIds.contains(serverId)) continue;
                Cursor pending = db.rawQuery(
                        "SELECT 1 FROM mobile_pack_ops WHERE local_pack_id=? LIMIT 1",
                        new String[]{String.valueOf(localId)});
                boolean hasPending = pending.moveToFirst();
                pending.close();
                if (!hasPending) db.delete("packs", "id=?", new String[]{String.valueOf(localId)});
            }
        } finally { linked.close(); }
    }

    private long localSalaryIdForServer(SQLiteDatabase db, long serverId) {
        Cursor c = db.rawQuery("SELECT id FROM salaries WHERE server_id=? LIMIT 1", new String[]{String.valueOf(serverId)});
        long id = c.moveToFirst() ? c.getLong(0) : 0;
        c.close();
        return id;
    }

    private long localPayrollIdForServer(SQLiteDatabase db, long serverId) {
        Cursor c = db.rawQuery("SELECT id FROM paies WHERE server_id=? LIMIT 1", new String[]{String.valueOf(serverId)});
        long id = c.moveToFirst() ? c.getLong(0) : 0;
        c.close();
        return id;
    }

    private void putSetting(SQLiteDatabase db, String key, String value) {
        ContentValues v = new ContentValues();
        v.put("k", key == null ? "" : key.trim());
        v.put("v", value == null ? "" : value.trim());
        db.insertWithOnConflict("settings", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public String setting(String key, String fallback) {
        String fb = fallback == null ? "" : fallback;
        if (key == null || key.trim().isEmpty()) return fb;
        Cursor c = getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=? LIMIT 1", new String[]{key.trim()});
        String out = fb;
        if (c.moveToFirst() && !c.isNull(0)) out = c.getString(0);
        c.close();
        return out == null ? fb : out;
    }

    public int advanceCount() { return (int) DatabaseUtilsCompat.count(getReadableDatabase(), "avances"); }
    public int payrollTotalCount() { return (int) DatabaseUtilsCompat.count(getReadableDatabase(), "paies"); }
    public int payrollPaymentCount() { return (int) DatabaseUtilsCompat.count(getReadableDatabase(), "paie_paiements"); }

    // ========================= PAIE SQLITE =========================
    public Cursor salaries() {
        return getReadableDatabase().rawQuery(
                "SELECT id,COALESCE(matricule,''),nom,COALESCE(telephone,''),COALESCE(email,''),COALESCE(address,'')," +
                "COALESCE(salaire_base,0),COALESCE(allocation_repas_jour,0),COALESCE(jours_repas_defaut,26),COALESCE(actif,1) " +
                "FROM salaries ORDER BY nom,id", null);
    }

    public String[] latestPayrollPeriod(long salarieId) {
        if (salarieId <= 0) return null;
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT periode_debut,periode_fin FROM paies WHERE salarie_id=? " +
                "AND COALESCE(periode_debut,'')<>'' AND COALESCE(periode_fin,'')<>'' " +
                "ORDER BY periode_fin DESC,id DESC LIMIT 1",
                new String[]{String.valueOf(salarieId)});
        String[] out = null;
        if (c.moveToFirst()) out = new String[]{c.getString(0), c.getString(1)};
        c.close();
        return out;
    }

    public String[] latestPayrollPeriodForMonth(long salarieId, String periodGroup) throws Exception {
        String g = normalizeMonth(periodGroup);
        if (salarieId <= 0) return null;
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT periode_debut,periode_fin FROM paies WHERE salarie_id=? AND " +
                "(CASE WHEN periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' " +
                "THEN substr(periode_fin,1,7) ELSE mois_paie END)=? " +
                "ORDER BY periode_fin DESC,id DESC LIMIT 1",
                new String[]{String.valueOf(salarieId), g});
        String[] out = null;
        if (c.moveToFirst()) out = new String[]{c.getString(0), c.getString(1)};
        c.close();
        return out;
    }

    /**
     * Retourne la période propre du salarié pour le groupe demandé (ex. 2026-09).
     * Si une fiche existe déjà dans ce groupe, ses dates sont conservées.
     * Sinon, le cycle de la dernière fiche du salarié est décalé vers le groupe demandé.
     * Ex.: 21/08-20/09 => groupe suivant 2026-10 = 21/09-20/10.
     */
    public String[] suggestedPayrollPeriod(long salarieId, String periodGroup) throws Exception {
        String g = normalizeMonth(periodGroup);
        if (salarieId <= 0) return monthPeriod(g);

        String[] existing = latestPayrollPeriodForMonth(salarieId, g);
        if (existing != null) return existing;

        String[] latest = latestPayrollPeriod(salarieId);
        if (latest == null) return monthPeriod(g);

        try {
            String start = normalizeDate(latest[0]);
            String end = normalizeDate(latest[1]);
            int sy = Integer.parseInt(start.substring(0,4));
            int sm = Integer.parseInt(start.substring(5,7));
            int sd = Integer.parseInt(start.substring(8,10));
            int ey = Integer.parseInt(end.substring(0,4));
            int em = Integer.parseInt(end.substring(5,7));
            int ed = Integer.parseInt(end.substring(8,10));
            int ty = Integer.parseInt(g.substring(0,4));
            int tm = Integer.parseInt(g.substring(5,7));

            int spanMonths = (ey * 12 + (em - 1)) - (sy * 12 + (sm - 1));
            if (spanMonths < 0 || spanMonths > 12) return monthPeriod(g);

            int targetEndIndex = ty * 12 + (tm - 1);
            int targetStartIndex = targetEndIndex - spanMonths;
            int tsy = Math.floorDiv(targetStartIndex, 12);
            int tsm = Math.floorMod(targetStartIndex, 12) + 1;

            String targetStart = dateClamped(tsy, tsm, sd);
            String targetEnd = dateClamped(ty, tm, ed);
            if (targetStart.compareTo(targetEnd) > 0) return monthPeriod(g);
            return new String[]{targetStart, targetEnd};
        } catch (Exception ignored) {
            return monthPeriod(g);
        }
    }

    public Cursor payrollPeriodsForEmployee(long salarieId) {
        return getReadableDatabase().rawQuery(
                "SELECT mois_paie,periode_debut,periode_fin FROM paies WHERE salarie_id=? " +
                "AND COALESCE(periode_debut,'')<>'' AND COALESCE(periode_fin,'')<>'' " +
                "GROUP BY mois_paie,periode_debut,periode_fin ORDER BY periode_fin DESC,periode_debut DESC",
                new String[]{String.valueOf(salarieId)});
    }

    public int payrollPeriodCountForEmployee(long salarieId) {
        if (salarieId <= 0) return 0;
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM (SELECT 1 FROM paies WHERE salarie_id=? " +
                "AND COALESCE(periode_debut,'')<>'' AND COALESCE(periode_fin,'')<>'' " +
                "GROUP BY mois_paie,periode_debut,periode_fin)",
                new String[]{String.valueOf(salarieId)});
        int out = c.moveToFirst() ? c.getInt(0) : 0;
        c.close();
        return out;
    }

    public Cursor payrollMonths() {
        // Compatibilité du nom de méthode : la valeur retournée représente désormais
        // le GROUPE DE PÉRIODE, déterminé d'abord par le mois de periode_fin.
        return getReadableDatabase().rawQuery(
                "SELECT DISTINCT (CASE " +
                "WHEN periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' THEN substr(periode_fin,1,7) " +
                "ELSE mois_paie END) AS periode_groupe " +
                "FROM paies WHERE (CASE " +
                "WHEN periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' THEN substr(periode_fin,1,7) " +
                "ELSE mois_paie END) GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]' " +
                "ORDER BY periode_groupe",
                null);
    }

    public synchronized long saveSalaryEmployee(long id, String matricule, String nom, String telephone, String email, String address,
                                                double salaireBase, double repasJour, double joursRepasDefaut, boolean actif) throws Exception {
        String n = safe(nom);
        if (n.isEmpty()) throw new Exception("Nom du salarié obligatoire.");
        if (salaireBase < 0 || repasJour < 0 || joursRepasDefaut < 0) throw new Exception("Montant ou jours invalides.");
        ContentValues v = new ContentValues();
        String mat = safe(matricule);
        if (mat.isEmpty()) v.putNull("matricule"); else v.put("matricule", mat);
        v.put("nom", n); v.put("telephone", safe(telephone)); v.put("email", safe(email)); v.put("address", safe(address));
        v.put("salaire_base", round2(salaireBase)); v.put("allocation_repas_jour", round2(repasJour));
        v.put("jours_repas_defaut", round2(joursRepasDefaut)); v.put("actif", actif ? 1 : 0);
        v.put("local_only", 1);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long localId=id;
            if (id > 0) {
                int count = db.update("salaries", v, "id=?", new String[]{String.valueOf(id)});
                if (count == 0) throw new Exception("Salarié introuvable.");
            } else {
                v.put("created_at", now());
                localId=db.insertOrThrow("salaries", null, v);
            }
            enqueueSalaryOp(db, localId);
            db.setTransactionSuccessful();
            return localId;
        } catch (android.database.sqlite.SQLiteConstraintException ex) {
            throw new Exception("Ce matricule existe déjà.");
        } finally { db.endTransaction(); }
    }

    public synchronized void deleteSalaryEmployee(long id) throws Exception {
        if (id <= 0) return;
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM paies WHERE salarie_id=?", new String[]{String.valueOf(id)});
        boolean used = c.moveToFirst() && c.getLong(0) > 0; c.close();
        if (used) throw new Exception("Impossible de supprimer : des paies existent pour ce salarié. Désactivez-le plutôt.");
        db.delete("salaries", "id=?", new String[]{String.valueOf(id)});
    }

    public Cursor advances(String month, long salarieId) {
        String m = safe(month);
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        StringBuilder where = new StringBuilder(" WHERE 1=1 ");
        if (!m.isEmpty()) { where.append(" AND substr(a.date_avance,1,7)=? "); args.add(m); }
        if (salarieId > 0) { where.append(" AND a.salarie_id=? "); args.add(String.valueOf(salarieId)); }
        return getReadableDatabase().rawQuery(
                "SELECT a.id,a.salarie_id,COALESCE(s.matricule,''),s.nom,a.date_avance,a.montant,COALESCE(a.remarque,'') " +
                "FROM avances a JOIN salaries s ON s.id=a.salarie_id" + where + " ORDER BY a.date_avance DESC,a.id DESC",
                args.toArray(new String[0]));
    }

    public Cursor advancesPeriod(String startDate, String endDate, long salarieId) throws Exception {
        String from = normalizeDate(startDate);
        String to = normalizeDate(endDate);
        if (from.compareTo(to) > 0) throw new Exception("La date de début doit être avant la date de fin.");
        java.util.ArrayList<String> args = new java.util.ArrayList<>();
        StringBuilder where = new StringBuilder(" WHERE date(a.date_avance) BETWEEN date(?) AND date(?) ");
        args.add(from); args.add(to);
        if (salarieId > 0) { where.append(" AND a.salarie_id=? "); args.add(String.valueOf(salarieId)); }
        return getReadableDatabase().rawQuery(
                "SELECT a.id,a.salarie_id,COALESCE(s.matricule,''),s.nom,a.date_avance,a.montant,COALESCE(a.remarque,'') " +
                "FROM avances a JOIN salaries s ON s.id=a.salarie_id" + where + " ORDER BY a.date_avance DESC,a.id DESC",
                args.toArray(new String[0]));
    }

    public synchronized long addAdvance(long salarieId, String date, double montant, String remarque) throws Exception {
        if (salarieId <= 0) throw new Exception("Sélectionnez un salarié.");
        if (montant <= 0) throw new Exception("Montant d'avance invalide.");
        String advanceDate = normalizeDate(date);
        ContentValues v = new ContentValues();
        v.put("salarie_id", salarieId); v.put("date_avance", advanceDate); v.put("montant", round2(montant));
        v.put("remarque", safe(remarque)); v.put("created_at", now());
        SQLiteDatabase db = getWritableDatabase();
        long id = db.insertOrThrow("avances", null, v);
        enqueueAdvanceOp(db, id);
        return id;
    }

    public synchronized void deleteAdvance(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("mobile_advance_ops", "local_advance_id=?", new String[]{String.valueOf(id)});
        db.delete("avances", "id=?", new String[]{String.valueOf(id)});
    }

    private double advancesTotal(SQLiteDatabase db, long salarieId, String startDate, String endDate) {
        Cursor c = db.rawQuery("SELECT COALESCE(SUM(montant),0) FROM avances WHERE salarie_id=? AND date(date_avance) BETWEEN date(?) AND date(?)",
                new String[]{String.valueOf(salarieId), startDate, endDate});
        double x = c.moveToFirst() ? c.getDouble(0) : 0; c.close(); return round2(x);
    }

    public synchronized long generatePayroll(long salarieId, String periodGroup, double joursRepas, boolean overwrite) throws Exception {
        String g = normalizeMonth(periodGroup);
        String[] period = suggestedPayrollPeriod(salarieId, g);
        return generatePayroll(salarieId, g, period[0], period[1], joursRepas, overwrite);
    }

    public synchronized long generatePayroll(long salarieId, String periodGroup, String periodStart, String periodEnd, double joursRepas, boolean overwrite) throws Exception {
        if (salarieId <= 0) throw new Exception("Sélectionnez un salarié.");
        String g = normalizeMonth(periodGroup);
        String startDate = normalizeDate(periodStart);
        String endDate = normalizeDate(periodEnd);
        if (startDate.compareTo(endDate) > 0) throw new Exception("La date de début doit être avant la date de fin.");
        SQLiteDatabase db = getWritableDatabase();
        Cursor s = db.rawQuery("SELECT salaire_base,allocation_repas_jour,COALESCE(actif,1) FROM salaries WHERE id=?",
                new String[]{String.valueOf(salarieId)});
        if (!s.moveToFirst()) { s.close(); throw new Exception("Salarié introuvable."); }
        double base = s.getDouble(0), repasJour = s.getDouble(1); int actif = s.getInt(2); s.close();
        if (actif != 1) throw new Exception("Ce salarié est inactif.");

        // Chaque salarié est calculé UNIQUEMENT avec sa propre période.
        double jr = Math.max(0, joursRepas);
        double repasTotal = round2(repasJour * jr);
        double avance = advancesTotal(db, salarieId, startDate, endDate);
        double net = Math.max(0, round2(base + repasTotal - avance));

        ContentValues v = new ContentValues();
        v.put("salarie_id", salarieId);
        // mois_paie reste une clé de regroupement/compatibilité. Le calcul se fait avec les deux dates ci-dessous.
        v.put("mois_paie", g);
        v.put("periode_debut", startDate); v.put("periode_fin", endDate);
        v.put("salaire_base", round2(base)); v.put("jours_travailles", jr); v.put("allocation_repas_jour", round2(repasJour));
        v.put("jours_repas", jr); v.put("allocation_repas_total", repasTotal); v.put("avance", avance); v.put("net_a_payer", net); v.put("updated_at", now());

        Cursor e = db.rawQuery(
                "SELECT id FROM paies WHERE salarie_id=? AND periode_debut=? AND periode_fin=? ORDER BY id DESC LIMIT 1",
                new String[]{String.valueOf(salarieId), startDate, endDate});
        long existing = e.moveToFirst() ? e.getLong(0) : 0; e.close();
        if (existing > 0) {
            if (!overwrite) return existing;
            db.update("paies", v, "id=?", new String[]{String.valueOf(existing)});
            return existing;
        }
        v.put("created_at", now());
        return db.insertOrThrow("paies", null, v);
    }

    public synchronized int generateAllPayrolls(String periodGroup) throws Exception {
        String g = normalizeMonth(periodGroup);
        Cursor c = getReadableDatabase().rawQuery("SELECT id,COALESCE(jours_repas_defaut,26) FROM salaries WHERE actif=1 ORDER BY id", null);
        int created = 0;
        while (c.moveToNext()) {
            long id = c.getLong(0); double days = c.getDouble(1);
            Cursor e = getReadableDatabase().rawQuery(
                    "SELECT id FROM paies WHERE salarie_id=? AND (CASE " +
                    "WHEN periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' THEN substr(periode_fin,1,7) " +
                    "ELSE mois_paie END)=? LIMIT 1",
                    new String[]{String.valueOf(id), g});
            boolean exists = e.moveToFirst(); e.close();
            if (!exists) {
                String[] ownPeriod = suggestedPayrollPeriod(id, g);
                generatePayroll(id, g, ownPeriod[0], ownPeriod[1], days, false);
                created++;
            }
        }
        c.close();
        return created;
    }

    public synchronized int recalculatePayrollPeriod(String periodGroup) throws Exception {
        String g = normalizeMonth(periodGroup);
        SQLiteDatabase db = getWritableDatabase();

        Cursor c = db.rawQuery(
                "SELECT p.id,p.salarie_id,COALESCE(p.jours_repas,0),p.periode_debut,p.periode_fin " +
                "FROM paies p WHERE (CASE " +
                "WHEN p.periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' THEN substr(p.periode_fin,1,7) " +
                "ELSE p.mois_paie END)=? ORDER BY p.id",
                new String[]{g});

        java.util.ArrayList<Long> payrollIds = new java.util.ArrayList<>();
        java.util.ArrayList<Long> salaryIds = new java.util.ArrayList<>();
        java.util.ArrayList<Double> days = new java.util.ArrayList<>();
        java.util.ArrayList<String> starts = new java.util.ArrayList<>();
        java.util.ArrayList<String> ends = new java.util.ArrayList<>();

        while (c.moveToNext()) {
            payrollIds.add(c.getLong(0));
            salaryIds.add(c.getLong(1));
            days.add(c.getDouble(2));
            starts.add(c.getString(3));
            ends.add(c.getString(4));
        }
        c.close();

        int updated = 0;
        db.beginTransaction();
        try {
            for (int i = 0; i < payrollIds.size(); i++) {
                long payrollId = payrollIds.get(i);
                long salarieId = salaryIds.get(i);
                String startDate = normalizeDate(starts.get(i));
                String endDate = normalizeDate(ends.get(i));
                double joursRepas = Math.max(0, days.get(i));

                // Toujours relire les valeurs ACTUELLES de la fiche salarié.
                Cursor s = db.rawQuery(
                        "SELECT COALESCE(salaire_base,0),COALESCE(allocation_repas_jour,0) " +
                        "FROM salaries WHERE id=? LIMIT 1",
                        new String[]{String.valueOf(salarieId)});
                if (!s.moveToFirst()) {
                    s.close();
                    continue;
                }

                double base = s.getDouble(0);
                double repasJour = s.getDouble(1);
                s.close();

                double repasTotal = round2(repasJour * joursRepas);

                // Avances uniquement dans la période propre de cette fiche.
                double avance = advancesTotal(db, salarieId, startDate, endDate);
                double net = Math.max(0, round2(base + repasTotal - avance));

                ContentValues v = new ContentValues();
                v.put("mois_paie", endDate.substring(0, 7)); // regroupement uniquement
                v.put("salaire_base", round2(base));
                v.put("allocation_repas_jour", round2(repasJour));
                v.put("jours_repas", joursRepas);
                v.put("allocation_repas_total", repasTotal);
                v.put("avance", avance);
                v.put("net_a_payer", net);
                v.put("updated_at", now());

                // Mise à jour directe de la fiche exacte.
                int n = db.update(
                        "paies",
                        v,
                        "id=?",
                        new String[]{String.valueOf(payrollId)}
                );
                if (n > 0) updated++;
            }

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

        return updated;
    }

    // Ancien nom conservé pour compatibilité avec d'éventuels appels existants.
    public synchronized int recalculatePayrollMonth(String month) throws Exception {
        return recalculatePayrollPeriod(month);
    }

    public Cursor payrolls(String periodGroup) throws Exception {
        String g = normalizeMonth(periodGroup);
        return getReadableDatabase().rawQuery(
                "SELECT p.id,p.salarie_id,COALESCE(s.matricule,''),s.nom,p.periode_debut,p.periode_fin,p.salaire_base," +
                "p.allocation_repas_total,p.avance,p.net_a_payer,COALESCE(SUM(pp.montant),0) total_paye," +
                "MAX(p.net_a_payer-COALESCE(SUM(pp.montant),0),0) reste,p.jours_repas,p.allocation_repas_jour " +
                "FROM paies p JOIN salaries s ON s.id=p.salarie_id LEFT JOIN paie_paiements pp ON pp.paie_id=p.id " +
                "WHERE (CASE WHEN p.periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' " +
                "THEN substr(p.periode_fin,1,7) ELSE p.mois_paie END)=? " +
                "GROUP BY p.id ORDER BY p.periode_fin DESC,p.periode_debut DESC,s.nom,p.id DESC",
                new String[]{g});
    }

    public synchronized long addPayrollPayment(long paieId, double montant, String datePaiement, String mode, String reference, String remarque) throws Exception {
        if (paieId <= 0 || montant <= 0) throw new Exception("Paiement invalide.");
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT p.net_a_payer-COALESCE(SUM(pp.montant),0) reste FROM paies p LEFT JOIN paie_paiements pp ON pp.paie_id=p.id WHERE p.id=? GROUP BY p.id",
                new String[]{String.valueOf(paieId)});
        if (!c.moveToFirst()) { c.close(); throw new Exception("Paie introuvable."); }
        double reste = Math.max(0,c.getDouble(0)); c.close();
        if (montant - reste > 0.009) throw new Exception("Le paiement dépasse le reste à payer.");
        String paymentDate = normalizeDate(datePaiement);
        ContentValues v = new ContentValues(); v.put("paie_id",paieId); v.put("montant",round2(montant));
        v.put("date_paiement", paymentDate); v.put("mode_paiement", safe(mode).isEmpty()?"ESPECES":safe(mode));
        v.put("reference",safe(reference)); v.put("remarque",safe(remarque)); v.put("created_at",now());
        return db.insertOrThrow("paie_paiements",null,v);
    }

    public Cursor payrollPayments(long paieId) {
        return getReadableDatabase().rawQuery("SELECT id,montant,date_paiement,mode_paiement,COALESCE(reference,''),COALESCE(remarque,'') FROM paie_paiements WHERE paie_id=? ORDER BY date_paiement DESC,id DESC",
                new String[]{String.valueOf(paieId)});
    }

    public synchronized void deletePayroll(long paieId) {
        getWritableDatabase().delete("paies","id=?",new String[]{String.valueOf(paieId)});
    }

    public int salaryEmployeeCount() { return (int) DatabaseUtilsCompat.count(getReadableDatabase(), "salaries"); }
    public int payrollCount(String periodGroup) {
        try {
            String g = normalizeMonth(periodGroup);
            Cursor c=getReadableDatabase().rawQuery(
                    "SELECT COUNT(*) FROM paies WHERE (CASE WHEN periode_fin GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]' " +
                    "THEN substr(periode_fin,1,7) ELSE mois_paie END)=?", new String[]{g});
            int n=c.moveToFirst()?c.getInt(0):0; c.close(); return n;
        } catch(Exception e){ return 0; }
    }

    // ---------------------------------------------------------------------
    // UTILISATEURS & SESSION LOCALE (V5.25.33)
    // ---------------------------------------------------------------------
    public static final class AppUser {
        public long id;
        public String firstname = "";
        public String lastname = "";
        public String username = "";
        public int role = 2;
        public boolean active = true;
        public boolean hasPin = false;
        public long serverId = 0;
        public boolean localOnly = true;

        public String displayName() {
            String full = (safe(firstname) + " " + safe(lastname)).trim();
            return full.isEmpty() ? safe(username) : full;
        }

        public String roleLabel() {
            return role == 1 ? "Administrateur" : "Utilisateur";
        }
    }

    public Cursor appUsers() {
        createUserTables(getWritableDatabase());
        return getReadableDatabase().rawQuery(
                "SELECT id,firstname,lastname,username,role,active," +
                        "CASE WHEN COALESCE(pin_hash,'')<>'' THEN 1 ELSE 0 END has_pin,COALESCE(server_id,0),COALESCE(local_only,1) " +
                        "FROM app_users ORDER BY active DESC,role ASC,lastname COLLATE NOCASE,firstname COLLATE NOCASE,username COLLATE NOCASE",
                null);
    }

    public Cursor activeAppUsers() {
        createUserTables(getWritableDatabase());
        return getReadableDatabase().rawQuery(
                "SELECT id,firstname,lastname,username,role,active," +
                        "CASE WHEN COALESCE(pin_hash,'')<>'' THEN 1 ELSE 0 END has_pin,COALESCE(server_id,0),COALESCE(local_only,1) " +
                        "FROM app_users WHERE active=1 ORDER BY role ASC,lastname COLLATE NOCASE,firstname COLLATE NOCASE,username COLLATE NOCASE",
                null);
    }

    public AppUser appUser(long id) {
        if (id <= 0) return null;
        createUserTables(getWritableDatabase());
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,firstname,lastname,username,role,active," +
                        "CASE WHEN COALESCE(pin_hash,'')<>'' THEN 1 ELSE 0 END has_pin,COALESCE(server_id,0),COALESCE(local_only,1) " +
                        "FROM app_users WHERE id=? LIMIT 1",
                new String[]{String.valueOf(id)});
        AppUser u = null;
        if (c.moveToFirst()) {
            u = new AppUser();
            u.id = c.getLong(0);
            u.firstname = safe(c.getString(1));
            u.lastname = safe(c.getString(2));
            u.username = safe(c.getString(3));
            u.role = c.getInt(4);
            u.active = c.getInt(5) == 1;
            u.hasPin = c.getInt(6) == 1;
            u.serverId = c.getLong(7);
            u.localOnly = c.getInt(8) == 1;
        }
        c.close();
        return u;
    }

    public long defaultAppUserId() {
        createUserTables(getWritableDatabase());
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id FROM app_users WHERE active=1 ORDER BY CASE WHEN role=1 THEN 0 ELSE 1 END,id LIMIT 1",
                null);
        long id = c.moveToFirst() ? c.getLong(0) : 0;
        c.close();
        return id;
    }

    public int appUserCount() {
        createUserTables(getWritableDatabase());
        return (int) DatabaseUtilsCompat.count(getReadableDatabase(), "app_users");
    }

    public synchronized long saveAppUser(long id, String firstname, String lastname,
                                         String username, int role, boolean active,
                                         String newPin, boolean changePin,
                                         String onlinePassword) throws Exception {
        SQLiteDatabase db = getWritableDatabase();
        createUserTables(db);
        String first = safe(firstname);
        String last = safe(lastname);
        String user = safe(username);
        if (first.isEmpty() && last.isEmpty()) throw new Exception("Saisissez le nom de l'utilisateur.");
        if (user.isEmpty()) throw new Exception("Nom d'utilisateur obligatoire.");
        if (user.length() < 2) throw new Exception("Nom d'utilisateur trop court.");
        if (role != 1 && role != 2) role = 2;

        if (id > 0) {
            AppUser oldUser = appUser(id);
            if (oldUser == null) throw new Exception("Utilisateur introuvable.");
            if (oldUser.role == 1 && oldUser.active && (role != 1 || !active) && activeAdminCount() <= 1) {
                throw new Exception("Impossible de retirer le dernier administrateur actif.");
            }
        }

        Cursor dup = db.rawQuery(
                "SELECT id FROM app_users WHERE LOWER(TRIM(username))=LOWER(TRIM(?)) AND id<>? LIMIT 1",
                new String[]{user, String.valueOf(id)});
        boolean exists = dup.moveToFirst();
        dup.close();
        if (exists) throw new Exception("Ce nom d'utilisateur existe déjà.");

        String pin = newPin == null ? "" : newPin.trim();
        if (changePin && !pin.isEmpty() && !pin.matches("\\d{4,8}")) {
            throw new Exception("Le PIN doit contenir 4 à 8 chiffres.");
        }
        String webPassword = onlinePassword == null ? "" : onlinePassword.trim();
        AppUser existingUser = id > 0 ? appUser(id) : null;
        long existingServerId = existingUser == null ? 0 : existingUser.serverId;
        if (existingServerId <= 0 && webPassword.isEmpty()) {
            throw new Exception("Mot de passe en ligne obligatoire pour synchroniser ce nouvel utilisateur.");
        }
        if (!webPassword.isEmpty() && webPassword.length() < 4) {
            throw new Exception("Le mot de passe en ligne doit contenir au moins 4 caractères.");
        }

        ContentValues v = new ContentValues();
        v.put("firstname", first);
        v.put("lastname", last);
        v.put("username", user);
        v.put("role", role);
        v.put("active", active ? 1 : 0);
        v.put("updated_at", now());
        if (changePin) v.put("pin_hash", pin.isEmpty() ? "" : sha256(pin));

        if (id > 0) {
            int n = db.update("app_users", v, "id=?", new String[]{String.valueOf(id)});
            if (n <= 0) throw new Exception("Utilisateur introuvable.");
            enqueueUserOp(db, id, "UPSERT", webPassword);
            return id;
        }

        v.put("server_id", 0);
        v.put("local_only", 1);
        v.put("created_at", now());
        if (!changePin) v.put("pin_hash", "");
        long newId = db.insertOrThrow("app_users", null, v);
        if (newId <= 0) throw new Exception("Création utilisateur impossible.");
        enqueueUserOp(db, newId, "UPSERT", webPassword);
        return newId;
    }

    public synchronized void setAppUserActive(long id, boolean active) throws Exception {
        AppUser u = appUser(id);
        if (u == null) throw new Exception("Utilisateur introuvable.");
        if (!active && u.role == 1 && activeAdminCount() <= 1) {
            throw new Exception("Impossible de désactiver le dernier administrateur.");
        }
        ContentValues v = new ContentValues();
        v.put("active", active ? 1 : 0);
        v.put("updated_at", now());
        SQLiteDatabase db = getWritableDatabase();
        db.update("app_users", v, "id=?", new String[]{String.valueOf(id)});
        enqueueUserOp(db, id, "UPSERT", "");
    }

    /**
     * Définit le PIN Android d'un utilisateur sans envoyer ce secret au serveur.
     * Le PIN reste strictement local et est stocké sous forme SHA-256.
     */
    public synchronized void setAppUserPin(long id, String pin) throws Exception {
        if (appUser(id) == null) throw new Exception("Utilisateur introuvable.");
        String value = pin == null ? "" : pin.trim();
        if (!value.matches("\\d{4,8}")) {
            throw new Exception("Le PIN doit contenir 4 à 8 chiffres.");
        }
        ContentValues v = new ContentValues();
        v.put("pin_hash", sha256(value));
        v.put("updated_at", now());
        getWritableDatabase().update("app_users", v, "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void clearAppUserPin(long id) throws Exception {
        if (appUser(id) == null) throw new Exception("Utilisateur introuvable.");
        ContentValues v = new ContentValues();
        v.put("pin_hash", "");
        v.put("updated_at", now());
        getWritableDatabase().update("app_users", v, "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void deleteAppUser(long id) throws Exception {
        AppUser u = appUser(id);
        if (u == null) return;
        if (u.role == 1 && u.active && activeAdminCount() <= 1) {
            throw new Exception("Impossible de supprimer le dernier administrateur actif.");
        }
        SQLiteDatabase db = getWritableDatabase();
        enqueueUserOp(db, id, "DELETE", "");
        int n = db.delete("app_users", "id=?", new String[]{String.valueOf(id)});
        if (n <= 0) throw new Exception("Suppression impossible.");
    }

    private void enqueueUserOp(SQLiteDatabase db, long userId, String action, String onlinePassword) throws Exception {
        createUserTables(db);
        Cursor c = db.rawQuery("SELECT firstname,lastname,username,role,active,COALESCE(server_id,0) FROM app_users WHERE id=? LIMIT 1",
                new String[]{String.valueOf(userId)});
        String first="", last="", username=""; int role=2, active=1; long serverId=0;
        if (c.moveToFirst()) {
            first=safe(c.getString(0)); last=safe(c.getString(1)); username=safe(c.getString(2));
            role=c.getInt(3); active=c.getInt(4); serverId=c.getLong(5);
        } else if (!"DELETE".equalsIgnoreCase(action)) {
            c.close(); throw new Exception("Utilisateur introuvable pour synchronisation.");
        }
        c.close();
        db.delete("mobile_user_ops", "local_user_id=?", new String[]{String.valueOf(userId)});
        ContentValues op = new ContentValues();
        op.put("op_uuid", UUID.randomUUID().toString()); op.put("local_user_id", userId); op.put("server_id", serverId);
        op.put("action", safe(action).isEmpty()?"UPSERT":safe(action).toUpperCase(Locale.ROOT));
        op.put("firstname", first); op.put("lastname", last); op.put("username", username); op.put("role", role); op.put("active", active);
        String pwd = onlinePassword == null ? "" : onlinePassword.trim(); op.put("password_md5", pwd.isEmpty()?"":md5(pwd)); op.put("created_at", now());
        db.insertOrThrow("mobile_user_ops", null, op);
    }

    private static String md5(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] bytes = md.digest((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception e) { throw new IllegalStateException("MD5 indisponible", e); }
    }

    public boolean verifyAppUserPin(long id, String pin) {
        createUserTables(getWritableDatabase());
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COALESCE(pin_hash,'') FROM app_users WHERE id=? AND active=1 LIMIT 1",
                new String[]{String.valueOf(id)});
        if (!c.moveToFirst()) { c.close(); return false; }
        String expected = safe(c.getString(0));
        c.close();
        if (expected.isEmpty()) return true;
        return expected.equalsIgnoreCase(sha256(pin == null ? "" : pin.trim()));
    }

    private int activeAdminCount() {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM app_users WHERE role=1 AND active=1", null);
        int n = c.moveToFirst() ? c.getInt(0) : 0;
        c.close();
        return n;
    }

    private static String sha256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 indisponible", e);
        }
    }

    public static String currentMonth() { return new SimpleDateFormat("yyyy-MM",Locale.ROOT).format(new Date()); }
    public static String today() { return new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date()); }
    public static String normalizeMonth(String month) throws Exception {
        String m=safe(month); if(!m.matches("\\d{4}-\\d{2}")) throw new Exception("Mois invalide (AAAA-MM)."); return m;
    }
    public static String normalizeDate(String date) throws Exception {
        String d=safe(date);
        if(!d.matches("\\d{4}-\\d{2}-\\d{2}")) throw new Exception("Date invalide (AAAA-MM-JJ).");
        java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT); f.setLenient(false);
        try { f.parse(d); } catch(Exception e){ throw new Exception("Date invalide (AAAA-MM-JJ)."); }
        return d;
    }
    private static String dateClamped(int year, int month1, int day) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.clear();
        cal.set(java.util.Calendar.YEAR, year);
        cal.set(java.util.Calendar.MONTH, month1 - 1);
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1);
        int max = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH);
        cal.set(java.util.Calendar.DAY_OF_MONTH, Math.max(1, Math.min(day, max)));
        return new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(cal.getTime());
    }

    public static String[] monthPeriod(String month) throws Exception {
        String m=normalizeMonth(month); java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);
        java.util.Calendar cal=java.util.Calendar.getInstance();
        try { cal.setTime(f.parse(m+"-01")); } catch(Exception e){ throw new Exception("Mois invalide."); }
        String start=f.format(cal.getTime()); cal.set(java.util.Calendar.DAY_OF_MONTH,cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH));
        return new String[]{start,f.format(cal.getTime())};
    }

    private static JSONObject cursorObject(Cursor c) throws Exception {
        JSONObject o=new JSONObject();
        for(int i=0;i<c.getColumnCount();i++){
            String k=c.getColumnName(i);
            if(c.isNull(i)) o.put(k,JSONObject.NULL);
            else switch(c.getType(i)){
                case Cursor.FIELD_TYPE_INTEGER: o.put(k,c.getLong(i)); break;
                case Cursor.FIELD_TYPE_FLOAT: o.put(k,c.getDouble(i)); break;
                default: o.put(k,c.getString(i));
            }
        }
        return o;
    }

    public static double round2(double x){return Math.round(x*100.0)/100.0;}
    public static double roundHalf(double x){return Math.round(x*2.0)/2.0;}
    public static String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.ROOT).format(new Date());}
    public static String normalizeStatus(String s){
        s=s==null?"":s.trim().toUpperCase(Locale.ROOT);
        if(s.contains("PART")) return "PARTIEL";
        if(s.contains("PAY")||s.contains("PAYE")||s.contains("PAYÉ")) return "PAYE";
        return "EN_ATTENTE";
    }

    private static final class DatabaseUtilsCompat {
        static long count(SQLiteDatabase db,String table){
            Cursor c=db.rawQuery("SELECT COUNT(*) FROM "+table,null);long n=c.moveToFirst()?c.getLong(0):0;c.close();return n;
        }
    }
}
