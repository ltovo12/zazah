package mg.zazah.erp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public class RemoteImageLoader {
    public static List<String> imageCandidates(Context context, String raw) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        if (raw == null) return new ArrayList<>(urls);
        String value = raw.trim().replace('\\', '/');
        if (value.isEmpty()) return new ArrayList<>(urls);

        if (value.startsWith("http://") || value.startsWith("https://")) {
            urls.add(value);
            urls.add(value.replace(" ", "%20"));
            return new ArrayList<>(urls);
        }

        while (value.startsWith("./")) value = value.substring(2);
        while (value.startsWith("../")) value = value.substring(3);
        while (value.startsWith("/")) value = value.substring(1);

        String api = AppPrefs.api(context);
        String siteRoot = api;
        int cutApi = api.indexOf("/admin/mobile_api");
        if (cutApi >= 0) siteRoot = api.substring(0, cutApi + 1);
        else if (!siteRoot.endsWith("/")) siteRoot += "/";

        String domainRoot = siteRoot;
        int cutZazah = siteRoot.indexOf("/zazah/");
        if (cutZazah >= 0) domainRoot = siteRoot.substring(0, cutZazah + 1);

        urls.add(siteRoot + value);
        if (value.startsWith("zazah/") || value.startsWith("admin/")) urls.add(domainRoot + value);

        if (value.startsWith("uploads/")) {
            urls.add(siteRoot + value);
            urls.add(siteRoot + "admin/" + value);
        }

        String lower = value.toLowerCase(Locale.ROOT);
        boolean looksLikeFile = lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".jfif");
        if (!value.contains("/") && looksLikeFile) {
            urls.add(siteRoot + "uploads/produits/" + value);
            urls.add(siteRoot + "uploads/variantes/" + value);
            urls.add(siteRoot + "uploads/" + value);
            urls.add(siteRoot + "admin/uploads/produits/" + value);
        }

        ArrayList<String> encoded = new ArrayList<>();
        for (String u : urls) {
            encoded.add(u);
            if (u.contains(" ")) encoded.add(u.replace(" ", "%20"));
        }
        return encoded;
    }

    public static void loadInto(Context context, ImageView target, String raw, int placeholderRes) {
        String requested = raw == null ? "" : raw.trim();
        target.setTag(requested);
        target.setImageResource(placeholderRes);
        target.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

        if (requested.isEmpty()) return;

        Bitmap cached = readCache(context, requested);
        if (cached != null) {
            target.setScaleType(ImageView.ScaleType.CENTER_CROP);
            target.setImageBitmap(cached);
            return;
        }

        List<String> candidates = imageCandidates(context, requested);
        if (candidates.isEmpty()) return;

        new Thread(() -> {
            for (String urlText : candidates) {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(urlText);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setConnectTimeout(6500);
                    connection.setReadTimeout(9000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/152 Mobile Safari/537.36");
                    connection.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
                    connection.setRequestProperty("Cache-Control", "no-cache");
                    connection.setRequestProperty("Referer", siteRoot(context));
                    connection.connect();
                    int code = connection.getResponseCode();
                    if (code >= 200 && code < 300) {
                        byte[] bytes = readAll(connection);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        if (bitmap != null) {
                            writeCache(context, requested, bytes);
                            target.post(() -> {
                                Object tag = target.getTag();
                                if (tag != null && tag.toString().equals(requested)) {
                                    target.setScaleType(ImageView.ScaleType.CENTER_CROP);
                                    target.setImageBitmap(bitmap);
                                }
                            });
                            return;
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
        }).start();
    }

    private static String siteRoot(Context context) {
        String api = AppPrefs.api(context);
        int cut = api.indexOf("/admin/mobile_api");
        if (cut >= 0) return api.substring(0, cut + 1);
        return api.endsWith("/") ? api : api + "/";
    }

    private static byte[] readAll(HttpURLConnection connection) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        try (java.io.InputStream in = connection.getInputStream()) {
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > 8 * 1024 * 1024) throw new Exception("Image trop volumineuse");
            }
        }
        return out.toByteArray();
    }

    private static File cacheFile(Context context, String key) {
        File dir = new File(context.getCacheDir(), "zazah_product_images");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, sha256(key) + ".img");
    }

    private static Bitmap readCache(Context context, String key) {
        try {
            File f = cacheFile(context, key);
            if (!f.exists() || f.length() <= 0) return null;
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b == null) f.delete();
            return b;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static void writeCache(Context context, String key, byte[] bytes) {
        try (FileOutputStream out = new FileOutputStream(cacheFile(context, key))) {
            out.write(bytes);
        } catch (Exception ignored) {}
    }

    private static String sha256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
