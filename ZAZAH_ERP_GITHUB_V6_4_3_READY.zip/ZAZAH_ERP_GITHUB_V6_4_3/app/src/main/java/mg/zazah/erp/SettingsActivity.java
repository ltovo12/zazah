package mg.zazah.erp;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {
    private EditText url, token;
    private Spinner printerSpinner, paperSpinner;
    private CheckBox autoPrint;
    private Button searchPrinterButton;
    private TextView printerStatus;

    private final ArrayList<String> printerNames = new ArrayList<>();
    private final ArrayList<String> printerAddresses = new ArrayList<>();

    private final LinkedHashMap<String, BluetoothDevice> foundDevices = new LinkedHashMap<>();
    private final ArrayList<String> foundLabels = new ArrayList<>();
    private ArrayAdapter<String> foundAdapter;
    private AlertDialog discoveryDialog;
    private TextView discoveryStatus;

    private String pendingBondAddress = "";
    private String pendingBondName = "";
    private boolean scanAfterBluetoothEnable = false;
    private boolean receiverRegistered = false;
    private boolean permissionRequestForDiscovery = false;
    private BluetoothLeScanner bleScanner;
    private final ScanCallback bleScanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result != null && result.getDevice() != null) addFoundDevice(result.getDevice());
        }
        @Override public void onBatchScanResults(java.util.List<ScanResult> results) {
            if (results != null) for (ScanResult r : results) if (r != null && r.getDevice() != null) addFoundDevice(r.getDevice());
        }
        @Override public void onScanFailed(int errorCode) {
            if (discoveryStatus != null) discoveryStatus.setText("Recherche BLE arrêtée (code " + errorCode + ").");
        }
    };

    private final ActivityResultLauncher<String[]> bluetoothPermissions =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean wantsDiscovery = permissionRequestForDiscovery;
                permissionRequestForDiscovery = false;

                if (!hasConnectPermission()) {
                    Toast.makeText(this,
                            "Autorisation Bluetooth refusée",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                loadPrinters(null);

                if (wantsDiscovery) {
                    if (hasDiscoveryPermissions()) {
                        startPrinterDiscovery();
                    } else {
                        Toast.makeText(this,
                                "Autorisation de recherche Bluetooth refusée",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });

    private final ActivityResultLauncher<Intent> enableBluetoothLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (scanAfterBluetoothEnable) {
                    scanAfterBluetoothEnable = false;
                    BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                    if (adapter != null && adapter.isEnabled()) {
                        startPrinterDiscovery();
                    } else {
                        Toast.makeText(this, "Bluetooth non activé", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                } else {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                }
                if (device != null) addFoundDevice(device);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {
                if (discoveryStatus != null) discoveryStatus.setText("Recherche en cours… rapprochez l'imprimante.");
                if (searchPrinterButton != null) searchPrinterButton.setText("Recherche en cours…");
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                if (discoveryStatus != null) {
                    discoveryStatus.setText(foundDevices.isEmpty()
                            ? "Aucun appareil trouvé. Vérifiez que l'imprimante est allumée et visible."
                            : "Recherche terminée • " + foundDevices.size() + " appareil(s) trouvé(s)");
                }
                if (searchPrinterButton != null) searchPrinterButton.setText("Rechercher des imprimantes Bluetooth");
            } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                BluetoothDevice device;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                } else {
                    device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                }
                if (device == null) return;

                String address = safeAddress(device);
                if (!address.equalsIgnoreCase(pendingBondAddress)) return;

                int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE);
                if (state == BluetoothDevice.BOND_BONDED) {
                    String selectedAddress = pendingBondAddress;
                    pendingBondAddress = "";
                    pendingBondName = "";
                    if (discoveryDialog != null) discoveryDialog.dismiss();
                    loadPrinters(selectedAddress);
                    Toast.makeText(SettingsActivity.this,
                            "Imprimante appairée et sélectionnée",
                            Toast.LENGTH_LONG).show();
                } else if (state == BluetoothDevice.BOND_NONE && !pendingBondAddress.isEmpty()) {
                    pendingBondAddress = "";
                    pendingBondName = "";
                    if (discoveryStatus != null) discoveryStatus.setText("Appairage annulé ou refusé.");
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_settings);
        UiTheme3D.apply(this);

        url = findViewById(R.id.inputApiUrl);
        token = findViewById(R.id.inputApiToken);
        printerSpinner = findViewById(R.id.spinnerTicketPrinter);
        paperSpinner = findViewById(R.id.spinnerPaperWidth);
        autoPrint = findViewById(R.id.checkAutoPrint);
        searchPrinterButton = findViewById(R.id.btnSearchBluetoothPrinter);
        printerStatus = findViewById(R.id.txtPrinterStatus);

        searchPrinterButton.setAllCaps(false);
        searchPrinterButton.setTextColor(0xFFFFFFFF);
        findViewById(R.id.btnReprintLastTicket).setTag("init");

        url.setText(AppPrefs.api(this));
        token.setText(AppPrefs.token(this));
        // V5.25.30 : token commun Android/serveur, non modifiable manuellement.
        token.setEnabled(false);
        token.setFocusable(false);
        token.setClickable(false);

        Button resetTokenButton = findViewById(R.id.btnResetApiToken);
        resetTokenButton.setAllCaps(false);
        resetTokenButton.setTextColor(0xFFFFFFFF);
        resetTokenButton.setOnClickListener(v -> {
            AppPrefs.resetToken(this);
            token.setText(AppPrefs.defaultToken());
            Toast.makeText(this,
                    "Token ZAZAH réinitialisé. Relancez la synchronisation.",
                    Toast.LENGTH_LONG).show();
        });

        paperSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"58 mm", "80 mm"}));
        paperSpinner.setSelection(AppPrefs.paperWidth(this) == 80 ? 1 : 0);
        autoPrint.setChecked(AppPrefs.autoPrint(this));

        registerBluetoothReceiver();
        ensureConnectPermissionAndLoad();

        searchPrinterButton.setOnClickListener(v -> startPrinterDiscovery());
        Button reprintButton = findViewById(R.id.btnReprintLastTicket);
        reprintButton.setAllCaps(false);
        reprintButton.setTextColor(0xFFFFFFFF);
        reprintButton.setOnClickListener(v -> reprintLastTicket());
        Button saveButton = findViewById(R.id.btnSaveSettings);
        saveButton.setAllCaps(false);
        saveButton.setTextColor(0xFFFFFFFF);
        saveButton.setOnClickListener(v -> saveSettings());
    }

    @Override
    protected void onDestroy() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        try {
            if (adapter != null && hasScanPermission() && adapter.isDiscovering()) adapter.cancelDiscovery();
        } catch (Exception ignored) {}

        if (receiverRegistered) {
            try { unregisterReceiver(bluetoothReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onDestroy();
    }

    private void registerBluetoothReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        ContextCompat.registerReceiver(this, bluetoothReceiver, filter, ContextCompat.RECEIVER_EXPORTED);
        receiverRegistered = true;
    }

    private void reprintLastTicket() {
        if (!BluetoothEscPosPrinter.hasConnectPermission(this)) {
            requestBluetoothPermissions(false);
            return;
        }

        int p = printerSpinner.getSelectedItemPosition();
        String address = p >= 0 && p < printerAddresses.size() ? printerAddresses.get(p) : "";
        String name = p > 0 && p < printerNames.size() ? printerNames.get(p) : "";
        int width = paperSpinner.getSelectedItemPosition() == 1 ? 80 : 58;
        AppPrefs.p(this).edit()
                .putString("printer_address", address)
                .putString("printer_name", name)
                .putInt("paper_width", width)
                .apply();

        try {
            DatabaseHelper db = new DatabaseHelper(this);
            long id = db.lastSaleId();
            if (id <= 0) {
                Toast.makeText(this, "Aucun ticket à réimprimer", Toast.LENGTH_SHORT).show();
                return;
            }
            org.json.JSONObject receipt = db.saleReceipt(id);
            org.json.JSONArray lines = db.saleLines(id);
            BluetoothEscPosPrinter.printSale(this, receipt, lines, "", new BluetoothEscPosPrinter.Callback() {
                @Override public void onSuccess() {
                    runOnUiThread(() -> Toast.makeText(SettingsActivity.this,
                            "Ticket réimprimé", Toast.LENGTH_SHORT).show());
                }
                @Override public void onError(String message) {
                    runOnUiThread(() -> Toast.makeText(SettingsActivity.this,
                            "Impression : " + message, Toast.LENGTH_LONG).show());
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void ensureConnectPermissionAndLoad() {
        if (hasConnectPermission()) {
            loadPrinters(null);
        } else {
            requestBluetoothPermissions(false);
        }
    }

    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasScanPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasDiscoveryPermissions() {
        return hasConnectPermission() && hasScanPermission();
    }

    private void requestBluetoothPermissions(boolean forDiscovery) {
        ArrayList<String> permissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!hasConnectPermission()) permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (forDiscovery && !hasScanPermission()) permissions.add(Manifest.permission.BLUETOOTH_SCAN);
        } else if (forDiscovery && !hasScanPermission()) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (permissions.isEmpty()) {
            if (forDiscovery) startPrinterDiscovery();
            else loadPrinters(null);
        } else {
            permissionRequestForDiscovery = forDiscovery;
            bluetoothPermissions.launch(permissions.toArray(new String[0]));
        }
    }

    private void loadPrinters(String forceSelectAddress) {
        printerNames.clear();
        printerAddresses.clear();
        printerNames.add("Aucune imprimante");
        printerAddresses.add("");

        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && hasConnectPermission()) {
                Set<BluetoothDevice> bonded = adapter.getBondedDevices();
                if (bonded != null) {
                    for (BluetoothDevice d : bonded) addBondedPrinter(d);
                }
                String savedAddress = forceSelectAddress != null && !forceSelectAddress.isEmpty() ? forceSelectAddress : AppPrefs.printerAddress(this);
                if (savedAddress != null && !savedAddress.trim().isEmpty()) {
                    boolean exists = false;
                    for (String a : printerAddresses) if (savedAddress.equalsIgnoreCase(a)) { exists = true; break; }
                    if (!exists) {
                        try { addBondedPrinter(adapter.getRemoteDevice(savedAddress)); } catch (Exception ignored2) {}
                    }
                }
            }
        } catch (Exception ignored) {}

        printerSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, printerNames));

        String saved = forceSelectAddress != null && !forceSelectAddress.isEmpty()
                ? forceSelectAddress : AppPrefs.printerAddress(this);
        int selected = 0;
        for (int i = 0; i < printerAddresses.size(); i++) {
            if (saved.equalsIgnoreCase(printerAddresses.get(i))) {
                selected = i;
                break;
            }
        }
        printerSpinner.setSelection(selected);
        updatePrinterStatus(selected);
        printerSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                updatePrinterStatus(position);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private void addBondedPrinter(BluetoothDevice d) {
        String address = safeAddress(d);
        if (address.isEmpty()) return;
        for (String existing : printerAddresses) {
            if (address.equalsIgnoreCase(existing)) return;
        }
        String name = safeName(d);
        printerNames.add(name + "  •  " + address);
        printerAddresses.add(address);
    }

    private void updatePrinterStatus(int position) {
        if (printerStatus == null) return;
        if (position <= 0 || position >= printerAddresses.size()) {
            printerStatus.setText("Aucune imprimante sélectionnée");
        } else {
            String label = printerNames.get(position);
            printerStatus.setText("Sélectionnée : " + label + (label.toLowerCase(java.util.Locale.ROOT).contains("sc03") ? "\nMode : SC03h / iPrint BLE (384 px)" : "\nMode : ESC/POS Bluetooth"));
        }
    }

    private void startPrinterDiscovery() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            Toast.makeText(this, "Bluetooth non disponible sur cet appareil", Toast.LENGTH_LONG).show();
            return;
        }

        if (!hasDiscoveryPermissions()) {
            requestBluetoothPermissions(true);
            return;
        }

        if (!adapter.isEnabled()) {
            scanAfterBluetoothEnable = true;
            Intent enable = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            enableBluetoothLauncher.launch(enable);
            return;
        }

        foundDevices.clear();
        foundLabels.clear();
        try {
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded != null) {
                for (BluetoothDevice d : bonded) addFoundDevice(d);
            }
        } catch (Exception ignored) {}

        showDiscoveryDialog();

        try {
            if (adapter.isDiscovering()) adapter.cancelDiscovery();
            boolean started = adapter.startDiscovery();
            try {
                bleScanner = adapter.getBluetoothLeScanner();
                if (bleScanner != null) bleScanner.startScan(bleScanCallback);
            } catch (Exception ignored) {}
            if (!started && bleScanner == null && discoveryStatus != null) {
                discoveryStatus.setText("Impossible de démarrer la recherche. Réessayez ou ouvrez les paramètres Bluetooth.");
            } else if (discoveryStatus != null) {
                discoveryStatus.setText("Recherche Bluetooth classique + BLE… SC03h/iPrint est prise en charge.");
            }
        } catch (SecurityException e) {
            Toast.makeText(this, "Autorisation Bluetooth manquante", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Recherche Bluetooth : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showDiscoveryDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        box.setPadding(pad, dp(8), pad, dp(4));

        discoveryStatus = new TextView(this);
        discoveryStatus.setText("Recherche en cours…");
        discoveryStatus.setTextSize(14);
        discoveryStatus.setPadding(0, 0, 0, dp(10));
        box.addView(discoveryStatus);

        TextView hint = new TextView(this);
        hint.setText("Touchez une imprimante. Si elle n'est pas encore appairée, Android lancera l'appairage (PIN fréquent : 0000 ou 1234).");
        hint.setTextSize(12);
        hint.setPadding(0, 0, 0, dp(10));
        box.addView(hint);

        ListView list = new ListView(this);
        list.setDividerHeight(1);
        foundAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, foundLabels);
        list.setAdapter(foundAdapter);
        box.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(390)));

        discoveryDialog = new DialogUi.Builder(this)
                .setTitle("Rechercher une imprimante")
                .setView(box)
                .setNegativeButton("Fermer", null)
                .setNeutralButton("Bluetooth Android", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
                    } catch (Exception ignored) {}
                })
                .create();

        list.setOnItemClickListener((parent, view, position, id) -> {
            BluetoothDevice device = deviceAt(position);
            if (device != null) selectOrPair(device);
        });

        discoveryDialog.setOnDismissListener(d -> {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            try {
                if (adapter != null && hasScanPermission() && adapter.isDiscovering()) adapter.cancelDiscovery();
                if (bleScanner != null && hasScanPermission()) bleScanner.stopScan(bleScanCallback);
            } catch (Exception ignored) {}
            bleScanner = null;
            searchPrinterButton.setText("Rechercher des imprimantes Bluetooth");
        });
        discoveryDialog.show();
        DialogUi.style(discoveryDialog);
    }

    private void addFoundDevice(BluetoothDevice device) {
        String address = safeAddress(device);
        if (address.isEmpty()) return;
        foundDevices.put(address, device);
        rebuildFoundLabels();
    }

    private void rebuildFoundLabels() {
        foundLabels.clear();
        for (Map.Entry<String, BluetoothDevice> entry : foundDevices.entrySet()) {
            BluetoothDevice d = entry.getValue();
            boolean bonded = isBonded(d);
            foundLabels.add((bonded ? "✓ Appairée   " : "● Trouvée   ") +
                    safeName(d) + "\n" + entry.getKey());
        }
        if (foundAdapter != null) foundAdapter.notifyDataSetChanged();
    }

    private BluetoothDevice deviceAt(int position) {
        if (position < 0 || position >= foundDevices.size()) return null;
        int i = 0;
        for (BluetoothDevice d : foundDevices.values()) {
            if (i++ == position) return d;
        }
        return null;
    }

    private void selectOrPair(BluetoothDevice device) {
        if (!hasConnectPermission()) {
            requestBluetoothPermissions(true);
            return;
        }

        String address = safeAddress(device);
        String deviceName = safeName(device);
        if (deviceName.toLowerCase(java.util.Locale.ROOT).contains("sc03")) {
            AppPrefs.p(this).edit().putString("printer_address", address).putString("printer_name", deviceName).putString("printer_mode", "SC03").apply();
            if (discoveryDialog != null) discoveryDialog.dismiss();
            loadPrinters(address);
            Toast.makeText(this, "SC03h / iPrint sélectionnée en BLE", Toast.LENGTH_LONG).show();
            return;
        }
        if (isBonded(device)) {
            if (discoveryDialog != null) discoveryDialog.dismiss();
            loadPrinters(address);
            Toast.makeText(this, "Imprimante sélectionnée", Toast.LENGTH_SHORT).show();
            return;
        }

        pendingBondAddress = address;
        pendingBondName = safeName(device);
        if (discoveryStatus != null) {
            discoveryStatus.setText("Appairage avec " + pendingBondName + "… confirmez le code si Android le demande.");
        }

        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && adapter.isDiscovering()) adapter.cancelDiscovery();
            boolean started = device.createBond();
            if (!started && discoveryStatus != null) {
                discoveryStatus.setText("L'appairage n'a pas démarré. Ouvrez Bluetooth Android pour appairer l'imprimante.");
            }
        } catch (SecurityException e) {
            Toast.makeText(this, "Autorisation Bluetooth manquante", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            if (discoveryStatus != null) discoveryStatus.setText("Appairage impossible : " + e.getMessage());
        }
    }

    private boolean isBonded(BluetoothDevice device) {
        try {
            return hasConnectPermission() && device.getBondState() == BluetoothDevice.BOND_BONDED;
        } catch (Exception e) {
            return false;
        }
    }

    private String safeName(BluetoothDevice device) {
        try {
            if (!hasConnectPermission()) return "Bluetooth";
            String name = device.getName();
            return name == null || name.trim().isEmpty() ? "Bluetooth" : name.trim();
        } catch (Exception e) {
            return "Bluetooth";
        }
    }

    private String safeAddress(BluetoothDevice device) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasConnectPermission()) return "";
            String address = device.getAddress();
            return address == null ? "" : address;
        } catch (Exception e) {
            return "";
        }
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private void saveSettings() {
        String u = url.getText().toString().trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);

        // V5.25.30 : toujours enregistrer le token officiel fourni avec le serveur.
        String t = AppPrefs.defaultToken();
        token.setText(t);

        int p = printerSpinner.getSelectedItemPosition();
        String printerAddress = p >= 0 && p < printerAddresses.size() ? printerAddresses.get(p) : "";
        String printerName = p > 0 && p < printerNames.size() ? printerNames.get(p) : "";
        int width = paperSpinner.getSelectedItemPosition() == 1 ? 80 : 58;

        String mode = printerName.toLowerCase(java.util.Locale.ROOT).contains("sc03") ? "SC03" : "ESC_POS";
        if (printerAddress.equalsIgnoreCase(AppPrefs.printerAddress(this)) && "SC03".equalsIgnoreCase(AppPrefs.printerMode(this))) mode = "SC03";
        AppPrefs.p(this).edit()
                .putString("api_url", u)
                .putString("api_token", t)
                .putString("printer_address", printerAddress)
                .putString("printer_name", printerName)
                .putString("printer_mode", mode)
                .putInt("paper_width", width)
                .putBoolean("auto_print", autoPrint.isChecked())
                .apply();

        Toast.makeText(this, "Paramètres enregistrés", Toast.LENGTH_SHORT).show();
        finish();
    }
}
