package mg.zazah.erp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SingleLineCartAdapter extends BaseAdapter {
    private final LayoutInflater inflater;
    private final List<String> rows;

    public SingleLineCartAdapter(Context context, List<String> rows) {
        this.inflater = LayoutInflater.from(context);
        this.rows = rows == null ? new ArrayList<>() : rows;
    }

    @Override public int getCount() { return rows.size(); }
    @Override public Object getItem(int position) { return rows.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) view = inflater.inflate(R.layout.row_cart_single_line, parent, false);
        TextView text = view.findViewById(R.id.rowCartText);
        text.setText(rows.get(position));
        return view;
    }
}
