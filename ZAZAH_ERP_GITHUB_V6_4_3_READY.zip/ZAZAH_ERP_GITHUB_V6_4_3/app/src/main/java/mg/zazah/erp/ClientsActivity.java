package mg.zazah.erp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ClientsActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText search;
    private ListView list;
    private final ArrayList<ClientRow> visibleClients = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_clients);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        search = findViewById(R.id.inputClientSearch);
        list = findViewById(R.id.listClients);
        findViewById(R.id.btnAddClient).setOnClickListener(v -> showClientDialog(null));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { load(); }
            public void afterTextChanged(Editable e) {}
        });
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < visibleClients.size()) showClientDialog(visibleClients.get(position));
        });
        load();
    }

    @Override protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase();
        Cursor c = db.clients();
        visibleClients.clear();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        while (c.moveToNext()) {
            ClientRow row = new ClientRow();
            row.id = c.getLong(0);
            row.serverId = c.isNull(1) ? 0 : c.getLong(1);
            row.name = c.getString(2);
            row.phone = c.getString(3);
            row.address = c.getString(4);
            row.localOnly = c.getInt(5) == 1;
            String hay = (row.name + " " + row.phone + " " + row.address).toLowerCase();
            if (!q.isEmpty() && !hay.contains(q)) continue;
            visibleClients.add(row);

            String status = row.localOnly ? "À synchroniser" : "Synchronisé";
            String serverText = row.serverId > 0 ? "  •  ID en ligne " + row.serverId : "";
            String sub = (row.phone.isEmpty() ? "Sans contact" : row.phone) +
                    (row.address.isEmpty() ? "" : "  •  " + row.address) +
                    "  •  " + status + serverText;
            items.add(new TwoLineAdapter.Item(row.name, sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, items));
    }

    private void showClientDialog(ClientRow existing) {
        boolean editing = existing != null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(4));

        TextView note = new TextView(this);
        note.setText(editing
                ? (existing.serverId > 0
                    ? "La modification sera envoyée au même client en ligne (ID " + existing.serverId + ")."
                    : "Ce client n'est pas encore en ligne. Les dernières informations seront utilisées lors de sa création.")
                : "Le code client sera généré automatiquement lors de la synchronisation.");
        note.setTextColor(0xFF64748B);
        note.setTextSize(12);
        note.setPadding(0, 0, 0, dp(12));
        box.addView(note);

        addLabel(box, "Nom complet *");
        EditText name = styledInput("Nom et prénom / Raison sociale");
        if (editing) name.setText(existing.name);
        box.addView(name);

        addLabel(box, "Téléphone / Contact");
        EditText phone = styledInput("Ex: 034 00 000 00");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        if (editing) phone.setText(existing.phone);
        box.addView(phone);

        addLabel(box, "Adresse");
        EditText address = styledInput("Adresse du client");
        address.setSingleLine(false);
        address.setMinLines(2);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        if (editing) address.setText(existing.address);
        box.addView(address);

        AlertDialog dialog = new DialogUi.Builder(this)
                .setTitle(editing ? "Modifier client" : "Nouveau client")
                .setView(box)
                .setPositiveButton(editing ? "Enregistrer modifications" : "Enregistrer", null)
                .setNegativeButton("Annuler", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String fullName = name.getText().toString().trim();
            if (fullName.isEmpty()) {
                name.setError("Nom complet obligatoire");
                return;
            }
            try {
                if (editing) {
                    db.updateLocalClient(existing.id, fullName, phone.getText().toString(), address.getText().toString());
                } else {
                    db.addLocalClient(fullName, phone.getText().toString(), address.getText().toString());
                }
                dialog.dismiss();
                load();
                Toast.makeText(this,
                        editing ? "Modification enregistrée dans SQLite" : "Client enregistré dans SQLite",
                        Toast.LENGTH_SHORT).show();
                if ("ONLINE".equals(AppPrefs.mode(this))) startActivity(new Intent(this, SyncActivity.class));
            } catch (Exception ex) {
                Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));
        DialogUi.show(dialog);
    }

    private void addLabel(LinearLayout parent, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(0xFF714B67);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(2), 0, dp(6));
        parent.addView(t);
    }

    private EditText styledInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setMinHeight(dp(48));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        e.setLayoutParams(lp);
        return e;
    }

    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density * v); }

    private static class ClientRow {
        long id, serverId;
        String name, phone, address;
        boolean localOnly;
    }
}
