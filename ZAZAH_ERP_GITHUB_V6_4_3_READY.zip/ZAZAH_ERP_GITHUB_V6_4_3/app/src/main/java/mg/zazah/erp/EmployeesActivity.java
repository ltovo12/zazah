package mg.zazah.erp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class EmployeesActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private ListView list;
    private final ArrayList<EmployeeRow> rows = new ArrayList<>();
    private final NumberFormat money = NumberFormat.getNumberInstance(Locale.FRANCE);

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_employees);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        list = findViewById(R.id.listEmployees);
        findViewById(R.id.btnAddEmployee).setOnClickListener(v -> showEditor(null));
        list.setOnItemClickListener((p,v,pos,id) -> showActions(rows.get(pos)));
        load();
    }

    @Override protected void onResume(){ super.onResume(); load(); }

    private void load() {
        Cursor c = db.salaries();
        rows.clear();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        while(c.moveToNext()) {
            EmployeeRow r = new EmployeeRow();
            r.id=c.getLong(0); r.matricule=c.getString(1); r.nom=c.getString(2); r.tel=c.getString(3); r.email=c.getString(4); r.address=c.getString(5);
            r.base=c.getDouble(6); r.repas=c.getDouble(7); r.days=c.getDouble(8); r.active=c.getInt(9)==1;
            rows.add(r);
            String title=(r.matricule.isEmpty()?"":r.matricule+" - ")+r.nom+(r.active?"":" • INACTIF");
            String sub="Base "+money.format(r.base)+" Ar • Repas "+money.format(r.repas)+" Ar/j • "+fmt(r.days)+" j";
            if(!r.tel.isEmpty()) sub += " • "+r.tel;
            items.add(new TwoLineAdapter.Item(title,sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this,items));
    }

    private void showActions(EmployeeRow r) {
        String[] actions = {"Modifier", r.active?"Désactiver":"Activer", "Supprimer"};
        DialogUi.show(new DialogUi.Builder(this).setTitle(r.nom).setItems(actions,(d,w)->{
            if(w==0) showEditor(r);
            else if(w==1) { try { db.saveSalaryEmployee(r.id,r.matricule,r.nom,r.tel,r.email,r.address,r.base,r.repas,r.days,!r.active); load(); } catch(Exception e){ toast(e.getMessage()); } }
            else DialogUi.show(new DialogUi.Builder(this).setTitle("Supprimer le salarié ?").setMessage("Les paies existantes empêchent la suppression.")
                    .setPositiveButton("Supprimer",(dd,ww)->{ try { db.deleteSalaryEmployee(r.id); load(); } catch(Exception e){ toast(e.getMessage()); } })
                    .setNegativeButton("Annuler",null));
        }));
    }

    private void showEditor(EmployeeRow r) {
        boolean edit=r!=null;
        LinearLayout box=box();
        EditText matricule=input("Matricule (optionnel)",InputType.TYPE_CLASS_TEXT); box.addView(matricule);
        EditText nom=input("Nom complet *",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS); box.addView(nom);
        EditText tel=input("Téléphone",InputType.TYPE_CLASS_PHONE); box.addView(tel);
        EditText email=input("Email",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS); box.addView(email);
        EditText address=input("Adresse",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); box.addView(address);
        EditText base=input("Salaire de base (Ar)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); box.addView(base);
        EditText repas=input("Allocation repas par jour (Ar)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); box.addView(repas);
        EditText days=input("Jours repas par défaut",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); box.addView(days);
        CheckBox active=new CheckBox(this); active.setText("Salarié actif"); active.setChecked(true); box.addView(active);
        if(edit){ matricule.setText(r.matricule);nom.setText(r.nom);tel.setText(r.tel);email.setText(r.email);address.setText(r.address);base.setText(fmt(r.base));repas.setText(fmt(r.repas));days.setText(fmt(r.days));active.setChecked(r.active); }
        else days.setText("26");
        AlertDialog dlg=new DialogUi.Builder(this).setTitle(edit?"Modifier salarié":"Nouveau salarié").setView(box).setPositiveButton("Enregistrer",null).setNegativeButton("Annuler",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(nom.getText().toString().trim().isEmpty()){nom.setError("Nom obligatoire");return;}
            try {
                db.saveSalaryEmployee(edit?r.id:0,matricule.getText().toString(),nom.getText().toString(),tel.getText().toString(),email.getText().toString(),address.getText().toString(),num(base),num(repas),num(days),active.isChecked());
                dlg.dismiss();load();Toast.makeText(this,"Salarié enregistré dans SQLite",Toast.LENGTH_SHORT).show();
            } catch(Exception e){toast(e.getMessage());}
        })); DialogUi.show(dlg);
    }

    private LinearLayout box(){ LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(20),dp(12),dp(20),0);return b; }
    private EditText input(String hint,int type){ EditText e=new EditText(this);e.setHint(hint);e.setInputType(type);e.setBackgroundResource(R.drawable.bg_input);e.setPadding(dp(12),dp(9),dp(12),dp(9)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(9);e.setLayoutParams(lp);return e; }
    private double num(EditText e){ try{return Double.parseDouble(e.getText().toString().trim().replace(',','.'));}catch(Exception x){return 0;} }
    private String fmt(double x){ return x==Math.rint(x)?String.valueOf((long)x):String.valueOf(x); }
    private int dp(int v){return Math.round(getResources().getDisplayMetrics().density*v);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private static class EmployeeRow { long id; String matricule,nom,tel,email,address; double base,repas,days; boolean active; }
}
