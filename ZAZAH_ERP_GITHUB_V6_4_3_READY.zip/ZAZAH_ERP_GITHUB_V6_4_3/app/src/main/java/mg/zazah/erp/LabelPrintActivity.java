package mg.zazah.erp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import android.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LabelPrintActivity extends AppCompatActivity {
    private static final int REQ_BLUETOOTH = 882;

    private DatabaseHelper db;
    private EditText searchInput;
    private EditText copiesInput;
    private TextView printerInfo;
    private TextView selectedTitle;
    private TextView selectedDetails;
    private TextView selectedCode;
    private ListView list;
    private Button printButton;

    private final ArrayList<VariantItem> variants = new ArrayList<>();
    private final ArrayList<TwoLineAdapter.Item> rows = new ArrayList<>();
    private TwoLineAdapter adapter;
    private VariantItem selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        UiTheme3D.installTheme(this);
        super.onCreate(savedInstanceState);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_label_print);
        UiTheme3D.apply(this);

        db = new DatabaseHelper(this);

        searchInput = findViewById(R.id.inputLabelSearch);
        copiesInput = findViewById(R.id.inputLabelCopies);
        printerInfo = findViewById(R.id.txtLabelPrinter);
        selectedTitle = findViewById(R.id.txtLabelSelectedTitle);
        selectedDetails = findViewById(R.id.txtLabelSelectedDetails);
        selectedCode = findViewById(R.id.txtLabelSelectedCode);
        list = findViewById(R.id.listLabelVariants);
        printButton = findViewById(R.id.btnPrintLabel);

        findViewById(R.id.btnLabelBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnLabelSettings).setOnClickListener(
                v -> startActivity(new Intent(this, SettingsActivity.class))
        );

        adapter = new TwoLineAdapter(this, rows);
        list.setAdapter(adapter);

        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= variants.size()) return;
            selected = variants.get(position);
            updateSelection();
        });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadVariants(s == null ? "" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        printButton.setOnClickListener(v -> printSelected());

        loadVariants("");
        updatePrinterInfo();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePrinterInfo();
    }

    private void updatePrinterInfo() {
        String name = AppPrefs.printerName(this);
        String address = AppPrefs.printerAddress(this);
        int width = AppPrefs.paperWidth(this);

        if (address == null || address.trim().isEmpty()) {
            printerInfo.setText("Aucune imprimante Bluetooth configurée • " + width + " mm");
        } else {
            String label = (name == null || name.trim().isEmpty()) ? "Imprimante Bluetooth" : name.trim();
            printerInfo.setText(label + " • " + width + " mm • 1 étiquette par ligne");
        }
    }

    private void loadVariants(String query) {
        long keepId = selected == null ? Long.MIN_VALUE : selected.id;

        variants.clear();
        rows.clear();

        Cursor c = null;
        try {
            c = db.searchPackVariants(query == null ? "" : query.trim(), 300);
            int idCol = c.getColumnIndex("variante_id");
            int prodCol = c.getColumnIndex("produit");
            int colorCol = c.getColumnIndex("couleur");
            int sizeCol = c.getColumnIndex("taille");
            int codeCol = c.getColumnIndex("code_barre");
            int priceCol = c.getColumnIndex("prix_vente");
            int stockCol = c.getColumnIndex("stock_tsena");
            if (stockCol < 0) stockCol = c.getColumnIndex("stock_total");

            if (idCol < 0 || prodCol < 0 || colorCol < 0 || sizeCol < 0 || codeCol < 0 || priceCol < 0 || stockCol < 0) {
                throw new IllegalStateException("Colonnes catalogue étiquettes manquantes");
            }

            while (c.moveToNext()) {
                VariantItem item = new VariantItem();
                item.id = c.getLong(idCol);
                item.product = c.getString(prodCol);
                item.color = c.getString(colorCol);
                item.size = c.getString(sizeCol);
                item.code = c.getString(codeCol);
                item.price = c.getDouble(priceCol);
                item.stock = c.getDouble(stockCol);

                if (item.code == null || item.code.trim().isEmpty()) {
                    item.code = localCode(item.id);
                }

                variants.add(item);
                rows.add(new TwoLineAdapter.Item(
                        item.title(),
                        "Code : " + item.code + " • " + money(item.price) + " Ar • stock " + qty(item.stock)
                ));

                if (item.id == keepId) selected = item;
            }
        } catch (Exception e) {
            Toast.makeText(this, "Erreur catalogue : " + safeMessage(e), Toast.LENGTH_LONG).show();
        } finally {
            if (c != null) c.close();
        }

        adapter.notifyDataSetChanged();

        if (selected != null) {
            boolean found = false;
            for (VariantItem item : variants) {
                if (item.id == selected.id) {
                    selected = item;
                    found = true;
                    break;
                }
            }
            if (!found) selected = null;
        }

        if (selected == null && !variants.isEmpty()) selected = variants.get(0);
        updateSelection();
    }

    private void updateSelection() {
        if (selected == null) {
            selectedTitle.setText("Aucune variante sélectionnée");
            selectedDetails.setText("Recherchez un produit puis touchez la variante à imprimer.");
            selectedCode.setText("Choix à l’impression : Barcode ou QR code");
            printButton.setEnabled(false);
            return;
        }

        selectedTitle.setText(selected.product == null ? "Produit" : selected.product);
        selectedDetails.setText(
                selected.variantText().isEmpty()
                        ? "Variante standard • " + money(selected.price) + " Ar"
                        : selected.variantText() + " • " + money(selected.price) + " Ar"
        );
        selectedCode.setText("Code : " + selected.code + " • choisissez Barcode ou QR à l’impression");
        printButton.setEnabled(true);
    }

    private void printSelected() {
        if (selected == null) {
            Toast.makeText(this, "Choisissez d’abord une variante.", Toast.LENGTH_SHORT).show();
            return;
        }

        String address = AppPrefs.printerAddress(this);
        if (address == null || address.trim().isEmpty()) {
            new DialogUi.Builder(this)
                    .setTitle("Imprimante non configurée")
                    .setMessage("Configurez d’abord l’imprimante Bluetooth et la largeur 58/80 mm.")
                    .setNegativeButton("Annuler", null)
                    .setPositiveButton("Paramètres", (d, w) ->
                            startActivity(new Intent(this, SettingsActivity.class)))
                    .show();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN},
                    REQ_BLUETOOTH
            );
            return;
        }

        int copies = 1;
        try {
            copies = Integer.parseInt(copiesInput.getText().toString().trim());
        } catch (Exception ignored) {}
        copies = Math.max(1, Math.min(50, copies));

        showCodeTypeDialog(copies);
    }

    /**
     * V5.25.47 : avant chaque impression, demander explicitement si
     * l’étiquette doit contenir un code-barres OU un QR code.
     */
    private void showCodeTypeDialog(int copies) {
        final int safeCopies = Math.max(1, Math.min(50, copies));
        final String[] choices = {
                "Code-barres (Barcode / Code 128)",
                "QR code 40×30 avec texte",
                "QR code 60×40 avec texte"
        };

        new DialogUi.Builder(this)
                .setTitle("Quel code / format imprimer ?")
                .setItems(choices, (dialog, which) -> {
                    int type;
                    if (which == 1) {
                        type = BluetoothEscPosPrinter.LABEL_QR_40X30;
                    } else if (which == 2) {
                        type = BluetoothEscPosPrinter.LABEL_QR_60X40;
                    } else {
                        type = BluetoothEscPosPrinter.LABEL_BARCODE;
                    }
                    startLabelPrint(safeCopies, type);
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void startLabelPrint(int copies, int type) {
        if (selected == null) return;

        final int copiesFinal = copies;
        final boolean qr = type == BluetoothEscPosPrinter.LABEL_QR || type == BluetoothEscPosPrinter.LABEL_QR_40X30 || type == BluetoothEscPosPrinter.LABEL_QR_60X40;
        final String typeLabel = type == BluetoothEscPosPrinter.LABEL_QR_40X30
                ? "QR 40×30"
                : (type == BluetoothEscPosPrinter.LABEL_QR_60X40 || type == BluetoothEscPosPrinter.LABEL_QR
                ? "QR 60×40"
                : "Barcode");

        printButton.setEnabled(false);
        printButton.setText("Impression " + typeLabel + "…");

        BluetoothEscPosPrinter.printLabel(
                this,
                selected.product,
                selected.variantText(),
                selected.code,
                selected.price,
                selected.id,
                copiesFinal,
                type,
                new BluetoothEscPosPrinter.Callback() {
                    @Override public void onSuccess() {
                        runOnUiThread(() -> {
                            printButton.setEnabled(true);
                            printButton.setText("Imprimer l’étiquette");
                            Toast.makeText(
                                    LabelPrintActivity.this,
                                    copiesFinal + " étiquette(s) " + typeLabel + " imprimée(s).",
                                    Toast.LENGTH_SHORT
                            ).show();
                        });
                    }

                    @Override public void onError(String message) {
                        runOnUiThread(() -> {
                            printButton.setEnabled(true);
                            printButton.setText("Imprimer l’étiquette");
                            Toast.makeText(
                                    LabelPrintActivity.this,
                                    message == null ? "Erreur impression" : message,
                                    Toast.LENGTH_LONG
                            ).show();
                        });
                    }
                }
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BLUETOOTH) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(
                    this,
                    granted ? "Autorisation accordée. Appuyez de nouveau sur Imprimer."
                            : "Autorisation Bluetooth refusée.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private String localCode(long variantId) {
        long n = Math.abs(variantId);
        return "ZTS" + String.format(Locale.US, "%08d", n % 100000000L);
    }

    private String money(double value) {
        return String.format(Locale.FRANCE, "%,.0f", value).replace('\u202f', ' ').replace('\u00a0', ' ');
    }

    private String qty(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.00001) {
            return String.format(Locale.FRANCE, "%.0f", value);
        }
        return String.format(Locale.FRANCE, "%.1f", value);
    }

    private String safeMessage(Exception e) {
        String m = e == null ? null : e.getMessage();
        return m == null || m.trim().isEmpty() ? "Erreur inconnue" : m;
    }

    private static class VariantItem {
        long id;
        String product;
        String color;
        String size;
        String code;
        double price;
        double stock;

        String variantText() {
            ArrayList<String> p = new ArrayList<>();
            if (color != null && !color.trim().isEmpty()) p.add(color.trim());
            if (size != null && !size.trim().isEmpty()) p.add("taille " + size.trim());
            return join(p, " • ");
        }

        String title() {
            String v = variantText();
            return (product == null ? "Produit" : product) + (v.isEmpty() ? "" : " (" + v + ")");
        }

        private static String join(List<String> values, String separator) {
            StringBuilder out = new StringBuilder();
            for (String value : values) {
                if (out.length() > 0) out.append(separator);
                out.append(value);
            }
            return out.toString();
        }
    }
}
