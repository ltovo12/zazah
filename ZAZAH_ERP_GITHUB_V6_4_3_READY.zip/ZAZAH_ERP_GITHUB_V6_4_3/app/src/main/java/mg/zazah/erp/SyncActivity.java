package mg.zazah.erp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class SyncActivity extends AppCompatActivity {
    private WebView webView;
    private TextView status;
    private Button reload;
    private Button backMain;
    private DatabaseHelper db;
    private String allowedHost = "";
    private final Object catalogLock = new Object();
    private String catalogSession = "";
    private StringBuilder catalogBuffer = new StringBuilder();

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_sync);
        UiTheme3D.apply(this);

        db = new DatabaseHelper(this);
        webView = findViewById(R.id.syncWebView);
        status = findViewById(R.id.txtSyncStatus);
        reload = findViewById(R.id.btnSyncNow);
        backMain = findViewById(R.id.btnSyncBackMain);

        String base = AppPrefs.api(this);
        try {
            allowedHost = Uri.parse(base).getHost();
        } catch (Exception ignored) {
            allowedHost = "";
        }

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            cookies.setAcceptThirdPartyCookies(webView, true);
        }

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " ZAZAH-ERP-Android/2.0");

        webView.addJavascriptInterface(new Bridge(), "ZazahAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost();
                if (host != null && host.equalsIgnoreCase(allowedHost)) {
                    return false;
                }
                Toast.makeText(SyncActivity.this,
                        "Lien externe bloqué pendant la synchronisation.",
                        Toast.LENGTH_LONG).show();
                return true;
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                status.setText("Page de synchronisation chargée.\nOpérations master en attente : " + db.pendingMasterCount() + "\nVentes en attente : " + db.pendingCount());
            }
        });

        reload.setOnClickListener(v -> loadSyncPage());
        backMain.setOnClickListener(v -> openMainMenu());
        loadSyncPage();
    }

    private void openMainMenu() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void loadSyncPage() {
        String base = AppPrefs.api(this);
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        status.setText("Ouverture du navigateur sécurisé…\nOpérations master en attente : " + db.pendingMasterCount() + "\nVentes en attente : " + db.pendingCount());
        webView.loadUrl(base + "/browser_sync.php?t=" + System.currentTimeMillis());
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("ZazahAndroid");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    public final class Bridge {
        @JavascriptInterface public String getToken() {
            return AppPrefs.token(SyncActivity.this);
        }

        @JavascriptInterface public String getPendingMasterData() {
            try {
                return db.pendingMasterData().toString();
            } catch (Exception e) {
                return "{\"clients\":[],\"users\":[],\"salaries\":[],\"avances\":[],\"variants\":[],\"stocks\":[],\"packs\":[]}";
            }
        }

        @JavascriptInterface public int getPendingMasterCount() {
            return db.pendingMasterCount();
        }

        @JavascriptInterface public void markMasterDataSynced(String responseJson) {
            try {
                db.applyMasterDataSync(new JSONObject(responseJson));
                runOnUiThread(() -> status.setText(
                        "Clients / utilisateurs / salariés / avances / variants / stock / packs envoyés.\nEnvoi des ventes POS…"));
            } catch (Exception e) {
                reportError("Mise à jour des IDs locaux impossible : " + e.getMessage());
            }
        }

        @JavascriptInterface public String getPendingSales() {
            try {
                return db.pendingSales().toString();
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface public int getPendingCount() {
            return db.pendingCount();
        }

        @JavascriptInterface public void markSalesSynced(String acceptedJson) {
            try {
                JSONArray accepted = new JSONArray(acceptedJson);
                db.markSynced(accepted);
                db.clearSaleErrors(accepted);
                runOnUiThread(() -> status.setText(
                        "Ventes acceptées par le serveur.\nMise à jour du catalogue et du stock…"));
            } catch (Exception e) {
                reportError("Marquage local impossible : " + e.getMessage());
            }
        }

        @JavascriptInterface public void markSalesRejected(String rejectedJson) {
            try {
                db.markSaleErrors(new JSONArray(rejectedJson));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText(
                        "Impossible d’enregistrer le détail des ventes refusées : " + e.getMessage()));
            }
        }

        @JavascriptInterface public void catalogBegin(String session) {
            synchronized (catalogLock) {
                catalogSession = session == null ? "" : session;
                catalogBuffer = new StringBuilder(256 * 1024);
            }
        }

        @JavascriptInterface public void catalogChunk(String session, String chunk) {
            synchronized (catalogLock) {
                if (session != null && session.equals(catalogSession) && chunk != null) {
                    catalogBuffer.append(chunk);
                }
            }
        }

        @JavascriptInterface public void catalogEnd(String session) {
            try {
                String json;
                synchronized (catalogLock) {
                    if (session == null || !session.equals(catalogSession)) {
                        throw new IllegalStateException("Session catalogue invalide.");
                    }
                    json = catalogBuffer.toString();
                    catalogBuffer = new StringBuilder();
                    catalogSession = "";
                }
                db.applyCatalog(new JSONObject(json));
                runOnUiThread(() -> status.setText(
                        "Catalogue SQLite mis à jour.\nProduits : " + db.productCount()
                                + "\nPacks : " + db.packCount()
                                + "\nUtilisateurs : " + db.appUserCount()
                                + "\nSalariés : " + db.salaryEmployeeCount()
                                + "\nAvances : " + db.advanceCount()
                                + "\nPaies : " + db.payrollTotalCount()
                                + "\nPaiements paie : " + db.payrollPaymentCount()
                                + "\nOpérations master en attente : " + db.pendingMasterCount()
                                + "\nVentes en attente : " + db.pendingCount()));
            } catch (Exception e) {
                reportError("Import catalogue impossible : " + e.getMessage());
            }
        }

        @JavascriptInterface public void finishSync(String message) {
            final String msg = message == null || message.trim().isEmpty()
                    ? "Synchronisation terminée."
                    : message;
            runOnUiThread(() -> {
                status.setText(msg + "\nOpérations master restantes : " + db.pendingMasterCount() + "\nVentes restantes : " + db.pendingCount());
                Toast.makeText(SyncActivity.this, msg, Toast.LENGTH_LONG).show();
            });
        }

        @JavascriptInterface public void reportStatus(String message) {
            runOnUiThread(() -> status.setText(message == null ? "" : message));
        }

        @JavascriptInterface public void reportError(String message) {
            final String msg = message == null ? "Erreur inconnue" : message;
            db.markSyncError(msg);
            runOnUiThread(() -> status.setText(
                    "Synchronisation non terminée :\n" + msg
                            + "\n\nLes données non encore acceptées restent dans SQLite."));
        }
    }
}
