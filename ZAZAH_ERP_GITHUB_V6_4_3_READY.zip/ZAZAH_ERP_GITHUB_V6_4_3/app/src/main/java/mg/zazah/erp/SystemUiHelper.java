package mg.zazah.erp;

import android.app.Activity;
import android.view.View;

/**
 * Cache uniquement la barre de navigation Android du bas.
 * Utilise les flags historiques compatibles minSdk 23 afin de ne rien
 * exécuter au niveau Application avant le lancement de MainActivity.
 */
public final class SystemUiHelper {
    private SystemUiHelper() {}

    private static final int FLAGS =
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;

    public static void install(Activity activity) {
        if (activity == null || activity.getWindow() == null) return;
        final View decor = activity.getWindow().getDecorView();
        if (decor == null) return;

        final Runnable hide = () -> {
            try { decor.setSystemUiVisibility(FLAGS); }
            catch (Throwable ignored) { }
        };

        hide.run();
        try {
            decor.setOnSystemUiVisibilityChangeListener(visibility -> {
                if ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) {
                    decor.postDelayed(hide, 350);
                }
            });
        } catch (Throwable ignored) { }
    }
}
