package mg.zazah.erp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TreeSet;

public class PayrollActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private Spinner monthSpinner;
    private ListView list;
    private TextView txtCount;
    private final ArrayList<PayrollRow> rows = new ArrayList<>();
    private final ArrayList<Employee> employees = new ArrayList<>();
    private final ArrayList<MonthOption> monthOptions = new ArrayList<>();
    private final NumberFormat nf = NumberFormat.getNumberInstance(Locale.FRANCE);
    private boolean monthListenerReady = false;

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_payroll);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        monthSpinner = findViewById(R.id.inputPayrollMonth);
        list = findViewById(R.id.listPayrolls);
        txtCount = findViewById(R.id.txtPayrollCount);

        buildMonthSpinner(null);

        findViewById(R.id.btnPayrollShow).setOnClickListener(v -> load());
        findViewById(R.id.btnGenerateOne).setOnClickListener(v -> generateOne());
        findViewById(R.id.btnGenerateAll).setOnClickListener(v -> confirmGenerateAll());
        findViewById(R.id.btnRecalcPayroll).setOnClickListener(v -> confirmRecalc());
        list.setOnItemClickListener((p, v, pos, id) -> showActions(rows.get(pos)));

        monthListenerReady = true;
        monthSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (monthListenerReady) load();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        loadEmployees();
        load();
    }

    @Override protected void onResume() {
        super.onResume();
        if (db == null) return;
        String keep = selectedMonth();
        loadEmployees();
        monthListenerReady = false;
        buildMonthSpinner(keep);
        monthListenerReady = true;
        load();
    }

    private void buildMonthSpinner(String selectedValue) {
        TreeSet<String> values = new TreeSet<>();
        String latestExisting = null;

        // Périodes réellement présentes en base : regroupées par le mois de FIN de période.
        Cursor existing = db.payrollMonths();
        while (existing.moveToNext()) {
            String g = existing.getString(0);
            if (g != null && g.matches("\\d{4}-\\d{2}")) {
                values.add(g);
                latestExisting = g;
            }
        }
        existing.close();

        // Fenêtre pratique pour créer les prochaines périodes.
        Calendar base = Calendar.getInstance();
        base.set(Calendar.DAY_OF_MONTH, 1);
        SimpleDateFormat valueFormat = new SimpleDateFormat("yyyy-MM", Locale.ROOT);
        for (int offset = -12; offset <= 6; offset++) {
            Calendar c = (Calendar) base.clone();
            c.add(Calendar.MONTH, offset);
            values.add(valueFormat.format(c.getTime()));
        }

        // Au premier affichage : dernière période réellement disponible, sinon période courante.
        if (selectedValue == null || !selectedValue.matches("\\d{4}-\\d{2}")) {
            selectedValue = latestExisting != null ? latestExisting : DatabaseHelper.currentMonth();
        }
        values.add(selectedValue);

        ArrayList<String> sorted = new ArrayList<>(values);
        Collections.sort(sorted);
        monthOptions.clear();
        ArrayList<String> labels = new ArrayList<>();
        int selectedIndex = 0;
        for (int i = 0; i < sorted.size(); i++) {
            MonthOption o = new MonthOption(sorted.get(i), "Période : " + monthLabel(sorted.get(i)));
            monthOptions.add(o);
            labels.add(o.label);
            if (o.value.equals(selectedValue)) selectedIndex = i;
        }

        monthSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        monthSpinner.setSelection(selectedIndex);
    }

    private String selectedMonth() {
        int p = monthSpinner == null ? -1 : monthSpinner.getSelectedItemPosition();
        if (p < 0 || p >= monthOptions.size()) return DatabaseHelper.currentMonth();
        return monthOptions.get(p).value;
    }

    private static String monthLabel(String month) {
        String[] fr = {"Janv", "Févr", "Mars", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"};
        try {
            int y = Integer.parseInt(month.substring(0, 4));
            int m = Integer.parseInt(month.substring(5, 7));
            return fr[m - 1] + "-" + String.format(Locale.ROOT, "%02d", y % 100);
        } catch (Exception e) {
            return month;
        }
    }

    private void loadEmployees() {
        employees.clear();
        Cursor c = db.salaries();
        while (c.moveToNext()) {
            Employee e = new Employee();
            e.id = c.getLong(0);
            e.label = (c.getString(1).isEmpty() ? "" : c.getString(1) + " - ") + c.getString(2);
            e.days = c.getDouble(8);
            e.active = c.getInt(9) == 1;
            if (e.active) employees.add(e);
        }
        c.close();
    }

    private void load() {
        String selected = selectedMonth();
        try {
            Cursor c = db.payrolls(selected);
            rows.clear();
            ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
            while (c.moveToNext()) {
                PayrollRow r = new PayrollRow();
                r.id = c.getLong(0); r.employeeId = c.getLong(1); r.matricule = c.getString(2); r.name = c.getString(3);
                r.start = c.getString(4); r.end = c.getString(5); r.base = c.getDouble(6); r.meal = c.getDouble(7);
                r.advance = c.getDouble(8); r.net = c.getDouble(9); r.paid = c.getDouble(10); r.remaining = Math.max(0, c.getDouble(11));
                r.days = c.getDouble(12); r.mealPerDay = c.getDouble(13); rows.add(r);
                String status = r.paid <= 0.009 ? "EN ATTENTE" : r.remaining <= 0.009 ? "PAYÉ" : "PARTIEL";
                String title = (r.matricule.isEmpty() ? "" : r.matricule + " - ") + r.name + " • " + status;
                String sub = "Période " + dateFr(r.start) + " au " + dateFr(r.end) +
                        "\nNet " + ar(r.net) + " • Payé " + ar(r.paid) + " • Reste " + ar(r.remaining) +
                        "\nBase " + ar(r.base) + " + Repas " + ar(r.meal) + " - Avance " + ar(r.advance);
                items.add(new TwoLineAdapter.Item(title, sub));
            }
            c.close();
            list.setAdapter(new TwoLineAdapter(this, items));
            txtCount.setText(rows.size() + " paie(s) • Période : " + monthLabel(selected));
        } catch (Exception e) {
            toast(e.getMessage());
        }
    }

    private void generateOne() {
        if (employees.isEmpty()) { toast("Ajoutez d'abord un salarié actif."); return; }
        final String selected = selectedMonth();
        LinearLayout box = box();
        Spinner sp = new Spinner(this);
        ArrayList<String> labels = new ArrayList<>();
        for (Employee e : employees) labels.add(e.label);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        box.addView(sp);

        String[] defaultPeriod;
        try { defaultPeriod = db.suggestedPayrollPeriod(employees.get(0).id, selected); }
        catch (Exception ex) { toast(ex.getMessage()); return; }

        EditText periodStart = input("Début période AAAA-MM-JJ", InputType.TYPE_CLASS_DATETIME);
        periodStart.setText(defaultPeriod[0]); box.addView(periodStart);
        EditText periodEnd = input("Fin période AAAA-MM-JJ", InputType.TYPE_CLASS_DATETIME);
        periodEnd.setText(defaultPeriod[1]); box.addView(periodEnd);
        EditText days = input("Jours repas", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        days.setText(fmt(employees.get(0).days)); box.addView(days);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                days.setText(fmt(employees.get(pos).days));
                try {
                    String[] own = db.suggestedPayrollPeriod(employees.get(pos).id, selected);
                    periodStart.setText(own[0]);
                    periodEnd.setText(own[1]);
                } catch (Exception ignored) { }
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        AlertDialog dlg = new DialogUi.Builder(this)
                .setTitle("Générer une paie • Période : " + monthLabel(selected))
                .setView(box)
                .setPositiveButton("Générer", null)
                .setNegativeButton("Annuler", null)
                .create();
        dlg.setOnShowListener(x -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                Employee e = employees.get(sp.getSelectedItemPosition());
                db.generatePayroll(e.id, selected, periodStart.getText().toString(), periodEnd.getText().toString(), num(days), true);
                dlg.dismiss();
                buildMonthSpinner(selected);
                load();
                Toast.makeText(this, "Paie générée / recalculée", Toast.LENGTH_SHORT).show();
            } catch (Exception ex) { toast(ex.getMessage()); }
        }));
        DialogUi.show(dlg);
    }

    private void confirmGenerateAll() {
        final String selected = selectedMonth();
        DialogUi.show(new DialogUi.Builder(this)
                .setTitle("Générer toutes les paies • Période : " + monthLabel(selected) + " ?")
                .setMessage("Chaque salarié garde sa propre période. Les paies déjà existantes seront ignorées.")
                .setPositiveButton("Générer", (d, w) -> {
                    try {
                        int n = db.generateAllPayrolls(selected);
                        buildMonthSpinner(selected);
                        load();
                        toast(n + " nouvelle(s) paie(s) générée(s).");
                    } catch (Exception e) { toast(e.getMessage()); }
                })
                .setNegativeButton("Annuler", null));
    }

    private void confirmRecalc() {
        final String selected = selectedMonth();
        DialogUi.show(new DialogUi.Builder(this)
                .setTitle("Recalculer la période " + monthLabel(selected) + " ?")
                .setMessage("Salaire, repas et avances seront recalculés. Les paiements déjà enregistrés restent séparés.")
                .setPositiveButton("Recalculer", (d, w) -> {
                    try {
                        int n = db.recalculatePayrollPeriod(selected);
                        monthListenerReady = false;
                        buildMonthSpinner(selected);
                        monthListenerReady = true;
                        load();
                        toast(n + " paie(s) recalculée(s) • base actuelle + avances de leur propre période.");
                    } catch (Exception e) { toast(e.getMessage()); }
                })
                .setNegativeButton("Annuler", null));
    }

    private void showActions(PayrollRow r) {
        String[] a = {"Enregistrer un paiement", "Historique des paiements", "Détails de la paie", "Supprimer la paie"};
        DialogUi.show(new DialogUi.Builder(this).setTitle(r.name + " • Reste " + ar(r.remaining)).setItems(a, (d, w) -> {
            if (w == 0) showPayment(r); else if (w == 1) showPayments(r); else if (w == 2) showDetails(r); else confirmDelete(r);
        }));
    }

    private void showPayment(PayrollRow r) {
        if (r.remaining <= 0.009) { toast("Cette paie est déjà entièrement payée."); return; }
        LinearLayout box = box();
        EditText amount = input("Montant de ce paiement", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amount.setText(fmt(r.remaining)); box.addView(amount);
        EditText date = input("Date paiement AAAA-MM-JJ", InputType.TYPE_CLASS_DATETIME);
        date.setText(DatabaseHelper.today()); box.addView(date);
        Spinner mode = new Spinner(this);
        String[] modes = {"ESPECES", "MVOLA", "ORANGE_MONEY", "AIRTEL_MONEY", "VIREMENT", "AUTRE"};
        mode.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes)); box.addView(mode);
        EditText ref = input("Référence (optionnel)", InputType.TYPE_CLASS_TEXT); box.addView(ref);
        EditText note = input("Remarque (optionnel)", InputType.TYPE_CLASS_TEXT); box.addView(note);
        AlertDialog dlg = new DialogUi.Builder(this).setTitle("Paiement • Reste " + ar(r.remaining)).setView(box)
                .setPositiveButton("Enregistrer", null).setNegativeButton("Annuler", null).create();
        dlg.setOnShowListener(x -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                db.addPayrollPayment(r.id, num(amount), date.getText().toString(), String.valueOf(mode.getSelectedItem()), ref.getText().toString(), note.getText().toString());
                dlg.dismiss(); load(); Toast.makeText(this, "Paiement enregistré", Toast.LENGTH_SHORT).show();
            } catch (Exception ex) { toast(ex.getMessage()); }
        }));
        DialogUi.show(dlg);
    }

    private void showPayments(PayrollRow r) {
        Cursor c = db.payrollPayments(r.id); StringBuilder sb = new StringBuilder();
        while (c.moveToNext()) {
            sb.append(c.getString(2)).append(" • ").append(ar(c.getDouble(1))).append(" • ").append(c.getString(3));
            if (!c.getString(4).isEmpty()) sb.append(" • Réf ").append(c.getString(4));
            if (!c.getString(5).isEmpty()) sb.append("\n  ").append(c.getString(5));
            sb.append("\n\n");
        }
        c.close();
        if (sb.length() == 0) sb.append("Aucun paiement enregistré.");
        DialogUi.show(new DialogUi.Builder(this).setTitle("Historique • " + r.name).setMessage(sb.toString()).setPositiveButton("Fermer", null));
    }

    private void showDetails(PayrollRow r) {
        String status = r.paid <= .009 ? "EN ATTENTE" : r.remaining <= .009 ? "PAYÉ" : "PARTIEL";
        DialogUi.show(new DialogUi.Builder(this).setTitle(r.name).setMessage(
                "Période : " + dateFr(r.start) + " au " + dateFr(r.end) +
                "\nSalaire base : " + ar(r.base) +
                "\nRepas : " + fmt(r.days) + " × " + ar(r.mealPerDay) + " = " + ar(r.meal) +
                "\nAvances : " + ar(r.advance) +
                "\nNet calculé : " + ar(r.net) +
                "\nDéjà payé : " + ar(r.paid) +
                "\nReste : " + ar(r.remaining) +
                "\nStatut : " + status
        ).setPositiveButton("Fermer", null));
    }

    private void confirmDelete(PayrollRow r) {
        DialogUi.show(new DialogUi.Builder(this).setTitle("Supprimer cette paie ?")
                .setMessage("Les paiements liés seront aussi supprimés.")
                .setPositiveButton("Supprimer", (d, w) -> { db.deletePayroll(r.id); load(); })
                .setNegativeButton("Annuler", null));
    }

    private String dateFr(String iso) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
            in.setLenient(false);
            SimpleDateFormat out = new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE);
            Date d = in.parse(iso);
            return d == null ? iso : out.format(d);
        } catch (Exception e) { return iso == null ? "-" : iso; }
    }

    private String ar(double x) { return nf.format(x) + " Ar"; }
    private String fmt(double x) { return x == Math.rint(x) ? String.valueOf((long) x) : String.valueOf(x); }
    private double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(',', '.')); }
        catch (Exception x) { return 0; }
    }
    private LinearLayout box() {
        LinearLayout b = new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(20), dp(12), dp(20), 0); return b;
    }
    private EditText input(String h, int t) {
        EditText e = new EditText(this); e.setHint(h); e.setInputType(t); e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(9), dp(12), dp(9)); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9); e.setLayoutParams(lp); return e;
    }
    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density * v); }
    private void toast(String s) { Toast.makeText(this, s == null ? "Erreur" : s, Toast.LENGTH_LONG).show(); }

    private static class MonthOption {
        String value, label;
        MonthOption(String value, String label) { this.value = value; this.label = label; }
    }
    private static class Employee { long id; String label; double days; boolean active; }
    private static class PayrollRow {
        long id, employeeId; String matricule, name, start, end;
        double base, meal, advance, net, paid, remaining, days, mealPerDay;
    }
}
