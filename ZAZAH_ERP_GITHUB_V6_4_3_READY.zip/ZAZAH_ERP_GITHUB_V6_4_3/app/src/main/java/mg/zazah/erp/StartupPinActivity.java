package mg.zazah.erp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Version 6 - verrouillage PIN style téléphone.
 *
 * Le clavier numérique est intégré à l'écran : aucun clavier Android n'est
 * nécessaire. Dès que la suite saisie correspond au PIN local (4 à 8 chiffres),
 * la session s'ouvre automatiquement sans bouton "Se connecter".
 */
public class StartupPinActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private DatabaseHelper.AppUser currentUser;
    private TextView txtUser;
    private TextView txtInfo;
    private TextView txtAvatar;
    private TextView txtPinDots;
    private TextView txtPinStatus;
    private Button btnChangeUser;
    private final StringBuilder enteredPin = new StringBuilder();
    private boolean opening = false;

    @Override
    protected void onCreate(Bundle state) {
        UiTheme3D.installTheme(this);
        super.onCreate(state);

        // Évite qu'un ancien MainActivity reste derrière l'écran de verrouillage.
        if (!isTaskRoot()) {
            Intent restart = new Intent(this, StartupPinActivity.class);
            restart.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(restart);
            finish();
            return;
        }

        SystemUiHelper.install(this);
        setContentView(R.layout.activity_startup_pin);
        UiTheme3D.apply(this);

        db = new DatabaseHelper(this);
        txtUser = findViewById(R.id.txtStartupUser);
        txtInfo = findViewById(R.id.txtStartupInfo);
        txtAvatar = findViewById(R.id.txtStartupAvatar);
        txtPinDots = findViewById(R.id.txtStartupPinDots);
        txtPinStatus = findViewById(R.id.txtStartupPinStatus);
        btnChangeUser = findViewById(R.id.btnStartupChangeUser);

        setupPinKeypad();
        btnChangeUser.setOnClickListener(v -> chooseAnotherUser());
        findViewById(R.id.btnStartupExit).setOnClickListener(v -> finishAffinity());

        updatePinDots();
        prepareStartupLock();
    }

    private void setupPinKeypad() {
        bindDigit(R.id.btnStartupPin1, '1');
        bindDigit(R.id.btnStartupPin2, '2');
        bindDigit(R.id.btnStartupPin3, '3');
        bindDigit(R.id.btnStartupPin4, '4');
        bindDigit(R.id.btnStartupPin5, '5');
        bindDigit(R.id.btnStartupPin6, '6');
        bindDigit(R.id.btnStartupPin7, '7');
        bindDigit(R.id.btnStartupPin8, '8');
        bindDigit(R.id.btnStartupPin9, '9');
        bindDigit(R.id.btnStartupPin0, '0');

        View delete = findViewById(R.id.btnStartupPinDelete);
        delete.setOnClickListener(v -> {
            keypadHaptic(v);
            if (opening || enteredPin.length() == 0) return;
            enteredPin.deleteCharAt(enteredPin.length() - 1);
            setStatusNormal();
            updatePinDots();
        });
        delete.setOnLongClickListener(v -> {
            if (opening) return true;
            keypadHaptic(v);
            enteredPin.setLength(0);
            setStatusNormal();
            updatePinDots();
            return true;
        });
    }

    private void bindDigit(int viewId, char digit) {
        View key = findViewById(viewId);
        key.setOnClickListener(v -> {
            keypadHaptic(v);
            appendPinDigit(digit);
        });
    }

    private void appendPinDigit(char digit) {
        if (opening || currentUser == null || !currentUser.hasPin) return;
        if (enteredPin.length() >= 8) return;

        enteredPin.append(digit);
        setStatusNormal();
        updatePinDots();

        // Les PIN de l'application peuvent faire 4 à 8 chiffres. Comme les
        // anciens comptes ne stockent que le hash, on vérifie à partir du 4e
        // chiffre. Dès que le PIN correspond, la connexion est immédiate.
        if (enteredPin.length() >= 4 &&
                db.verifyAppUserPin(currentUser.id, enteredPin.toString())) {
            opening = true;
            txtPinStatus.setText("PIN correct • ouverture…");
            txtPinStatus.setTextColor(Color.parseColor("#86EFAC"));
            successHaptic(txtPinStatus);
            txtPinStatus.postDelayed(this::openMain, 120);
            return;
        }

        if (enteredPin.length() >= 8) {
            showWrongPin();
        }
    }

    private void showWrongPin() {
        txtPinStatus.setText("PIN incorrect • réessayez");
        txtPinStatus.setTextColor(Color.parseColor("#FCA5A5"));
        Toast.makeText(this, "PIN incorrect", Toast.LENGTH_SHORT).show();
        errorHaptic(txtPinStatus);
        txtPinStatus.postDelayed(() -> {
            enteredPin.setLength(0);
            updatePinDots();
            setStatusNormal();
        }, 420);
    }

    private void setStatusNormal() {
        txtPinStatus.setText("Saisissez votre PIN • connexion automatique");
        txtPinStatus.setTextColor(Color.parseColor("#AFC0D8"));
    }

    private void updatePinDots() {
        int count = enteredPin.length();
        StringBuilder dots = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i > 0) dots.append(' ');
            dots.append(i < count ? '●' : '○');
        }
        txtPinDots.setText(dots.toString());
    }

    private void keypadHaptic(View view) {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void successHaptic(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            view.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
        } else {
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        }
    }

    private void errorHaptic(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            view.performHapticFeedback(HapticFeedbackConstants.REJECT);
        } else {
            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        }
    }

    private void prepareStartupLock() {
        long id = AppPrefs.sessionUserId(this);
        currentUser = db.appUser(id);

        if (currentUser == null || !currentUser.active) {
            if (id > 0) AppPrefs.clearSession(this);
            openStartupSessionPicker();
            return;
        }

        if (!currentUser.hasPin) {
            openMain();
            return;
        }

        String displayName = currentUser.displayName();
        txtUser.setText(displayName);
        txtAvatar.setText(initialOf(displayName));
        txtInfo.setText("@" + currentUser.username + " • " + currentUser.roleLabel()
                + "\nEntrez votre PIN pour ouvrir votre espace.");
        btnChangeUser.setVisibility(View.VISIBLE);
        enteredPin.setLength(0);
        updatePinDots();
        setStatusNormal();
    }

    private String initialOf(String value) {
        String text = value == null ? "" : value.trim();
        if (text.isEmpty()) return "U";
        return text.substring(0, 1).toUpperCase(Locale.ROOT);
    }

    private void chooseAnotherUser() {
        Intent i = new Intent(this, SessionActivity.class);
        i.putExtra("startup_mode", true);
        startActivity(i);
        finish();
    }

    private void openStartupSessionPicker() {
        Intent i = new Intent(this, SessionActivity.class);
        i.putExtra("startup_mode", true);
        startActivity(i);
        finish();
    }

    private void openMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
