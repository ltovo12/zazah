package mg.zazah.erp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;

import androidx.core.content.ContextCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Impression BLE propriétaire SC03h / iPrint (AE30 / AE01, protocole 0x51 0x78).
 * Le texte est d'abord rendu en bitmap 384 px, puis envoyé ligne par ligne.
 */
public final class Sc03BlePrinter {
    private static final int WIDTH = 384;
    private static final int PRINT_TYPE_IMAGE = 0x00;
    private static final int PRINT_TYPE_LABEL = 0x03;
    private static final UUID SERVICE_AE30 = UUID.fromString("0000ae30-0000-1000-8000-00805f9b34fb");
    private static final UUID TX_AE01 = UUID.fromString("0000ae01-0000-1000-8000-00805f9b34fb");

    public static boolean isSc03(Context c) {
        if ("SC03".equalsIgnoreCase(AppPrefs.printerMode(c))) return true;
        String n = AppPrefs.printerName(c);
        return n != null && n.toLowerCase(Locale.ROOT).contains("sc03");
    }

    private static boolean hasConnectPermission(Context c) {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                ContextCompat.checkSelfPermission(c, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    public static void printSale(Context context, JSONObject receipt, JSONArray lines, String clientName,
                                 BluetoothEscPosPrinter.Callback callback) {
        new Thread(() -> {
            try {
                Bitmap bmp = renderTicket(context, receipt, lines, clientName);
                printBitmap(context, bmp, 2, PRINT_TYPE_IMAGE);
                callback.onSuccess();
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Erreur SC03h" : e.getMessage());
            }
        }, "SC03h-ticket").start();
    }

    public static void printLabel(Context context, String product, String variant, String code, double price,
                                  long variantId, int copies, int type,
                                  BluetoothEscPosPrinter.Callback callback) {
        new Thread(() -> {
            try {
                int count = Math.max(1, copies);
                for (int i = 0; i < count; i++) {
                    Bitmap bmp = renderLabel(product, variant, code, price, variantId, type);
                    // V6.3.9 : on ajoute un retour/avance papier final plus confortable pour les étiquettes.
                    printBitmap(context, bmp, 1, PRINT_TYPE_LABEL);
                    Thread.sleep(260);
                }
                callback.onSuccess();
            } catch (Exception e) {
                callback.onError(e.getMessage() == null ? "Erreur SC03h" : e.getMessage());
            }
        }, "SC03h-label").start();
    }

    public static void printBitmap(Context context, Bitmap source, int feedCount, int printType) throws Exception {
        if (!hasConnectPermission(context)) throw new Exception("Autorisation Bluetooth manquante");
        String address = AppPrefs.printerAddress(context);
        if (address == null || address.trim().isEmpty()) throw new Exception("Aucune imprimante SC03h configurée");
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new Exception("Bluetooth non disponible");
        if (!adapter.isEnabled()) throw new Exception("Activez le Bluetooth");
        BluetoothDevice device = adapter.getRemoteDevice(address.trim());
        GattSession session = new GattSession(context, device);
        try {
            session.connect();

            // V6.3.7 : réinitialisation complète avant CHAQUE impression.
            // On ne dépend plus de l'état thermique laissé par l'impression précédente.
            preparePrintState(session, printType);

            session.send(command(0xBD, new byte[]{0x19}));
            Thread.sleep(60);

            Bitmap bmp = fitWidth(source, WIDTH);
            int height = bmp.getHeight();
            int[] pixels = new int[WIDTH];
            for (int y = 0; y < height; y++) {
                bmp.getPixels(pixels, 0, WIDTH, 0, y, WIDTH, 1);
                byte[] row = new byte[48];
                for (int x = 0; x < WIDTH; x++) {
                    int color = pixels[x];
                    int gray = (Color.red(color) * 30 + Color.green(color) * 59 + Color.blue(color) * 11) / 100;
                    // léger tramage pour photos / anti-aliasing
                    int threshold = ((x + y) & 1) == 0 ? 148 : 176;
                    if (gray < threshold) row[x >> 3] |= (byte)(1 << (x & 7));
                }
                session.send(command(0xA2, row));

                // Pause courte et régulière pour éviter de saturer le buffer BLE.
                if ((y + 1) % 24 == 0) Thread.sleep(28);

                // Sur les impressions longues la SC03h peut dériver en densité.
                // On réaffirme la densité périodiquement sans interrompre le bitmap.
                if ((y + 1) % 96 == 0) {
                    Thread.sleep(55);
                    session.send(command(0xA4, new byte[]{0x33}));
                    Thread.sleep(35);
                }
            }

            session.send(command(0xBD, new byte[]{0x19}));
            byte[] setPaper = command(0xA1, new byte[]{0x30,0x00});
            int feeds = Math.max(0, Math.min(5, feedCount));
            for (int i = 0; i < feeds; i++) session.send(setPaper);

            // V6.3.7 : remise à zéro propre après impression.
            resetPrintState(session);
            Thread.sleep(450);
        } finally {
            session.close();
        }
    }

    private static void preparePrintState(GattSession session, int printType) throws Exception {
        session.send(command(0xA3, new byte[]{0x00}));
        Thread.sleep(80);
        session.send(command(0xA4, new byte[]{0x33}));
        session.send(command(0xAF, new byte[]{0x20, 0x4E}));
        session.send(command(0xBE, new byte[]{(byte)(printType & 0xFF)}));
        session.send(command(0xA6, new byte[]{(byte)0xAA,0x55,0x17,0x38,0x44,0x5F,0x5F,0x5F,0x44,0x38,0x2C}));
        Thread.sleep(180);
        session.send(command(0xA4, new byte[]{0x33}));
        Thread.sleep(80);
    }

    private static void resetPrintState(GattSession session) throws Exception {
        session.send(command(0xA6, new byte[]{(byte)0xAA,0x55,0x17,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x17}));
        Thread.sleep(80);
        session.send(command(0xA3, new byte[]{0x00}));
        Thread.sleep(120);
        // Deuxième reset pour éviter que l'état de chauffe du ticket précédent persiste.
        session.send(command(0xA3, new byte[]{0x00}));
    }

    private static Bitmap fitWidth(Bitmap src, int width) {
        if (src.getWidth() == width) return src;
        float ratio = width / (float) src.getWidth();
        return Bitmap.createScaledBitmap(src, width, Math.max(1, Math.round(src.getHeight() * ratio)), true);
    }

    private static Bitmap renderTicket(Context context, JSONObject r, JSONArray lines, String clientName) throws Exception {
        DatabaseHelper db = new DatabaseHelper(context.getApplicationContext());
        String company = cleanText(db.setting("ticket_company_name", "ZAZAH TSENA SABOTSY")).trim();
        String address = cleanText(db.setting("ticket_company_address", "")).trim();
        String phone = cleanText(db.setting("ticket_company_phone", "")).trim();
        String message = cleanText(db.setting("ticket_message", "Merci pour votre achat !")).trim();
        db.close();

        ArrayList<Line> rows = new ArrayList<>();
        rows.add(new Line(company.isEmpty()?"ZAZAH TSENA SABOTSY":company, 28, true, true));
        if (!address.isEmpty()) rows.add(new Line(address, 17, false, true));
        if (!phone.isEmpty()) rows.add(new Line("Tel : " + phone, 17, false, true));
        rows.add(new Line("TICKET DE CAISSE", 27, true, true));
        rows.add(new Line("N° " + ztsTicketNo(r), 19, true, false));
        rows.add(new Line("Date : " + cleanText(r.optString("date_vente", "")), 17, false, false));
        if (clientName != null && !clientName.trim().isEmpty()) rows.add(new Line("Client : " + cleanText(clientName.trim()), 17, false, false));
        rows.add(new Line("--------------------------------", 17, false, false));

        // Même présentation des packs que le ticket ERP en ligne :
        // nom du pack + prix global une seule fois, puis composants avec leur quantité.
        LinkedHashMap<String, Double> packTotals = new LinkedHashMap<>();
        for (int i=0;i<lines.length();i++) {
            JSONObject l=lines.getJSONObject(i);
            String des=cleanText(l.optString("designation","Produit"));
            int sep=des.indexOf(" • ");
            if (sep>0) {
                String packName=des.substring(0,sep).trim();
                if (packName.toLowerCase(Locale.ROOT).startsWith("pack")) {
                    double q=l.optDouble("quantite",0), p=l.optDouble("prix",0);
                    double total=l.has("total_ligne")?l.optDouble("total_ligne",q*p):q*p;
                    packTotals.put(packName, packTotals.containsKey(packName)?packTotals.get(packName)+total:total);
                }
            }
        }
        HashSet<String> printedPacks=new HashSet<>();

        for (int i=0;i<lines.length();i++) {
            JSONObject l=lines.getJSONObject(i);
            String des=cleanText(l.optString("designation","Produit"));
            double q=l.optDouble("quantite",0), p=l.optDouble("prix",0);
            double total=l.has("total_ligne")?l.optDouble("total_ligne",q*p):q*p;
            int sep=des.indexOf(" • ");
            String packName=sep>0?des.substring(0,sep).trim():"";
            boolean isPack=sep>0&&packName.toLowerCase(Locale.ROOT).startsWith("pack");

            if (isPack) {
                String component=des.substring(sep+3).trim();
                if (!printedPacks.contains(packName)) {
                    printedPacks.add(packName);
                    rows.add(new Line(packName+"     "+money(packTotals.get(packName))+" Ar", 22, true, false));
                }
                rows.add(new Line("  "+component+"     Qte "+fmtQty(q), 21, true, false));
            } else {
                rows.add(new Line(des, 22, true, false));
                rows.add(new Line(fmtQty(q)+" x "+money(p)+" Ar     "+money(total)+" Ar", 18, false, false));
            }
            if(i<lines.length()-1) rows.add(new Line("................................", 14, false, false));
        }

        rows.add(new Line("--------------------------------", 17, false, false));
        double subtotal=r.optDouble("sous_total",0), remise=r.optDouble("remise",0), tva=r.optDouble("montant_tva",0), liv=r.optDouble("frais_livraison",0), total=r.optDouble("montant_total",0);
        rows.add(new Line("Sous-total : "+money(subtotal)+" Ar",18,false,false));
        if(remise>0) rows.add(new Line("Remise : -"+money(remise)+" Ar",18,false,false));
        if(tva>0) rows.add(new Line("TVA : "+money(tva)+" Ar",18,false,false));
        if(liv>0) rows.add(new Line("Livraison : "+money(liv)+" Ar",18,false,false));
        rows.add(new Line("TOTAL : "+money(total)+" Ar",30,true,true));
        if(!message.isEmpty()) rows.add(new Line(message,18,false,true));
        rows.add(new Line("ZAZAH TSENA SABOTSY",17,true,true));
        return renderLines(rows);
    }

    private static Bitmap renderLabel(String product, String variant, String code, double price, long variantId, int type) throws Exception {
        String payload = code==null||code.trim().isEmpty()?String.valueOf(variantId):code.trim();
        if (type == BluetoothEscPosPrinter.LABEL_QR_40X30) {
            return renderQr40x30(product, variant, payload, price);
        }
        if (type == BluetoothEscPosPrinter.LABEL_QR || type == BluetoothEscPosPrinter.LABEL_QR_60X40) {
            return renderQr60x40(product, variant, payload, price);
        }
        return renderBarcodeModern(product, variant, payload, price);
    }

    private static Bitmap renderBarcodeModern(String product, String variant, String payload, double price) throws Exception {
        // Format compact proche de l'aperçu 40x30 : contenu centré sur ~40 mm de large.
        int h = 240;
        Bitmap bmp = Bitmap.createBitmap(WIDTH, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp); c.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTextAlign(Paint.Align.CENTER);

        final float cx = WIDTH / 2f;
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(10);
        c.drawText("ZAZAH TSENA SABOTSY", cx, 15, p);

        p.setTextSize(22);
        c.drawText(trim(product, 26), cx, 42, p);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(14);
        if (variant != null && !variant.trim().isEmpty()) c.drawText(trim(variant, 34), cx, 63, p);

        BarcodeFormat fmt = BarcodeFormat.CODE_128;
        int bw = 310, bh = 88, top = 75;
        BitMatrix matrix = new MultiFormatWriter().encode(payload, fmt, bw, bh);
        Bitmap codeBmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        for (int y=0;y<bh;y++) for (int x=0;x<bw;x++) codeBmp.setPixel(x,y,matrix.get(x,y)?Color.BLACK:Color.WHITE);
        c.drawBitmap(codeBmp, (WIDTH-bw)/2f, top, null);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(16);
        c.drawText(trim(payload, 36), cx, 184, p);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(28);
        c.drawText(money(price)+" Ar", cx, 220, p);
        return bmp;
    }

    private static Bitmap renderQr40x30(String product, String variant, String payload, double price) throws Exception {
        // V6.4.3 : texte vertical à gauche + grand QR à droite.
        int h = 220;
        Bitmap bmp=Bitmap.createBitmap(WIDTH,h,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(bmp); c.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTextAlign(Paint.Align.LEFT);

        int panelRight = 188;
        int qrMarginRight = 18;
        int qr = 164;
        int qrLeft = WIDTH - qr - qrMarginRight;
        int qrTop = (h - qr) / 2;
        float baseY = h - 12;

        // Séparateur vertical fin entre texte et QR.
        p.setStrokeWidth(1.5f);
        c.drawLine(panelRight, 14, panelRight, h-14, p);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(11);
        drawVerticalText(c,p,"ZAZAH TSENA SABOTSY",26,baseY);

        p.setTextSize(18);
        drawVerticalText(c,p,trim(product,18),62,baseY);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(13);
        if(variant!=null && !variant.trim().isEmpty()) drawVerticalText(c,p,trim(variant,18),96,baseY);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(24);
        drawVerticalText(c,p,money(price)+" Ar",132,baseY);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(11);
        drawVerticalText(c,p,trim(payload,18),164,baseY);

        BarcodeFormat fmt = BarcodeFormat.QR_CODE;
        BitMatrix matrix=new MultiFormatWriter().encode(payload,fmt,qr,qr);
        Bitmap codeBmp=Bitmap.createBitmap(qr,qr,Bitmap.Config.ARGB_8888);
        for(int yy=0;yy<qr;yy++) for(int xx=0;xx<qr;xx++) codeBmp.setPixel(xx,yy,matrix.get(xx,yy)?Color.BLACK:Color.WHITE);
        c.drawBitmap(codeBmp,qrLeft,qrTop,null);
        return bmp;
    }

    private static Bitmap renderQr60x40(String product, String variant, String payload, double price) throws Exception {
        // V6.4.3 : texte vertical à gauche + QR encore plus grand à droite.
        int h = 250;
        Bitmap bmp=Bitmap.createBitmap(WIDTH,h,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(bmp); c.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTextAlign(Paint.Align.LEFT);

        int panelRight = 176;
        int qrMarginRight = 16;
        int qr = 192;
        int qrLeft = WIDTH - qr - qrMarginRight;
        int qrTop = (h - qr) / 2;
        float baseY = h - 12;

        p.setStrokeWidth(1.5f);
        c.drawLine(panelRight, 14, panelRight, h-14, p);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(11);
        drawVerticalText(c,p,"ZAZAH TSENA SABOTSY",24,baseY);

        p.setTextSize(19);
        drawVerticalText(c,p,trim(product,21),58,baseY);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(14);
        if(variant!=null && !variant.trim().isEmpty()) drawVerticalText(c,p,trim(variant,22),94,baseY);

        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(27);
        drawVerticalText(c,p,money(price)+" Ar",132,baseY);

        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(12);
        drawVerticalText(c,p,trim(payload,22),162,baseY);

        BarcodeFormat fmt = BarcodeFormat.QR_CODE;
        BitMatrix matrix=new MultiFormatWriter().encode(payload,fmt,qr,qr);
        Bitmap codeBmp=Bitmap.createBitmap(qr,qr,Bitmap.Config.ARGB_8888);
        for(int yy=0;yy<qr;yy++) for(int xx=0;xx<qr;xx++) codeBmp.setPixel(xx,yy,matrix.get(xx,yy)?Color.BLACK:Color.WHITE);
        c.drawBitmap(codeBmp,qrLeft,qrTop,null);
        return bmp;
    }

    private static void drawVerticalText(Canvas c, Paint p, String text, float x, float bottomY) {
        if(text==null || text.trim().isEmpty()) return;
        c.save();
        c.rotate(-90f, x, bottomY);
        c.drawText(text, x, bottomY, p);
        c.restore();
    }

    private static Bitmap renderLines(ArrayList<Line> rows) {
        Paint measure=new Paint(Paint.ANTI_ALIAS_FLAG); int total=20;
        ArrayList<Line> expanded=new ArrayList<>();
        for(Line l:rows){
            measure.setTextSize(l.size); measure.setTypeface(l.bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);
            for(String s:wrapPixels(l.text,measure,WIDTH-24)){expanded.add(new Line(s,l.size,l.bold,l.center)); total += l.size+9;}
        }
        Bitmap bmp=Bitmap.createBitmap(WIDTH,Math.max(120,total+18),Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp); c.drawColor(Color.WHITE);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); int y=25;
        for(Line l:expanded){p.setColor(Color.BLACK);p.setTextSize(l.size);p.setTypeface(l.bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);p.setTextAlign(l.center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(l.text,l.center?WIDTH/2f:12,y,p);y+=l.size+9;}
        return bmp;
    }

    private static ArrayList<String> wrapPixels(String text, Paint p, int max) {
        ArrayList<String> out=new ArrayList<>(); String[] words=(text==null?"":text).trim().split("\\s+"); String line="";
        for(String w:words){String t=line.isEmpty()?w:line+" "+w;if(p.measureText(t)<=max)line=t;else{if(!line.isEmpty())out.add(line);line=w;}}
        if(!line.isEmpty())out.add(line); if(out.isEmpty())out.add(""); return out;
    }

    private static byte[] command(int cmd, byte[] data) {
        int n=data==null?0:data.length; byte[] out=new byte[n+8]; out[0]=0x51;out[1]=0x78;out[2]=(byte)cmd;out[3]=0;out[4]=(byte)(n&0xff);out[5]=(byte)((n>>8)&0xff);
        if(n>0)System.arraycopy(data,0,out,6,n);out[6+n]=crc8(data);out[7+n]=(byte)0xff;return out;
    }
    private static byte crc8(byte[] data){int crc=0;if(data!=null)for(byte bb:data){crc^=bb&0xff;for(int i=0;i<8;i++)crc=((crc&0x80)!=0)?((crc<<1)^0x07):(crc<<1);crc&=0xff;}return(byte)crc;}
    private static String cleanText(String s){
        if(s==null)return "";
        String out=s.replace('\u00a0',' ').trim();

        // Répare plusieurs niveaux de mojibake UTF-8 (ex. sécurité -> sÃ©curitÃ©).
        for(int pass=0; pass<3; pass++){
            if(!(out.contains("Ã")||out.contains("Â")||out.contains("â")||out.contains("ð")||out.contains("ï¿½"))) break;
            String before=out;
            try{
                String fixed=new String(out.getBytes(StandardCharsets.ISO_8859_1),StandardCharsets.UTF_8);
                if(!fixed.contains("�") && badEncodingScore(fixed) < badEncodingScore(out)) out=fixed;
            }catch(Exception ignored){}
            if(out.equals(before)) break;
        }

        // Cas français fréquents encore visibles après une mauvaise double conversion.
        out=out
                .replace("Ã©","é").replace("Ã¨","è").replace("Ãª","ê").replace("Ã«","ë")
                .replace("Ã ","à ").replace("Ã ","à").replace("Ã¢","â").replace("Ã¤","ä")
                .replace("Ã¹","ù").replace("Ã»","û").replace("Ã¼","ü")
                .replace("Ã´","ô").replace("Ã¶","ö").replace("Ã®","î").replace("Ã¯","ï")
                .replace("Ã§","ç").replace("Ã‰","É").replace("Ãˆ","È").replace("Ã€","À")
                .replace("â€™","’").replace("â€˜","‘").replace("â€œ","\"").replace("â€","\"")
                .replace("â€“","-").replace("â€”","-").replace("Â°","°").replace("Â"," ")
                .replace("ï¿½","");

        // Quelques entités HTML possibles dans le paramètre en ligne.
        out=out.replace("&eacute;","é").replace("&egrave;","è").replace("&ecirc;","ê")
                .replace("&agrave;","à").replace("&ccedil;","ç").replace("&#039;","'")
                .replace("&apos;","'").replace("&quot;","\"").replace("&amp;","&");
        return out.trim();
    }

    private static int badEncodingScore(String s){
        if(s==null||s.isEmpty()) return 0;
        int score=0;
        String[] bad={"Ã","Â","â€","â€™","ðŸ","ï¿½","�"};
        for(String b:bad){int pos=0;while((pos=s.indexOf(b,pos))>=0){score+=3;pos+=b.length();}}
        return score;
    }
    private static String ztsTicketNo(JSONObject r){
        long id=r.optLong("id",0);
        if(id<=0){String raw=r.optString("num_vente","");String digits=raw.replaceAll("[^0-9]","");try{id=Long.parseLong(digits);}catch(Exception ignored){id=0;}}
        if(id>0)return String.format(Locale.ROOT,"ZTS%05d",id);
        String raw=cleanText(r.optString("num_vente",""));
        return raw.toUpperCase(Locale.ROOT).startsWith("ZTS")?raw:"ZTS"+raw.replaceAll("\\s+","");
    }
    private static String money(double v){return String.format(Locale.FRANCE,"%,.0f",v).replace('\u00a0',' ');} private static String fmtQty(double v){return Math.abs(v-Math.rint(v))<.00001?String.format(Locale.FRANCE,"%.0f",v):String.format(Locale.FRANCE,"%.1f",v);} private static String trim(String s,int n){if(s==null)return"";return s.length()<=n?s:s.substring(0,n-1)+"…";}

    private static final class Line { final String text; final float size; final boolean bold,center; Line(String t,float s,boolean b,boolean c){text=t;size=s;bold=b;center=c;} }

    private static final class GattSession {
        final Context context; final BluetoothDevice device; BluetoothGatt gatt; BluetoothGattCharacteristic tx;
        final CountDownLatch connected=new CountDownLatch(1), services=new CountDownLatch(1), mtu=new CountDownLatch(1); volatile String error="";
        GattSession(Context c,BluetoothDevice d){context=c.getApplicationContext();device=d;}
        final BluetoothGattCallback cb=new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int status,int state){if(status==BluetoothGatt.GATT_SUCCESS&&state==BluetoothProfile.STATE_CONNECTED){g.discoverServices();connected.countDown();}else if(state==BluetoothProfile.STATE_DISCONNECTED){if(error.isEmpty())error="Connexion SC03h interrompue";connected.countDown();services.countDown();}}
            @Override public void onServicesDiscovered(BluetoothGatt g,int status){if(status==BluetoothGatt.GATT_SUCCESS){BluetoothGattService s=g.getService(SERVICE_AE30);if(s!=null)tx=s.getCharacteristic(TX_AE01);if(tx==null)error="Service iPrint AE30/AE01 introuvable";}else error="Services BLE SC03h introuvables";services.countDown();}
            @Override public void onMtuChanged(BluetoothGatt g,int m,int status){mtu.countDown();}
        };
        void connect() throws Exception {
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)gatt=device.connectGatt(context,false,cb,BluetoothDevice.TRANSPORT_LE);else gatt=device.connectGatt(context,false,cb);
            if(gatt==null)throw new Exception("Connexion BLE impossible");
            if(!connected.await(10,TimeUnit.SECONDS))throw new Exception("Délai de connexion SC03h dépassé");
            if(!services.await(10,TimeUnit.SECONDS))throw new Exception("Délai de découverte SC03h dépassé");
            if(!error.isEmpty())throw new Exception(error); if(tx==null)throw new Exception("Caractéristique AE01 introuvable");
            try{gatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);}catch(Exception ignored){}
            try{gatt.requestMtu(123);mtu.await(3,TimeUnit.SECONDS);}catch(Exception ignored){}
            tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
            Thread.sleep(120);
        }
        void send(byte[] packet) throws Exception {
            if(gatt==null||tx==null)throw new Exception("SC03h non connectée");
            Exception last=null;
            for(int attempt=1; attempt<=4; attempt++){
                try{
                    boolean ok;
                    if(Build.VERSION.SDK_INT>=33){
                        ok=gatt.writeCharacteristic(tx,packet,BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)==BluetoothGatt.GATT_SUCCESS;
                    }else{
                        tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                        tx.setValue(packet);
                        ok=gatt.writeCharacteristic(tx);
                    }
                    if(ok){
                        Thread.sleep(12);
                        return;
                    }
                    last=new Exception("Pile BLE occupée");
                }catch(Exception e){
                    last=e;
                }
                // Laisse Android vider sa file BLE puis retente exactement la même trame.
                Thread.sleep(35L * attempt);
            }
            throw new Exception("Échec d'envoi vers SC03h après 4 tentatives" + (last!=null && last.getMessage()!=null ? " : "+last.getMessage() : ""));
        }
        void close(){try{if(gatt!=null){gatt.disconnect();gatt.close();}}catch(Exception ignored){}}
    }

    private Sc03BlePrinter() {}
}
