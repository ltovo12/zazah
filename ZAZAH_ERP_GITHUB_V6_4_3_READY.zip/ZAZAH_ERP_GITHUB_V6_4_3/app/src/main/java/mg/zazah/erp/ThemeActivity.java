package mg.zazah.erp;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ThemeActivity extends AppCompatActivity {
    private TextView activeOdoo, activeHercule, activeAurora, activeGraphite;

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b); SystemUiHelper.install(this);
        setContentView(R.layout.activity_theme);
        UiTheme3D.apply(this);

        activeOdoo = findViewById(R.id.activeOdoo);
        activeHercule = findViewById(R.id.activeHercule);
        activeAurora = findViewById(R.id.activeAurora);
        activeGraphite = findViewById(R.id.activeGraphite);

        paintPreview(R.id.previewOdoo, "ODOO");
        paintPreview(R.id.previewHercule, "HERCULE");
        paintPreview(R.id.previewAurora, "AURORA");
        paintPreview(R.id.previewGraphite, "GRAPHITE");

        findViewById(R.id.cardThemeOdoo).setOnClickListener(v -> choose("ODOO"));
        findViewById(R.id.cardThemeHercule).setOnClickListener(v -> choose("HERCULE"));
        findViewById(R.id.cardThemeAurora).setOnClickListener(v -> choose("AURORA"));
        findViewById(R.id.cardThemeGraphite).setOnClickListener(v -> choose("GRAPHITE"));
        findViewById(R.id.btnThemeBack).setOnClickListener(v -> finish());
        refreshActive();
    }

    private void choose(String key) {
        if (key.equals(AppPrefs.uiTheme(this))) return;
        AppPrefs.setUiTheme(this, key);
        Toast.makeText(this, "Thème " + AppPrefs.uiThemeLabel(this) + " activé", Toast.LENGTH_SHORT).show();
        recreate();
    }

    private void refreshActive() {
        String k = AppPrefs.uiTheme(this);
        activeOdoo.setText("ODOO".equals(k) ? "ACTIF" : "Toucher pour activer");
        activeHercule.setText("HERCULE".equals(k) ? "ACTIF" : "Toucher pour activer");
        activeAurora.setText("AURORA".equals(k) ? "ACTIF" : "Toucher pour activer");
        activeGraphite.setText("GRAPHITE".equals(k) ? "ACTIF" : "Toucher pour activer");
    }

    private void paintPreview(int id, String key) {
        View v = findViewById(id);
        int c;
        switch (key) {
            case "HERCULE": c = Color.rgb(26,76,92); break;
            case "AURORA": c = Color.rgb(79,70,229); break;
            case "GRAPHITE": c = Color.rgb(31,41,55); break;
            default: c = Color.rgb(113,75,103); break;
        }
        v.setBackgroundColor(c);
    }
}
