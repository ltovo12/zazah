package mg.zazah.erp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;

public class PackActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText search;
    private ListView list;
    private TextView summary;
    private final ArrayList<PackRow> packs = new ArrayList<>();
    private EditText pendingImageField;
    private ActivityResultLauncher<String> imagePicker;

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_packs);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        imagePicker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null && pendingImageField != null) pendingImageField.setText(uri.toString());
            pendingImageField = null;
        });

        search = findViewById(R.id.inputPackSearch);
        list = findViewById(R.id.listPacks);
        summary = findViewById(R.id.txtPackSummary);

        findViewById(R.id.btnNewPack).setOnClickListener(v -> showPackForm(null));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { refresh(); }
            public void afterTextChanged(Editable e) {}
        });
        list.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < packs.size()) showPackEditor(packs.get(pos).id);
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < packs.size()) confirmDeletePack(packs.get(pos));
            return true;
        });
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        packs.clear();
        ArrayList<TwoLineAdapter.Item> rows = new ArrayList<>();
        Cursor c = db.packs(search == null ? "" : search.getText().toString());
        int total = 0, linked = 0;
        while (c.moveToNext()) {
            PackRow r = new PackRow();
            r.id = c.getLong(0); r.name = c.getString(1); r.price = c.getDouble(2); r.description = c.getString(3);
            r.active = c.getInt(4) != 0; r.itemCount = c.getInt(5); r.linkedCount = c.getInt(6); r.detailTotal = c.getDouble(7);
            r.slogan = c.getString(8); r.category = c.getString(9); r.imagePath = c.getString(10); r.logoPath = c.getString(11); r.whatsappNumber = c.getString(12);
            packs.add(r); total += r.itemCount; linked += r.linkedCount;
            String state = r.active ? "Actif" : "Inactif";
            String sub = money(r.price) + " Ar  •  " + r.itemCount + " article(s)  •  " + r.linkedCount + " lié(s) au stock  •  " + state;
            rows.add(new TwoLineAdapter.Item(r.name, sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, rows));
        summary.setText(packs.size() + " pack(s)  •  " + total + " article(s)  •  " + linked + " lié(s) au stock");
    }

    private void showPackForm(PackRow old) {
        LinearLayout box = dialogBox(old == null ? "Nouveau pack" : "Modifier le pack",
                "Le prix du pack reste modifiable. Le détail peut évoluer au fur et à mesure.");
        EditText name = input("Nom du pack", old == null ? "" : old.name, false);
        EditText price = input("Prix de vente du pack (Ar)", old == null ? "" : plain(old.price), true);
        EditText slogan = input("Slogan pour l'image", old == null ? "" : old.slogan, false);
        EditText category = input("Catégorie", old == null ? "Nouveau-né" : old.category, false);
        EditText whatsapp = input("Numéro WhatsApp", old == null ? "" : safe(old.whatsappNumber), false);
        EditText imagePath = input("Image du pack (galerie)", old == null ? "" : safe(old.imagePath), false);
        EditText logoPath = input("Logo (galerie)", old == null ? "" : safe(old.logoPath), false);
        EditText desc = input("Description / note", old == null ? "" : old.description, false);
        desc.setSingleLine(false); desc.setMinLines(2); desc.setMaxLines(4);
        CheckBox active = new CheckBox(this); active.setText("Pack actif et visible dans le POS"); active.setChecked(old == null || old.active);
        LinearLayout imgActions = new LinearLayout(this); imgActions.setOrientation(LinearLayout.HORIZONTAL);
        Button pickImage = smallButton("Choisir image");
        Button pickLogo = smallButton("Choisir logo");
        imgActions.addView(pickImage, weighted()); imgActions.addView(pickLogo, weighted());
        pickImage.setOnClickListener(v -> chooseImage(imagePath));
        pickLogo.setOnClickListener(v -> chooseImage(logoPath));
        box.addView(label("Nom")); box.addView(name); box.addView(label("Prix pack")); box.addView(price);
        box.addView(label("Slogan marketing")); box.addView(slogan); box.addView(label("Catégorie")); box.addView(category);
        box.addView(label("WhatsApp")); box.addView(whatsapp); box.addView(label("Image marketing")); box.addView(imagePath); box.addView(label("Logo")); box.addView(logoPath); box.addView(imgActions);
        box.addView(label("Description")); box.addView(desc); box.addView(active);

        AlertDialog d = new DialogUi.Builder(this)
                .setView(wrap(box))
                .setPositiveButton("Enregistrer", (x, w) -> {
                    try {
                        if (old == null) {
                            long id = db.createPack(name.getText().toString(), num(price), slogan.getText().toString(), category.getText().toString(), desc.getText().toString(), imagePath.getText().toString(), logoPath.getText().toString(), whatsapp.getText().toString(), active.isChecked());
                            refresh();
                            showPackEditor(id);
                        } else {
                            db.updatePack(old.id, name.getText().toString(), num(price), slogan.getText().toString(), category.getText().toString(), desc.getText().toString(), imagePath.getText().toString(), logoPath.getText().toString(), whatsapp.getText().toString(), active.isChecked());
                            refresh();
                        }
                    } catch (Exception ex) { Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show(); }
                })
                .setNegativeButton("Annuler", null).create();
        d.show();
    }

    private void showPackEditor(long packId) {
        try {
            JSONObject h = db.packHeader(packId);
            String name = h.optString("nom", "Pack");
            double price = h.optDouble("prix_vente", 0);
            int itemCount = h.optInt("item_count", 0);
            int linkedCount = h.optInt("linked_count", 0);
            double detailTotal = h.optDouble("detail_total", 0);

            LinearLayout box = dialogBox(name,
                    "Prix pack : " + money(price) + " Ar  •  Détail : " + money(detailTotal) + " Ar\n" +
                            linkedCount + "/" + itemCount + " article(s) relié(s) au stock.");

            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button editPack = smallButton("Modifier pack");
            Button addItem = smallButton("+ Article multi-produits");
            actions.addView(editPack, weighted()); actions.addView(addItem, weighted());
            box.addView(actions);

            LinearLayout imageActions = new LinearLayout(this); imageActions.setOrientation(LinearLayout.HORIZONTAL);
            Button poster = smallButton("🖼 Affiche");
            Button square = smallButton("□ WhatsApp");
            Button mini = smallButton("▤ Mini fiche");
            imageActions.addView(poster, weighted()); imageActions.addView(square, weighted()); imageActions.addView(mini, weighted());
            box.addView(imageActions);

            LinkedHashMap<String, ArticleGroup> grouped = new LinkedHashMap<>();
            Cursor c = db.packArticles(packId);
            while (c.moveToNext()) {
                ItemRow it = new ItemRow();
                it.id = c.getLong(0); it.packId = c.getLong(1); it.variantId = c.getLong(2); it.name = c.getString(3);
                it.qty = c.getDouble(4); it.price = c.getDouble(5); it.product = c.getString(6); it.color = c.getString(7);
                it.size = c.getString(8); it.code = c.getString(9); it.groupCode = c.getString(10);
                String key = safeText(it.groupCode).trim();
                if (key.isEmpty()) key = "A" + it.id;
                ArticleGroup g = grouped.get(key);
                if (g == null) {
                    g = new ArticleGroup(); g.code = key; g.name = it.name; g.qty = it.qty; g.freePrice = it.price;
                    grouped.put(key, g);
                }
                g.rows.add(it);
                if (it.variantId > 0) g.linkedCount++;
                g.detailTotal += Math.max(0, it.price) * Math.max(.5, it.qty);
            }
            c.close();

            final ArrayList<ArticleGroup> groups = new ArrayList<>(grouped.values());
            ArrayList<TwoLineAdapter.Item> labels = new ArrayList<>();
            for (ArticleGroup g : groups) {
                ArrayList<String> names = new ArrayList<>();
                for (ItemRow it : g.rows) {
                    if (it.variantId > 0) {
                        String d = it.product == null || it.product.trim().isEmpty() ? it.name : it.product;
                        if (it.color != null && !it.color.trim().isEmpty()) d += " " + it.color.trim();
                        if (it.size != null && !it.size.trim().isEmpty()) d += " T." + it.size.trim();
                        d += " (" + qty(it.qty) + ")";
                        names.add(d);
                    }
                }
                String products;
                if (names.isEmpty()) products = "⚠ Article libre / non lié";
                else {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < names.size() && i < 3; i++) {
                        if (i > 0) sb.append("  +  ");
                        sb.append(names.get(i));
                    }
                    if (names.size() > 3) sb.append("  + ").append(names.size() - 3).append(" autre(s)");
                    products = "✓ " + names.size() + " produit(s) : " + sb;
                }
                labels.add(new TwoLineAdapter.Item(g.name,
                        products + "  •  détail " + money(g.detailTotal) + " Ar"));
            }

            ListView lv = new ListView(this); lv.setDividerHeight(0); lv.setAdapter(new TwoLineAdapter(this, labels));
            box.addView(lv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(Math.min(440, Math.max(190, groups.size() * 78)))));

            TextView note = new TextView(this);
            note.setText("Un article peut maintenant contenir plusieurs produits. Touchez un article pour modifier sa sélection. Appui long pour supprimer tout le groupe.");
            note.setTextSize(11); note.setTextColor(0xFFCBD5E1); note.setPadding(0, dp(8), 0, 0); box.addView(note);

            AlertDialog dialog = new DialogUi.Builder(this).setView(wrap(box)).setNegativeButton("Fermer", null).create();
            editPack.setOnClickListener(v -> {
                dialog.dismiss();
                PackRow r = findPack(packId);
                if (r != null) showPackForm(r);
            });
            addItem.setOnClickListener(v -> { dialog.dismiss(); showItemForm(packId, null); });
            poster.setOnClickListener(v -> showPackImage(packId, PackImageGenerator.Format.POSTER));
            square.setOnClickListener(v -> showPackImage(packId, PackImageGenerator.Format.SQUARE));
            mini.setOnClickListener(v -> showPackImage(packId, PackImageGenerator.Format.MINI));
            lv.setOnItemClickListener((p, v, pos, id) -> {
                if (pos >= 0 && pos < groups.size()) { dialog.dismiss(); showItemForm(packId, groups.get(pos)); }
            });
            lv.setOnItemLongClickListener((p, v, pos, id) -> {
                if (pos >= 0 && pos < groups.size()) {
                    ArticleGroup g = groups.get(pos);
                    new DialogUi.Builder(this).setTitle("Supprimer l'article ?")
                            .setMessage(g.name + "\n" + g.rows.size() + " produit(s) seront retirés du pack.")
                            .setPositiveButton("Supprimer", (a, b) -> {
                                db.deletePackArticleGroup(packId, g.code); dialog.dismiss(); refresh(); showPackEditor(packId);
                            }).setNegativeButton("Annuler", null).show();
                }
                return true;
            });
            dialog.show();
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showItemForm(long packId, ArticleGroup old) {
        final LinkedHashMap<Long, VariantRow> selected = new LinkedHashMap<>();
        if (old != null) {
            for (ItemRow it : old.rows) {
                if (it.variantId <= 0) continue;
                VariantRow r = new VariantRow();
                r.id = it.variantId; r.product = it.product; r.color = it.color; r.size = it.size; r.code = it.code; r.price = it.price; r.qty = it.qty;
                selected.put(r.id, r);
            }
        }

        LinearLayout box = dialogBox(old == null ? "Nouvel article multi-produits" : "Modifier l'article",
                "Vous pouvez sélectionner plusieurs produits/variantes dans le même article. Le POS déduira chaque produit séparément du stock.");

        EditText name = input("Nom de l'article / groupe", old == null ? "" : old.name, false);
        EditText freeQty = input("Quantité article libre", old == null ? "1" : plain(old.qty), true);
        EditText freePrice = input("Prix détail si article libre (Ar)", old == null ? "" : plain(old.freePrice), true);

        TextView selection = new TextView(this);
        selection.setTextSize(12); selection.setTextColor(0xFFF1F5F9); selection.setPadding(dp(10), dp(9), dp(10), dp(9));
        selection.setBackgroundResource(R.drawable.bg_dialog_input_lux);

        LinearLayout qtyBox = new LinearLayout(this);
        qtyBox.setOrientation(LinearLayout.VERTICAL);

        Runnable renderSelection = () -> {
            if (selected.isEmpty()) {
                selection.setText("⚠ Article libre : aucun produit lié au stock");
                return;
            }
            StringBuilder sb = new StringBuilder("✓ ").append(selected.size()).append(" produit(s) sélectionné(s)\n");
            int i = 0;
            for (VariantRow r : selected.values()) {
                if (i++ > 0) sb.append("\n");
                sb.append("◉ ").append(r.designation()).append(" (").append(qty(r.qty <= 0 ? 1 : r.qty)).append(")");
                if (r.price > 0) sb.append(" — ").append(money(r.price)).append(" Ar");
            }
            selection.setText(sb.toString());
        };
        final Runnable[] renderQtyBox = new Runnable[1];
        renderQtyBox[0] = () -> {
            qtyBox.removeAllViews();
            if (selected.isEmpty()) {
                TextView t = new TextView(this);
                t.setText("Aucun sous-produit sélectionné. La quantité ci-dessous sera utilisée seulement pour un article libre.");
                t.setTextSize(11); t.setTextColor(0xFFCBD5E1); t.setPadding(0, dp(4), 0, dp(4));
                qtyBox.addView(t);
                return;
            }
            for (VariantRow r : selected.values()) {
                TextView l = label("Qté : " + r.designation());
                EditText e = input("Quantité", plain(r.qty <= 0 ? 1 : r.qty), true);
                e.addTextChangedListener(new android.text.TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                    @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
                    @Override public void afterTextChanged(android.text.Editable ed) {
                        try {
                            double q = Double.parseDouble(String.valueOf(ed).trim().replace(',', '.'));
                            r.qty = q >= 0.5 ? q : 1;
                        } catch (Exception ex) {
                            r.qty = 1;
                        }
                        renderSelection.run();
                    }
                });
                qtyBox.addView(l);
                qtyBox.addView(e);
            }
        };
        renderSelection.run();
        renderQtyBox[0].run();

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button choose = smallButton("☑ Choisir plusieurs produits");
        Button clear = smallButton("Article libre");
        actions.addView(choose, weighted()); actions.addView(clear, weighted());
        choose.setOnClickListener(v -> showVariantMultiPicker(selected, picked -> {
            LinkedHashMap<Long, VariantRow> merged = new LinkedHashMap<>();
            for (VariantRow r : picked.values()) {
                VariantRow ex = selected.get(r.id);
                if (ex != null && ex.qty >= 0.5) r.qty = ex.qty;
                else if (r.qty < 0.5) r.qty = 1;
                merged.put(r.id, r);
            }
            selected.clear();
            selected.putAll(merged);
            renderSelection.run();
            renderQtyBox[0].run();
            if ((name.getText().toString().trim().isEmpty()) && selected.size() == 1) {
                name.setText(selected.values().iterator().next().product);
            }
        }));
        clear.setOnClickListener(v -> {
            selected.clear();
            renderSelection.run();
            renderQtyBox[0].run();
        });

        box.addView(label("Nom de l'article")); box.addView(name);
        box.addView(label("Produits inclus")); box.addView(selection); box.addView(actions);
        box.addView(label("Quantité de chaque sous-produit")); box.addView(qtyBox);
        box.addView(label("Quantité si article libre")); box.addView(freeQty);
        box.addView(label("Prix si article libre")); box.addView(freePrice);

        TextView help = new TextView(this);
        help.setText("Pour un article avec plusieurs produits, vous pouvez régler la quantité de chaque sous-produit séparément. Le prix détail de chaque composant reprend automatiquement son prix catalogue. Le prix final vendu reste le prix du pack.");
        help.setTextSize(11); help.setTextColor(0xFFCBD5E1); help.setPadding(0, dp(6), 0, 0); box.addView(help);

        AlertDialog d = new DialogUi.Builder(this).setView(wrap(box))
                .setPositiveButton("Enregistrer", (a, b) -> {
                    try {
                        ArrayList<Long> ids = new ArrayList<>(selected.keySet());
                        LinkedHashMap<Long, Double> qtyByVariant = new LinkedHashMap<>();
                        for (VariantRow r : selected.values()) qtyByVariant.put(r.id, r.qty >= 0.5 ? r.qty : 1d);
                        db.savePackArticleGroup(packId, old == null ? "" : old.code,
                                name.getText().toString(), ids, qtyByVariant, num(freeQty), num(freePrice));
                        Toast.makeText(this,
                                selected.isEmpty() ? "Article libre enregistré" : selected.size() + " produit(s) enregistrés dans le même article",
                                Toast.LENGTH_SHORT).show();
                        refresh(); showPackEditor(packId);
                    } catch (Exception ex) {
                        Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Annuler", null).create();
        d.show();
    }

    private void showVariantMultiPicker(LinkedHashMap<Long, VariantRow> current, OnVariantsPicked callback) {
        LinearLayout box = dialogBox("Produits de l'article",
                "Recherchez puis cochez un ou plusieurs produits. Le stock affiché est uniquement celui de Tsena. Les produits à stock 0 à Tsena restent visibles.");
        EditText q = input("Produit, couleur, taille ou code-barres", "", false);
        TextView count = new TextView(this);
        count.setTextSize(12);
        count.setTextColor(0xFFF1F5F9);
        count.setTypeface(null, android.graphics.Typeface.BOLD);
        count.setPadding(dp(4), dp(7), dp(4), dp(7));

        ListView lv = new ListView(this);
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        lv.setDivider(new ColorDrawable(0x33475569));
        lv.setDividerHeight(dp(1));
        lv.setBackgroundResource(R.drawable.bg_dialog_choice_lux);
        lv.setPadding(dp(4), dp(4), dp(4), dp(4));
        lv.setClipToPadding(false);

        int screenH = getResources().getDisplayMetrics().heightPixels;
        int listH = Math.min(dp(390), Math.max(dp(250), Math.round(screenH * 0.43f)));
        box.addView(q); box.addView(count);
        box.addView(lv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, listH));

        final LinkedHashMap<Long, VariantRow> working = new LinkedHashMap<>(current);
        final ArrayList<VariantRow> visible = new ArrayList<>();
        final AlertDialog[] holder = new AlertDialog[1];

        Runnable load = () -> {
            visible.clear(); ArrayList<String> labels = new ArrayList<>();
            Cursor c = db.searchPackVariants(q.getText().toString(), 150);
            while (c.moveToNext()) {
                VariantRow r = new VariantRow();
                r.id = c.getLong(0); r.product = c.getString(1); r.color = c.getString(2); r.size = c.getString(3); r.code = c.getString(4); r.price = c.getDouble(5); r.stock = c.getDouble(6);
                VariantRow cur = working.get(r.id); r.qty = cur != null && cur.qty >= 0.5 ? cur.qty : 1;
                visible.add(r);
                labels.add(r.designation() + "\n" + money(r.price) + " Ar  •  stock Tsena " + qty(r.stock));
            }
            c.close();
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, labels) {
                @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                    View row = super.getView(position, convertView, parent);
                    CheckedTextView text = row.findViewById(android.R.id.text1);
                    if (text != null) {
                        text.setTextColor(0xFFF8FAFC);
                        text.setTextSize(16);
                        text.setTypeface(null, android.graphics.Typeface.BOLD);
                        text.setGravity(android.view.Gravity.CENTER_VERTICAL);
                        text.setMinHeight(dp(62));
                        text.setPadding(dp(14), dp(8), dp(12), dp(8));

                        int[][] states = new int[][] {
                                new int[] { android.R.attr.state_checked },
                                new int[] {}
                        };
                        int[] colors = new int[] { 0xFF60A5FA, 0xFFE2E8F0 };
                        text.setCheckMarkTintList(new ColorStateList(states, colors));
                    }
                    row.setBackgroundColor(0x00000000);
                    return row;
                }
            };
            lv.setAdapter(adapter);
            for (int i = 0; i < visible.size(); i++) lv.setItemChecked(i, working.containsKey(visible.get(i).id));
            count.setText(visible.isEmpty() ? "Aucun produit trouvé." : visible.size() + " résultat(s) • " + working.size() + " sélectionné(s)");
        };

        lv.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < 0 || pos >= visible.size()) return;
            VariantRow r = visible.get(pos);
            if (lv.isItemChecked(pos)) working.put(r.id, r); else working.remove(r.id);
            count.setText(visible.size() + " résultat(s) • " + working.size() + " sélectionné(s)");
        });
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { load.run(); }
            public void afterTextChanged(Editable e) {}
        });

        AlertDialog d = new DialogUi.Builder(this).setView(wrap(box))
                .setPositiveButton("Valider la sélection", null)
                .setNegativeButton("Annuler", null).create();
        holder[0] = d;
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            callback.onPicked(new LinkedHashMap<>(working)); d.dismiss();
        }));
        load.run(); d.show();
    }

    private void chooseImage(EditText target) {
        pendingImageField = target;
        if (imagePicker != null) imagePicker.launch("image/*");
    }

    private String safe(String value) { return value == null ? "" : value; }

    private String safeText(String value) {
        return value == null ? "" : value;
    }

    private void showPackImage(long packId, PackImageGenerator.Format format) {
        try {
            JSONObject h = db.packHeader(packId);
            String packName = h.optString("nom", "Pack Nouveau-né");
            Bitmap bitmap = new PackImageGenerator(this, db).render(packId, format);

            ImageView preview = new ImageView(this);
            preview.setImageBitmap(bitmap);
            preview.setAdjustViewBounds(true);
            preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
            preview.setPadding(dp(6), dp(6), dp(6), dp(6));

            AlertDialog dlg = new DialogUi.Builder(this)
                    .setTitle("Aperçu image — " + imageFormatName(format))
                    .setView(preview)
                    .setPositiveButton("Enregistrer", null)
                    .setNeutralButton("WhatsApp", null)
                    .setNegativeButton("Fermer", null)
                    .create();
            dlg.setOnShowListener(x -> {
                dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                    try {
                        Uri uri = new PackImageGenerator(this, db).save(bitmap, packName, format);
                        Toast.makeText(this, "Image enregistrée dans Pictures/ZAZAH", Toast.LENGTH_LONG).show();
                    } catch (Exception ex) {
                        Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                    try {
                        new PackImageGenerator(this, db).shareWhatsApp(bitmap, packId, packName, format);
                    } catch (Exception ex) {
                        Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            });
            dlg.show();
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String imageFormatName(PackImageGenerator.Format f) {
        if (f == PackImageGenerator.Format.SQUARE) return "Carré WhatsApp / Facebook";
        if (f == PackImageGenerator.Format.MINI) return "Mini fiche";
        return "Affiche marketing";
    }

    private void confirmDeletePack(PackRow r) {
        new DialogUi.Builder(this).setTitle("Supprimer le pack ?")
                .setMessage(r.name + "\nTous les articles de sa composition seront supprimés.")
                .setPositiveButton("Supprimer", (d, w) -> { db.deletePack(r.id); refresh(); })
                .setNegativeButton("Annuler", null).show();
    }

    private PackRow findPack(long id) {
        for (PackRow r : packs) if (r.id == id) return r;
        refresh(); for (PackRow r : packs) if (r.id == id) return r;
        return null;
    }

    private String linkedDetail(ItemRow it) {
        if (it.variantId <= 0 || it.product == null || it.product.trim().isEmpty()) return "";
        String d = "  •  " + it.product;
        if (it.color != null && !it.color.trim().isEmpty()) d += " / " + it.color;
        if (it.size != null && !it.size.trim().isEmpty()) d += " / " + it.size;
        return d;
    }

    private LinearLayout dialogBox(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(14), dp(18), dp(8));
        TextView t = new TextView(this); t.setText(title); t.setTextSize(20); t.setTextColor(0xFFF1F5F9); t.setTypeface(null, android.graphics.Typeface.BOLD); box.addView(t);
        TextView s = new TextView(this); s.setText(subtitle); s.setTextSize(12); s.setTextColor(0xFFCBD5E1); s.setPadding(0, dp(5), 0, dp(12)); box.addView(s);
        return box;
    }

    private View wrap(View v) {
        LinearLayout outer = new LinearLayout(this); outer.setPadding(dp(8), dp(8), dp(8), dp(8)); outer.setBackgroundResource(R.drawable.bg_dialog_surface); outer.addView(v);
        return outer;
    }

    private TextView label(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(0xFFF1F5F9); t.setTypeface(null, android.graphics.Typeface.BOLD); t.setPadding(0, dp(8), 0, dp(4)); return t;
    }

    private EditText input(String hint, String value, boolean number) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value == null ? "" : value); e.setTextSize(14); e.setTextColor(0xFFFFFFFF); e.setHintTextColor(0xFF94A3B8); e.setPadding(dp(12), dp(8), dp(12), dp(8)); e.setBackgroundResource(R.drawable.bg_dialog_input_lux);
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); else e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)); lp.bottomMargin = dp(5); e.setLayoutParams(lp); return e;
    }

    private Button smallButton(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(12); b.setTextColor(0xFFFFFFFF); b.setBackgroundResource(R.drawable.bg_odoo_button); UiTheme3D.hardenButton(b); return b;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(8)); return lp;
    }

    private int dp(int x) { return Math.round(x * getResources().getDisplayMetrics().density); }
    private double num(EditText e) { try { return Double.parseDouble(e.getText().toString().trim().replace(',', '.')); } catch (Exception ex) { return 0; } }
    private String money(double v) { return String.format(Locale.FRANCE, "%,.0f", v).replace('\u00a0', ' '); }
    private String qty(double v) { return Math.abs(v - Math.rint(v)) < 0.00001 ? String.format(Locale.FRANCE, "%.0f", v) : String.format(Locale.FRANCE, "%.1f", v); }
    private String plain(double v) { return Math.abs(v - Math.rint(v)) < 0.00001 ? String.format(Locale.ROOT, "%.0f", v) : String.format(Locale.ROOT, "%.1f", v); }

    interface OnVariantsPicked { void onPicked(LinkedHashMap<Long, VariantRow> rows); }
    static class PackRow { long id; String name, description, slogan, category, imagePath, logoPath, whatsappNumber; double price, detailTotal; boolean active; int itemCount, linkedCount; }
    static class ItemRow { long id, packId, variantId; String name, product, color, size, code, groupCode; double qty, price; }
    static class ArticleGroup { String code, name; double qty, freePrice, detailTotal; int linkedCount; final ArrayList<ItemRow> rows = new ArrayList<>(); }
    static class VariantRow {
        long id; String product, color, size, code; double price, stock, qty;
        String designation() {
            String d = product == null ? "Article" : product;
            ArrayList<String> p = new ArrayList<>();
            if (color != null && !color.trim().isEmpty()) p.add(color.trim());
            if (size != null && !size.trim().isEmpty()) p.add(size.trim());
            if (!p.isEmpty()) d += " (" + String.join(", ", p) + ")";
            return d;
        }
    }
}
