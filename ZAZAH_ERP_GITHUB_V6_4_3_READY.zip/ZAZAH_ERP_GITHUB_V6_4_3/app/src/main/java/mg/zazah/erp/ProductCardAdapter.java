package mg.zazah.erp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ProductCardAdapter extends BaseAdapter {
    public static class Item {
        public String title;
        public String subtitle;
        public String imageUrl;
        public String badge;
        public Item(String title, String subtitle, String imageUrl, String badge) {
            this.title = title;
            this.subtitle = subtitle;
            this.imageUrl = imageUrl;
            this.badge = badge;
        }
    }

    private final Context context;
    private final List<Item> items;
    private final LayoutInflater inflater;

    public ProductCardAdapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
        this.inflater = LayoutInflater.from(context);
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_product_online, parent, false);
            h = new ViewHolder();
            h.image = convertView.findViewById(R.id.rowProductImage);
            h.title = convertView.findViewById(R.id.rowProductTitle);
            h.subtitle = convertView.findViewById(R.id.rowProductSubtitle);
            h.badge = convertView.findViewById(R.id.rowProductBadge);
            convertView.setTag(h);
        } else h = (ViewHolder) convertView.getTag();

        Item item = items.get(position);
        h.title.setText(item.title);
        h.subtitle.setText(item.subtitle);
        h.badge.setText(item.badge == null || item.badge.trim().isEmpty() ? "Voir variantes" : item.badge);
        RemoteImageLoader.loadInto(context, h.image, item.imageUrl, R.drawable.ic_zazah);
        return convertView;
    }

    static class ViewHolder {
        ImageView image;
        TextView title, subtitle, badge;
    }
}
