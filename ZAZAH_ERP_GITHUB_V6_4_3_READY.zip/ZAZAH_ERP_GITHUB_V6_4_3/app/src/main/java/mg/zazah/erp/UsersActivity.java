package mg.zazah.erp;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * V5.25.34 - Utilisateurs Android synchronisés avec les comptes en ligne.
 * Les comptes servent à identifier la personne qui utilise l'ERP hors ligne.
 * Le PIN reste uniquement dans SQLite sous forme SHA-256.
 */
public class UsersActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private ListView list;
    private final ArrayList<DatabaseHelper.AppUser> rows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_users);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        list = findViewById(R.id.listUsers);

        // V5.25.36 : Android/Material peut appliquer une teinte au fond des Button et
        // rendre le texte presque invisible. On force ici le fond + la couleur du texte.
        hardenUsersButtons();

        DatabaseHelper.AppUser current = db.appUser(AppPrefs.sessionUserId(this));
        if (current != null && current.role != 1) {
            Toast.makeText(this,
                    "La gestion des utilisateurs est réservée à l'administrateur.",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        findViewById(R.id.btnAddUser).setOnClickListener(v -> showEditor(null));
        findViewById(R.id.btnConfigurePin).setOnClickListener(v -> showPinUserPicker());
        findViewById(R.id.btnUsersSession).setOnClickListener(v ->
                startActivity(new Intent(this, SessionActivity.class)));
        findViewById(R.id.btnUsersBackMain).setOnClickListener(v -> openMain());
        list.setOnItemClickListener((parent, view, position, id) -> showActions(rows.get(position)));
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void hardenUsersButtons() {
        styleUsersButton(R.id.btnUsersBackMain, R.drawable.bg_odoo_surface,
                Color.rgb(113, 75, 103), "← Menu principal", 12);
        styleUsersButton(R.id.btnUsersSession, R.drawable.bg_odoo_button,
                Color.WHITE, "Session", 14);
        styleUsersButton(R.id.btnConfigurePin, R.drawable.bg_odoo_button,
                Color.WHITE, "Configurer / changer le PIN", 14);
        styleUsersButton(R.id.btnAddUser, R.drawable.bg_odoo_success,
                Color.WHITE, "+ Nouvel utilisateur", 14);
    }

    private void styleUsersButton(int id, int background, int textColor, String text, float textSize) {
        android.widget.Button b = findViewById(id);
        if (b == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setBackgroundTintList(null);
        }
        b.setBackgroundResource(background);
        b.setTextColor(textColor);
        b.setText(text);
        b.setTextSize(textSize);
        b.setAllCaps(false);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
    }

    private void openMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }

    private void load() {
        if (list == null || db == null) return;
        Cursor c = db.appUsers();
        rows.clear();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        long currentId = AppPrefs.sessionUserId(this);
        while (c.moveToNext()) {
            DatabaseHelper.AppUser u = new DatabaseHelper.AppUser();
            u.id = c.getLong(0);
            u.firstname = c.getString(1) == null ? "" : c.getString(1);
            u.lastname = c.getString(2) == null ? "" : c.getString(2);
            u.username = c.getString(3) == null ? "" : c.getString(3);
            u.role = c.getInt(4);
            u.active = c.getInt(5) == 1;
            u.hasPin = c.getInt(6) == 1;
            u.serverId = c.getLong(7);
            u.localOnly = c.getInt(8) == 1;
            rows.add(u);

            String title = u.displayName();
            if (u.id == currentId) title += " • SESSION ACTIVE";
            if (!u.active) title += " • INACTIF";
            String sync = u.serverId > 0 ? " • En ligne #" + u.serverId : " • Local non lié";
            String sub = "@" + u.username + " • " + u.roleLabel()
                    + (u.hasPin ? " • PIN protégé" : " • Sans PIN") + sync;
            items.add(new TwoLineAdapter.Item(title, sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, items));
    }

    private void showActions(DatabaseHelper.AppUser u) {
        ArrayList<String> actions = new ArrayList<>();
        if (u.active) actions.add("Ouvrir une session");
        actions.add("Modifier");
        actions.add(u.hasPin ? "Changer le PIN" : "Définir le PIN");
        if (u.hasPin) actions.add("Supprimer le PIN");
        actions.add(u.active ? "Désactiver" : "Activer");
        actions.add("Supprimer");
        String[] labels = actions.toArray(new String[0]);

        DialogUi.show(new DialogUi.Builder(this)
                .setTitle(u.displayName())
                .setMessage("@" + u.username + " • " + u.roleLabel())
                .setItems(labels, (d, which) -> {
                    String action = labels[which];
                    if ("Ouvrir une session".equals(action)) {
                        Intent i = new Intent(this, SessionActivity.class);
                        i.putExtra("select_user_id", u.id);
                        startActivity(i);
                    } else if ("Modifier".equals(action)) {
                        showEditor(u);
                    } else if ("Définir le PIN".equals(action) || "Changer le PIN".equals(action)) {
                        showPinEditor(u);
                    } else if ("Désactiver".equals(action) || "Activer".equals(action)) {
                        try {
                            if (!u.active && u.id == AppPrefs.sessionUserId(this)) {
                                AppPrefs.clearSession(this);
                            }
                            db.setAppUserActive(u.id, !u.active);
                            if (u.active && u.id == AppPrefs.sessionUserId(this)) {
                                AppPrefs.clearSession(this);
                            }
                            load();
                        } catch (Exception e) {
                            toast(e.getMessage());
                        }
                    } else if ("Supprimer le PIN".equals(action)) {
                        DialogUi.show(new DialogUi.Builder(this)
                                .setTitle("Supprimer le PIN ?")
                                .setMessage("La prochaine ouverture de session de " + u.displayName()
                                        + " ne demandera plus de PIN.")
                                .setPositiveButton("Supprimer le PIN", (dd, ww) -> {
                                    try {
                                        db.clearAppUserPin(u.id);
                                        load();
                                        toast("PIN supprimé.");
                                    } catch (Exception e) {
                                        toast(e.getMessage());
                                    }
                                })
                                .setNegativeButton("Annuler", null));
                    } else if ("Supprimer".equals(action)) {
                        if (u.id == AppPrefs.sessionUserId(this)) {
                            toast("Fermez d'abord la session de cet utilisateur.");
                            return;
                        }
                        DialogUi.show(new DialogUi.Builder(this)
                                .setTitle("Supprimer l'utilisateur ?")
                                .setMessage(u.displayName() + " sera supprimé d'Android et la suppression sera envoyée au serveur lors de la prochaine synchronisation.")
                                .setPositiveButton("Supprimer", (dd, ww) -> {
                                    try {
                                        db.deleteAppUser(u.id);
                                        load();
                                    } catch (Exception e) {
                                        toast(e.getMessage());
                                    }
                                })
                                .setNegativeButton("Annuler", null));
                    }
                }));
    }

    /** Bouton visible : choisir le compte dont on veut définir/changer le PIN. */
    private void showPinUserPicker() {
        if (rows.isEmpty()) {
            toast("Aucun utilisateur disponible.");
            return;
        }
        String[] labels = new String[rows.size()];
        for (int i = 0; i < rows.size(); i++) {
            DatabaseHelper.AppUser u = rows.get(i);
            labels[i] = u.displayName() + " (@" + u.username + ")"
                    + (u.hasPin ? "  •  PIN actif" : "  •  Sans PIN");
        }
        // Ne pas combiner setMessage() + setItems() ici : selon le thème Android,
        // le message peut prendre la place de la liste et aucun utilisateur n'est visible.
        DialogUi.show(new DialogUi.Builder(this)
                .setTitle("Choisir l’utilisateur pour le PIN")
                .setItems(labels, (d, which) -> {
                    if (which >= 0 && which < rows.size()) {
                        showPinEditor(rows.get(which));
                    }
                })
                .setNegativeButton("Annuler", null));
    }

    /** PIN strictement local : aucune synchronisation du secret vers le serveur. */
    private void showPinEditor(DatabaseHelper.AppUser u) {
        if (u == null) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        TextView info = new TextView(this);
        info.setText(u.displayName() + " • @" + u.username + "\n"
                + (u.hasPin ? "PIN actuellement actif. Saisissez le nouveau PIN."
                : "Aucun PIN. Saisissez un PIN pour protéger l'ouverture de session."));
        info.setTextSize(14);
        info.setTextColor(android.graphics.Color.rgb(71, 85, 105));
        info.setPadding(0, 0, 0, dp(12));

        EditText pin = input("Nouveau PIN Android (4 à 8 chiffres)",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        EditText confirm = input("Confirmer le PIN",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);

        box.addView(info);
        box.addView(pin);
        box.addView(confirm);

        AlertDialog dlg = new DialogUi.Builder(this)
                .setTitle(u.hasPin ? "Changer le PIN" : "Définir le PIN")
                .setView(box)
                .setPositiveButton("Activer le PIN", null)
                .setNegativeButton("Annuler", null)
                .create();

        dlg.setOnShowListener(x -> {
            DialogUi.style(dlg);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String p1 = pin.getText().toString().trim();
                String p2 = confirm.getText().toString().trim();
                if (!p1.matches("\\d{4,8}")) {
                    pin.setError("Le PIN doit contenir 4 à 8 chiffres");
                    return;
                }
                if (!p1.equals(p2)) {
                    confirm.setError("Les deux PIN ne correspondent pas");
                    return;
                }
                try {
                    db.setAppUserPin(u.id, p1);
                    dlg.dismiss();
                    load();
                    toast("PIN activé pour " + u.displayName() + ". Il sera demandé à la prochaine ouverture de session.");
                } catch (Exception e) {
                    toast(e.getMessage());
                }
            });
        });
        dlg.show();
        DialogUi.style(dlg);
    }

    private void showEditor(DatabaseHelper.AppUser u) {
        final boolean edit = u != null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), 0);

        EditText first = input("Prénom *", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText last = input("Nom", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText username = input("Nom d'utilisateur *", InputType.TYPE_CLASS_TEXT);
        EditText pin = input(edit ? "Nouveau PIN local (vide = conserver)" : "PIN local 4 à 8 chiffres (optionnel)",
                InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        EditText onlinePassword = input((edit && u.serverId > 0) ? "Nouveau mot de passe EN LIGNE (vide = conserver)" : "Mot de passe EN LIGNE *",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        Spinner role = new Spinner(this);
        role.setBackgroundResource(R.drawable.bg_input);
        ArrayAdapter<String> roleAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Administrateur", "Utilisateur"});
        role.setAdapter(roleAdapter);
        LinearLayout.LayoutParams roleLp = new LinearLayout.LayoutParams(-1, dp(52));
        roleLp.bottomMargin = dp(9);
        role.setLayoutParams(roleLp);

        CheckBox active = new CheckBox(this);
        active.setText("Utilisateur actif");
        active.setChecked(true);

        box.addView(first);
        box.addView(last);
        box.addView(username);
        box.addView(role);
        box.addView(pin);
        box.addView(onlinePassword);
        box.addView(active);

        if (edit) {
            first.setText(u.firstname);
            last.setText(u.lastname);
            username.setText(u.username);
            role.setSelection(u.role == 1 ? 0 : 1);
            active.setChecked(u.active);
        }

        AlertDialog dlg = new DialogUi.Builder(this)
                .setTitle(edit ? "Modifier utilisateur" : "Nouvel utilisateur")
                .setView(box)
                .setPositiveButton("Enregistrer", null)
                .setNegativeButton("Annuler", null)
                .create();

        dlg.setOnShowListener(x -> {
            DialogUi.style(dlg);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String f = first.getText().toString().trim();
                String l = last.getText().toString().trim();
                String un = username.getText().toString().trim();
                String p = pin.getText().toString().trim();
                String webPass = onlinePassword.getText().toString();
                if (f.isEmpty() && l.isEmpty()) {
                    first.setError("Nom obligatoire");
                    return;
                }
                if (un.isEmpty()) {
                    username.setError("Identifiant obligatoire");
                    return;
                }
                if (!p.isEmpty() && !p.matches("\\d{4,8}")) {
                    pin.setError("4 à 8 chiffres");
                    return;
                }
                if ((!edit || u.serverId <= 0) && webPass.trim().length() < 4) {
                    onlinePassword.setError("Minimum 4 caractères pour créer le compte en ligne");
                    return;
                }
                try {
                    int roleValue = role.getSelectedItemPosition() == 0 ? 1 : 2;
                    boolean changePin = !edit || !p.isEmpty();
                    long id = db.saveAppUser(edit ? u.id : 0,
                            f, l, un, roleValue, active.isChecked(), p, changePin, webPass);
                    if (!active.isChecked() && id == AppPrefs.sessionUserId(this)) {
                        AppPrefs.clearSession(this);
                    }
                    dlg.dismiss();
                    load();
                    toast("Utilisateur enregistré. Synchronisez pour envoyer les changements en ligne.");
                } catch (Exception e) {
                    toast(e.getMessage());
                }
            });
        });
        dlg.show();
        DialogUi.style(dlg);
    }

    private EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(9), dp(12), dp(9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.bottomMargin = dp(9);
        e.setLayoutParams(lp);
        return e;
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }

    private void toast(String s) {
        Toast.makeText(this, s == null ? "Erreur" : s, Toast.LENGTH_LONG).show();
    }
}
