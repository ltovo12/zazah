package mg.zazah.erp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Locale;

public class AdvancesActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText startDate, endDate;
    private Spinner employeeFilter, periodFilter;
    private android.widget.TextView periodInfo, totalView;
    private ListView list;
    private final ArrayList<Employee> employees = new ArrayList<>();
    private final ArrayList<AdvanceRow> rows = new ArrayList<>();
    private final ArrayList<PayrollPeriod> periods = new ArrayList<>();
    private final NumberFormat nf = NumberFormat.getNumberInstance(Locale.FRANCE);
    private boolean employeeListenerReady = false;
    private boolean periodListenerReady = false;

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_advances);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);

        startDate = findViewById(R.id.inputAdvanceStart);
        endDate = findViewById(R.id.inputAdvanceEnd);
        employeeFilter = findViewById(R.id.spinAdvanceEmployee);
        periodFilter = findViewById(R.id.spinAdvancePeriod);
        periodInfo = findViewById(R.id.txtAdvancePeriodInfo);
        totalView = findViewById(R.id.txtAdvanceTotal);
        list = findViewById(R.id.listAdvances);

        setCurrentMonthPeriod();
        findViewById(R.id.btnAdvanceShow).setOnClickListener(v -> load());
        findViewById(R.id.btnAddAdvance).setOnClickListener(v -> showAdd());
        list.setOnItemClickListener((p, v, pos, id) -> showActions(rows.get(pos)));

        loadEmployees();
        loadPeriodsForSelectedEmployee(false);
        load();

        periodFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!periodListenerReady) return;
                applySelectedPeriod(true);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        employeeListenerReady = true;
        employeeFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!employeeListenerReady) return;
                loadPeriodsForSelectedEmployee(true);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (db == null) return;
        long keep = currentEmployeeId();
        employeeListenerReady = false;
        loadEmployees(keep);
        loadPeriodsForSelectedEmployee(false);
        load();
        employeeListenerReady = true;
    }

    private void setCurrentMonthPeriod() {
        try {
            String[] p = DatabaseHelper.monthPeriod(DatabaseHelper.currentMonth());
            startDate.setText(p[0]);
            endDate.setText(p[1]);
        } catch (Exception ignored) { }
    }

    private void loadEmployees() { loadEmployees(currentEmployeeId()); }

    private void loadEmployees(long selected) {
        employees.clear();
        employees.add(new Employee(0, "Tous les salariés", 0));
        Cursor c = db.salaries();
        while (c.moveToNext()) {
            long id = c.getLong(0);
            String mat = c.getString(1), name = c.getString(2);
            double days = c.getDouble(8);
            employees.add(new Employee(id, (mat.isEmpty() ? "" : mat + " - ") + name, days));
        }
        c.close();

        ArrayList<String> labels = new ArrayList<>();
        int sel = 0;
        for (int i = 0; i < employees.size(); i++) {
            labels.add(employees.get(i).label);
            if (employees.get(i).id == selected) sel = i;
        }
        employeeFilter.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        employeeFilter.setSelection(sel);
    }

    private long currentEmployeeId() {
        if (employeeFilter == null || employeeFilter.getSelectedItemPosition() < 0 ||
                employeeFilter.getSelectedItemPosition() >= employees.size()) return 0;
        return employees.get(employeeFilter.getSelectedItemPosition()).id;
    }

    /**
     * Charge toutes les périodes de paie du salarié sélectionné.
     * La plus récente est sélectionnée automatiquement, comme dans l'ERP web.
     */
    private void loadPeriodsForSelectedEmployee(boolean reload) {
        periodListenerReady = false;
        periods.clear();

        long employeeId = currentEmployeeId();
        if (employeeId > 0) {
            Cursor c = db.payrollPeriodsForEmployee(employeeId);
            while (c.moveToNext()) {
                String month = c.getString(0);
                String start = c.getString(1);
                String end = c.getString(2);
                if (start == null || start.trim().isEmpty() || end == null || end.trim().isEmpty()) continue;
                periods.add(new PayrollPeriod(month, start, end, formatPeriodLabel(start, end)));
            }
            c.close();
        }

        // Aucun salarié ou aucune paie : période du mois courant en secours.
        if (periods.isEmpty()) {
            try {
                String month = DatabaseHelper.currentMonth();
                String[] p = DatabaseHelper.monthPeriod(month);
                periods.add(new PayrollPeriod(month, p[0], p[1], formatPeriodLabel(p[0], p[1])));
            } catch (Exception ignored) { }
        }

        ArrayList<String> labels = new ArrayList<>();
        for (PayrollPeriod p : periods) labels.add(p.label);
        periodFilter.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        if (!periods.isEmpty()) periodFilter.setSelection(0, false);

        if (employeeId > 0) {
            int realCount = db.payrollPeriodCountForEmployee(employeeId);
            if (realCount > 0) {
                periodInfo.setText(realCount + (realCount > 1 ? " périodes disponibles pour ce salarié" : " période disponible pour ce salarié"));
            } else {
                periodInfo.setText("Aucune période enregistrée • mois courant utilisé");
            }
        } else {
            periodInfo.setText("Sélectionnez un salarié pour afficher ses périodes");
        }

        applySelectedPeriod(false);
        periodListenerReady = true;
        if (reload) load();
    }

    private void applySelectedPeriod(boolean reload) {
        int pos = periodFilter == null ? -1 : periodFilter.getSelectedItemPosition();
        if (pos >= 0 && pos < periods.size()) {
            PayrollPeriod p = periods.get(pos);
            startDate.setText(p.start);
            endDate.setText(p.end);
        } else {
            setCurrentMonthPeriod();
        }
        if (reload) load();
    }

    private String formatPeriodLabel(String start, String end) {
        return formatDateFr(start) + " au " + formatDateFr(end);
    }

    private String formatDateFr(String iso) {
        try {
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            in.setLenient(false);
            Date d = in.parse(iso);
            return new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(d);
        } catch (Exception e) {
            return iso == null ? "" : iso;
        }
    }

    private void load() {
        try {
            Cursor c = db.advancesPeriod(
                    startDate.getText().toString().trim(),
                    endDate.getText().toString().trim(),
                    currentEmployeeId()
            );
            rows.clear();
            double total = 0;
            ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
            while (c.moveToNext()) {
                AdvanceRow r = new AdvanceRow();
                r.id = c.getLong(0);
                r.employeeId = c.getLong(1);
                r.matricule = c.getString(2);
                r.name = c.getString(3);
                r.date = c.getString(4);
                r.amount = c.getDouble(5);
                r.note = c.getString(6);
                total += r.amount;
                rows.add(r);
                items.add(new TwoLineAdapter.Item(
                        (r.matricule.isEmpty() ? "" : r.matricule + " - ") + r.name,
                        "Avance " + nf.format(r.amount) + " Ar • " + r.date +
                                (r.note.isEmpty() ? "" : " • " + r.note)
                ));
            }
            c.close();
            if (totalView != null) totalView.setText(nf.format(total) + " Ar");
            list.setAdapter(new TwoLineAdapter(this, items));
        } catch (Exception e) {
            if (totalView != null) totalView.setText("0 Ar");
            toast(e.getMessage());
        }
    }

    private void showAdd() {
        if (employees.size() <= 1) {
            toast("Ajoutez d'abord un salarié.");
            return;
        }
        LinearLayout box = box();
        Spinner sp = new Spinner(this);
        ArrayList<String> labels = new ArrayList<>();
        for (int i = 1; i < employees.size(); i++) labels.add(employees.get(i).label);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));

        long selectedEmployee = currentEmployeeId();
        if (selectedEmployee > 0) {
            for (int i = 1; i < employees.size(); i++) {
                if (employees.get(i).id == selectedEmployee) {
                    sp.setSelection(i - 1);
                    break;
                }
            }
        }
        box.addView(sp);

        EditText date = input("Date AAAA-MM-JJ", InputType.TYPE_CLASS_DATETIME);
        date.setText(DatabaseHelper.today());
        box.addView(date);
        EditText amount = input("Montant avance (Ar)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(amount);
        EditText note = input("Remarque", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(note);

        AlertDialog dlg = new DialogUi.Builder(this)
                .setTitle("Nouvelle avance")
                .setView(box)
                .setPositiveButton("Enregistrer", null)
                .setNegativeButton("Annuler", null)
                .create();
        dlg.setOnShowListener(x -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                Employee e = employees.get(sp.getSelectedItemPosition() + 1);
                db.addAdvance(e.id, date.getText().toString(), num(amount), note.getText().toString());
                dlg.dismiss();
                if (currentEmployeeId() == 0 || currentEmployeeId() == e.id) load();
                Toast.makeText(this, "Avance enregistrée", Toast.LENGTH_SHORT).show();
            } catch (Exception ex) {
                toast(ex.getMessage());
            }
        }));
        DialogUi.show(dlg);
    }

    private void showActions(AdvanceRow r) {
        DialogUi.show(new DialogUi.Builder(this)
                .setTitle(r.name)
                .setMessage("Avance : " + nf.format(r.amount) + " Ar\nDate : " + r.date + "\n" + r.note)
                .setPositiveButton("Supprimer", (d, w) -> { db.deleteAdvance(r.id); load(); })
                .setNegativeButton("Fermer", null));
    }

    private LinearLayout box() {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(dp(20), dp(12), dp(20), 0);
        return b;
    }

    private EditText input(String h, int t) {
        EditText e = new EditText(this);
        e.setHint(h);
        e.setInputType(t);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(dp(12), dp(9), dp(12), dp(9));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9);
        e.setLayoutParams(lp);
        return e;
    }

    private double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(',', '.')); }
        catch (Exception x) { return 0; }
    }

    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density * v); }
    private void toast(String s) { Toast.makeText(this, s == null ? "Erreur" : s, Toast.LENGTH_LONG).show(); }

    private static class Employee {
        long id; String label; double days;
        Employee(long i, String l, double d) { id = i; label = l; days = d; }
    }

    private static class PayrollPeriod {
        String month, start, end, label;
        PayrollPeriod(String m, String s, String e, String l) { month = m; start = s; end = e; label = l; }
    }

    private static class AdvanceRow {
        long id, employeeId; String matricule, name, date, note; double amount;
    }
}
