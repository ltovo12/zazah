package mg.zazah.erp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class TwoLineAdapter extends BaseAdapter {
    public static class Item {
        public final String title;
        public final String subtitle;
        public Item(String title, String subtitle) {
            this.title = title == null ? "" : title;
            this.subtitle = subtitle == null ? "" : subtitle;
        }
    }

    private final LayoutInflater inflater;
    private final List<Item> items;

    public TwoLineAdapter(Context context, List<Item> items) {
        this.inflater = LayoutInflater.from(context);
        this.items = items == null ? new ArrayList<>() : items;
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) view = inflater.inflate(R.layout.row_card_two_line, parent, false);
        TextView t = view.findViewById(R.id.rowTitle);
        TextView s = view.findViewById(R.id.rowSubtitle);
        Item item = items.get(position);
        t.setText(item.title);
        s.setText(item.subtitle);
        // Important for the luxury popup theme: these rows use a light card.
        // Keep dark text even when DialogUi recursively styles custom dialog content.
        view.setTag("zazah_light_card");
        t.setTag("zazah_keep_colors");
        s.setTag("zazah_keep_colors");
        t.setTextColor(0xFF263247);
        s.setTextColor(0xFF64748B);
        return view;
    }
}
