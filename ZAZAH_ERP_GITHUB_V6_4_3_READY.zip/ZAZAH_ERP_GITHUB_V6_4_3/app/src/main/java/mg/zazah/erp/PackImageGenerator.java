package mg.zazah.erp;

import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;

/**
 * Générateur marketing local/offline.
 * V6.1.4 :
 * - image pack + logo depuis la galerie
 * - numéro WhatsApp dans le visuel et dans le partage
 * - format carré capable d'afficher toute la liste du pack
 */
public final class PackImageGenerator {
    public enum Format {
        POSTER(1080, 1350, "affiche"),
        SQUARE(1080, 1080, "whatsapp"),
        MINI(1200, 800, "mini-fiche");

        final int width;
        final int height;
        final String slug;
        Format(int width, int height, String slug) {
            this.width = width;
            this.height = height;
            this.slug = slug;
        }
    }

    private final Context context;
    private final DatabaseHelper db;

    public PackImageGenerator(Context context, DatabaseHelper db) {
        this.context = context;
        this.db = db;
    }

    public Bitmap render(long packId, Format format) throws Exception {
        JSONObject h = db.packHeader(packId);
        String name = h.optString("nom", "Pack Nouveau-né");
        String slogan = h.optString("slogan", "");
        String category = h.optString("categorie", "Nouveau-né");
        String description = h.optString("description", "");
        String imagePath = h.optString("image_path", "");
        String logoPath = h.optString("logo_path", "");
        String whatsapp = h.optString("whatsapp_number", "");
        double price = h.optDouble("prix_vente", 0);

        LinkedHashMap<String, GroupItem> grouped = new LinkedHashMap<>();
        Cursor c = db.packArticles(packId);
        try {
            while (c.moveToNext()) {
                String code = c.getString(10);
                if (code == null || code.trim().isEmpty()) code = "A" + c.getLong(0);
                GroupItem g = grouped.get(code);
                if (g == null) {
                    g = new GroupItem();
                    g.name = c.getString(3);
                    g.qty = c.getDouble(4);
                    grouped.put(code, g);
                }
                long variantId = c.getLong(2);
                if (variantId > 0) {
                    String product = safe(c.getString(6));
                    String color = safe(c.getString(7));
                    String size = safe(c.getString(8));
                    StringBuilder label = new StringBuilder(product.isEmpty() ? g.name : product);
                    ArrayList<String> bits = new ArrayList<>();
                    if (!color.isEmpty()) bits.add(color);
                    if (!size.isEmpty()) bits.add("T." + size);
                    if (!bits.isEmpty()) label.append(" (").append(String.join(", ", bits)).append(")");
                    ProductLine pl = new ProductLine();
                    pl.label = label.toString();
                    pl.qty = c.getDouble(4);
                    g.products.add(pl);
                }
            }
        } finally { c.close(); }

        int width = format.width;
        int height = format.height;
        if (format == Format.SQUARE) {
            int count = grouped.size();
            if (count > 18) { width = height = 2800; }
            else if (count > 12) { width = height = 2400; }
            else if (count > 8) { width = height = 2000; }
            else if (count > 5) { width = height = 1600; }
        }

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Bitmap hero = loadBitmap(imagePath, format == Format.SQUARE ? Math.round(width * 0.30f) : 420);
        Bitmap logo = loadBitmap(logoPath, 180);
        drawModernPoster(canvas, format, name, slogan, category, description, whatsapp, price, new ArrayList<>(grouped.values()), hero, logo);
        return bitmap;
    }

    public Uri save(Bitmap bitmap, String packName, Format format) throws Exception {
        String safe = slug(packName);
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date());
        String fileName = "ZAZAH_" + safe + "_" + format.slug + "_" + stamp + ".png";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ZAZAH");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Impossible de créer l'image dans la galerie.");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null || !bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    throw new Exception("Impossible d'enregistrer l'image.");
                }
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return uri;
        }

        File dir = new File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "ZAZAH");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Impossible de créer le dossier image.");
        File file = new File(dir, fileName);
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new Exception("Impossible d'enregistrer l'image.");
        }
        return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
    }

    public void share(Bitmap bitmap, String packName, Format format) throws Exception {
        shareInternal(bitmap, 0, packName, format, null);
    }

    public void shareWhatsApp(Bitmap bitmap, long packId, String packName, Format format) throws Exception {
        shareInternal(bitmap, packId, packName, format, "com.whatsapp");
    }

    private void shareInternal(Bitmap bitmap, long packId, String packName, Format format, String preferredPackage) throws Exception {
        File dir = new File(context.getCacheDir(), "shared_pack_images");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Impossible de préparer le partage.");
        File file = new File(dir, slug(packName) + "_" + format.slug + ".png");
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new Exception("Impossible de préparer l'image.");
        }
        Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);

        String caption = packName + " — ZAZAH TSENA SABOTSY";
        if (packId > 0) {
            try {
                JSONObject h = db.packHeader(packId);
                caption = "✨ " + packName + "\n" + money(h.optDouble("prix_vente", 0)) + " Ar";
                String slogan = h.optString("slogan", "").trim();
                String whatsapp = h.optString("whatsapp_number", "").trim();
                if (!slogan.isEmpty()) caption += "\n" + slogan;
                if (!whatsapp.isEmpty()) caption += "\n📱 WhatsApp : " + whatsapp;
                caption += "\n\nZAZAH TSENA SABOTSY";
            } catch (Exception ignored) {}
        }

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_TEXT, caption);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (preferredPackage != null) {
            try {
                intent.setPackage(preferredPackage);
                context.startActivity(intent);
                return;
            } catch (ActivityNotFoundException ex) {
                try {
                    intent.setPackage("com.whatsapp.w4b");
                    context.startActivity(intent);
                    return;
                } catch (ActivityNotFoundException ignored) {
                    intent.setPackage(null);
                }
            }
        }
        context.startActivity(Intent.createChooser(intent, "Partager l'image du pack"));
    }

    private void drawModernPoster(Canvas c, Format format, String name, String slogan, String category,
                                  String description, String whatsapp, double price,
                                  ArrayList<GroupItem> groups, Bitmap hero, Bitmap logo) {
        final float W = c.getWidth(), H = c.getHeight();
        final boolean mini = format == Format.MINI;
        final boolean square = format == Format.SQUARE;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Fond premium prune / doré
        p.setShader(new LinearGradient(0, 0, W, H,
                new int[]{Color.rgb(43, 20, 41), Color.rgb(82, 34, 65), Color.rgb(148, 93, 99)},
                new float[]{0f, .48f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
        p.setColor(Color.argb(34, 255, 255, 255)); c.drawCircle(W * .12f, H * .10f, W * .18f, p);
        p.setColor(Color.argb(48, 247, 213, 140)); c.drawCircle(W * .88f, H * .08f, W * .20f, p);
        p.setColor(Color.argb(22, 255, 255, 255)); c.drawCircle(W * .90f, H * .88f, W * .26f, p);

        float pad = square ? W * .045f : (mini ? 46 : 56);
        float headerH = square ? Math.min(H * .28f, 390f) : (mini ? 230f : 318f);
        float bodyTop = pad + headerH + (square ? 18 : 24);
        float bodyBottomPad = square ? 34 : 40;

        // Carte principale claire pour la liste / contenu
        roundRect(c, pad, bodyTop, W - pad, H - bodyBottomPad, 34, Color.rgb(255, 250, 251));
        strokeRect(c, pad, bodyTop, W - pad, H - bodyBottomPad, 34, Color.argb(45, 112, 60, 78), 2f);

        // En-tête sombre vitrine
        roundRect(c, pad, pad, W - pad, pad + headerH, 38, Color.argb(150, 22, 12, 22));
        strokeRect(c, pad, pad, W - pad, pad + headerH, 38, Color.argb(120, 244, 210, 140), 2.2f);

        float leftX = pad + 28;
        float brandY = pad + 26;
        float logoSize = square ? 60 : 54;
        if (logo != null) {
            drawBitmapCover(c, logo, leftX, brandY, logoSize, logoSize, 14);
            p.setColor(Color.rgb(247, 213, 140));
            p.setTextSize(square ? 28 : 22);
            p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
            c.drawText("ZAZAH TSENA SABOTSY", leftX + logoSize + 16, brandY + 36, p);
        } else {
            p.setColor(Color.rgb(247, 213, 140));
            p.setTextSize(square ? 28 : 22);
            p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
            c.drawText("ZAZAH TSENA SABOTSY", leftX, brandY + 36, p);
        }
        p.setColor(Color.rgb(245, 233, 232));
        p.setTextSize(square ? 17 : 15);
        p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
        c.drawText("Pack prêt à offrir • sélection marketing", leftX, brandY + 72, p);

        float heroW = 0, heroH = 0, heroX = 0, heroY = 0;
        float titleMaxW = W - pad * 2 - 50;
        if (hero != null) {
            heroW = square ? W * .26f : (mini ? 250 : 280);
            heroH = square ? headerH - 56 : headerH - 60;
            heroX = W - pad - heroW - 24;
            heroY = pad + 28;
            drawBitmapCover(c, hero, heroX, heroY, heroW, heroH, 28);
            p.setColor(Color.argb(38, 255, 255, 255));
            c.drawRoundRect(new RectF(heroX, heroY, heroX + heroW, heroY + heroH), 28, 28, p);
            strokeRect(c, heroX, heroY, heroX + heroW, heroY + heroH, 28, Color.argb(100, 255, 255, 255), 1.8f);
            titleMaxW = heroX - leftX - 24;
        }

        p.setColor(Color.WHITE);
        p.setTypeface(android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD));
        p.setTextSize(square ? 46 : (mini ? 38 : 50));
        float titleY = drawWrapped(c, name, leftX, pad + 130, titleMaxW, p, square ? 48 : 52, 3);
        if (!safe(slogan).isEmpty()) {
            p.setColor(Color.rgb(245, 233, 232));
            p.setTextSize(square ? 20 : 18);
            p.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
            titleY = drawWrapped(c, slogan, leftX, titleY + 6, titleMaxW, p, square ? 24 : 24, 2);
        }

        // Chips catégorie et whatsapp
        float chipY = pad + headerH - 56;
        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize(square ? 16 : 14);
        String catTxt = safe(category).isEmpty() ? "Pack" : category;
        float catW = p.measureText(catTxt) + 34;
        roundRect(c, leftX, chipY, leftX + catW, chipY + 34, 17, Color.argb(44, 255, 255, 255));
        p.setColor(Color.rgb(252, 231, 177));
        c.drawText(catTxt, leftX + 17, chipY + 22, p);
        if (!safe(whatsapp).isEmpty()) {
            String wt = "WhatsApp : " + whatsapp;
            float ww = Math.min(titleMaxW - catW - 12, p.measureText(wt) + 34);
            if (ww > 120) {
                float wx = leftX + catW + 12;
                roundRect(c, wx, chipY, wx + ww, chipY + 34, 17, Color.argb(44, 255, 255, 255));
                p.setColor(Color.rgb(252, 231, 177));
                c.drawText(ellipsize(p, wt, ww - 24), wx + 12, chipY + 22, p);
            }
        }

        // Bloc prix premium
        float priceW = square ? 280 : (mini ? 250 : 290);
        float priceH = square ? 92 : (mini ? 88 : 98);
        float priceX = hero != null ? heroX + heroW - priceW : W - pad - priceW - 20;
        float priceY = pad + 24;
        roundRect(c, priceX, priceY, priceX + priceW, priceY + priceH, 28, Color.rgb(247, 213, 140));
        strokeRect(c, priceX, priceY, priceX + priceW, priceY + priceH, 28, Color.argb(40, 112, 60, 78), 1.6f);
        centerText(c, money(price) + " Ar", priceX + priceW / 2f, priceY + 46, square ? 29 : 30, Color.rgb(77, 37, 43), true, p);
        centerText(c, "PRIX DU PACK", priceX + priceW / 2f, priceY + 72, 13, Color.rgb(77, 37, 43), true, p);

        // Titre section contenu
        float sectionY = bodyTop + 42;
        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize(square ? 28 : 24);
        p.setColor(Color.rgb(214, 31, 50));
        c.drawText("Contenu du pack", pad + 24, sectionY, p);
        p.setTypeface(android.graphics.Typeface.DEFAULT);
        p.setTextSize(square ? 15 : 14);
        p.setColor(Color.rgb(120, 93, 103));
        c.drawText(groups.size() + " ligne(s) d'article(s)", pad + 24, sectionY + 24, p);

        // Grille articles plus propre
        float gridTop = sectionY + 42;
        float footerReserve = square ? 88 : 80;
        float gridBottom = H - bodyBottomPad - footerReserve;
        int cols = square ? (groups.size() > 10 ? 3 : 2) : (mini ? 2 : 2);
        int shown = square ? groups.size() : Math.min(groups.size(), mini ? 6 : 10);
        float gap = square ? 16 : 16;
        float cardW = (W - pad * 2 - 48 - gap * (cols - 1)) / cols;
        int rows = Math.max(1, (int) Math.ceil(shown / (double) cols));
        float cardH = (gridBottom - gridTop - gap * Math.max(0, rows - 1)) / rows;
        float minCardH = square ? 150 : (mini ? 150 : 148);
        if (cardH < minCardH) cardH = minCardH;

        for (int i = 0; i < shown; i++) {
            int col = i % cols, row = i / cols;
            float x = pad + 24 + col * (cardW + gap);
            float y = gridTop + row * (cardH + gap);
            GroupItem g = groups.get(i);

            // carte style fiche claire inspirée du modèle
            roundRect(c, x, y + 4, x + cardW, y + 4 + cardH, 22, Color.argb(10, 64, 33, 43));
            roundRect(c, x, y, x + cardW, y + cardH, 22, Color.rgb(255, 247, 248));
            strokeRect(c, x, y, x + cardW, y + cardH, 22, Color.rgb(241, 201, 208), 1.4f);

            // pilule rouge avec index + titre
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            p.setTextSize(square ? 16 : 15);
            String titleLabel = safe(g.name);
            float pillW = Math.min(cardW - 28, Math.max(square ? 190 : 205, p.measureText(titleLabel) + 88));
            roundRect(c, x + 14, y + 14, x + 14 + pillW, y + 46, 16, Color.rgb(216, 31, 50));
            p.setColor(Color.WHITE);
            c.drawText(String.format(Locale.ROOT, "%02d", i + 1), x + 26, y + 35, p);
            float ty = drawWrapped(c, titleLabel, x + 58, y + 35, pillW - 68, p, 18, 1);

            p.setTypeface(android.graphics.Typeface.DEFAULT);
            p.setTextSize(square ? 14 : 13);
            p.setColor(Color.rgb(47, 47, 53));
            float ly = Math.max(y + 68, ty + 8);
            if (g.products.isEmpty()) {
                c.drawText("Article libre", x + 18, ly, p);
                ly += 18;
            } else {
                int maxProducts = square ? 7 : (mini ? 4 : 4);
                for (int j = 0; j < g.products.size() && j < maxProducts; j++) {
                    ProductLine pl = g.products.get(j);
                    p.setColor(Color.rgb(216, 31, 50));
                    c.drawCircle(x + 24, ly - 5, 4, p);
                    p.setColor(Color.rgb(47, 47, 53));
                    String line = ellipsize(p, pl.label + " (" + qty(pl.qty) + ")", cardW - 50);
                    c.drawText(line, x + 36, ly, p);
                    ly += square ? 18 : 18;
                }
                if (g.products.size() > maxProducts) {
                    p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                    p.setColor(Color.rgb(157, 112, 63));
                    c.drawText("+ " + (g.products.size() - maxProducts) + " autre(s)", x + 18, ly, p);
                    p.setTypeface(android.graphics.Typeface.DEFAULT);
                    p.setColor(Color.rgb(113, 88, 99));
                }
            }

        }

        // bas de carte : description / contact / signature
        float footerY = H - bodyBottomPad - 52;
        if (!safe(description).isEmpty() && !mini) {
            p.setTypeface(android.graphics.Typeface.DEFAULT);
            p.setTextSize(13);
            p.setColor(Color.rgb(118, 92, 103));
            drawWrapped(c, description, pad + 24, footerY - 14, W - pad * 2 - 260, p, 17, square ? 2 : 3);
        }

        if (!safe(whatsapp).isEmpty()) {
            String contact = "Contact WhatsApp : " + whatsapp;
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            p.setTextSize(13);
            float cw = Math.min(W * .42f, p.measureText(contact) + 28);
            roundRect(c, W - pad - cw - 24, footerY - 26, W - pad - 24, footerY + 4, 15, Color.rgb(247, 240, 222));
            p.setColor(Color.rgb(108, 72, 50));
            c.drawText(ellipsize(p, contact, cw - 20), W - pad - cw - 10, footerY - 7, p);
        }

        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        p.setTextSize(square ? 17 : 15);
        p.setColor(Color.rgb(90, 46, 63));
        centerText(c, "ZAZAH TSENA SABOTSY • Élégance, qualité, simplicité", W / 2f, H - bodyBottomPad + 4, square ? 17 : 15, Color.rgb(90, 46, 63), true, p);
    }

    private Bitmap loadBitmap(String path, int maxSize) {
        String src = safe(path);
        if (src.isEmpty()) return null;
        try {
            Bitmap bmp = null;
            if (src.startsWith("content://") || src.startsWith("file://")) {
                try (InputStream in = context.getContentResolver().openInputStream(Uri.parse(src))) {
                    if (in != null) bmp = BitmapFactory.decodeStream(in);
                }
            } else {
                File f = new File(src);
                if (f.exists()) bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
            }
            if (bmp == null) return null;
            int w = bmp.getWidth(), h = bmp.getHeight();
            int max = Math.max(w, h);
            if (max > maxSize && maxSize > 0) {
                float ratio = maxSize / (float) max;
                bmp = Bitmap.createScaledBitmap(bmp, Math.max(1, Math.round(w * ratio)), Math.max(1, Math.round(h * ratio)), true);
            }
            return bmp;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static void roundRect(Canvas c, float left, float top, float right, float bottom, float radius, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(color);
        c.drawRoundRect(new RectF(left, top, right, bottom), radius, radius, p);
    }

    private static void strokeRect(Canvas c, float left, float top, float right, float bottom, float radius, int color, float width) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(color); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(width);
        c.drawRoundRect(new RectF(left, top, right, bottom), radius, radius, p);
    }

    private static void drawBitmapCover(Canvas c, Bitmap bmp, float x, float y, float w, float h, float radius) {
        if (bmp == null) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        RectF dst = new RectF(x, y, x + w, y + h);
        c.save();
        android.graphics.Path path = new android.graphics.Path();
        path.addRoundRect(dst, radius, radius, android.graphics.Path.Direction.CW);
        c.clipPath(path);
        float scale = Math.max(w / bmp.getWidth(), h / bmp.getHeight());
        float dw = bmp.getWidth() * scale;
        float dh = bmp.getHeight() * scale;
        float dx = x + (w - dw) / 2f;
        float dy = y + (h - dh) / 2f;
        c.drawBitmap(bmp, null, new RectF(dx, dy, dx + dw, dy + dh), p);
        c.restore();
    }

    private static float drawWrapped(Canvas c, String text, float x, float y, float maxWidth,
                                     Paint p, float lineHeight, int maxLines) {
        if (text == null) return y;
        String[] words = text.trim().split("\\s+");
        String line = "";
        int lines = 0;
        float yy = y;
        for (String word : words) {
            if (word == null || word.isEmpty()) continue;
            String test = line.isEmpty() ? word : line + " " + word;
            if (p.measureText(test) <= maxWidth) line = test;
            else {
                if (!line.isEmpty()) {
                    c.drawText(line, x, yy, p);
                    yy += lineHeight;
                    lines++;
                    if (lines >= maxLines) return yy;
                }
                line = word;
            }
        }
        if (!line.isEmpty() && lines < maxLines) {
            c.drawText(line, x, yy, p);
            yy += lineHeight;
        }
        return yy;
    }

    private static void centerText(Canvas c, String text, float cx, float baseline, float size, int color, boolean bold, Paint p) {
        p.setShader(null); p.setTextSize(size); p.setColor(color);
        p.setTypeface(android.graphics.Typeface.create("sans-serif", bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
        c.drawText(text, cx - p.measureText(text) / 2f, baseline, p);
    }

    private static String ellipsize(Paint p, String text, float maxWidth) {
        if (p.measureText(text) <= maxWidth) return text;
        String suffix = "…";
        String s = text;
        while (s.length() > 2 && p.measureText(s + suffix) > maxWidth) s = s.substring(0, s.length() - 1);
        return s.trim() + suffix;
    }

    private static String money(double v) { return String.format(Locale.FRANCE, "%,.0f", v).replace('\u00a0', ' '); }
    private static String qty(double v) { return Math.abs(v - Math.rint(v)) < .00001 ? String.format(Locale.FRANCE, "%.0f", v) : String.format(Locale.FRANCE, "%.1f", v); }
    private static String safe(String s) { return s == null ? "" : s.trim(); }
    private static String slug(String text) {
        String s = text == null ? "pack" : text.trim().toLowerCase(Locale.ROOT);
        s = s.replaceAll("[^a-z0-9àâäéèêëîïôöùûüç]+", "-");
        s = s.replaceAll("^-+|-+$", "");
        return s.isEmpty() ? "pack" : s;
    }

    private static class GroupItem {
        String name;
        double qty;
        final ArrayList<ProductLine> products = new ArrayList<>();
    }

    private static class ProductLine {
        String label;
        double qty;
    }
}
