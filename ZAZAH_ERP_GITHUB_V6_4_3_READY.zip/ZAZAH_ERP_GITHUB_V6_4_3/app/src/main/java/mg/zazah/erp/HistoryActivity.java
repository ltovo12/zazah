package mg.zazah.erp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText search;
    private ListView list;
    private TextView empty;
    private final ArrayList<SaleRow> rows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_history);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        search = findViewById(R.id.inputHistorySearch);
        list = findViewById(R.id.listHistory);
        empty = findViewById(R.id.txtHistoryEmpty);

        findViewById(R.id.btnHistoryBack).setOnClickListener(v -> finish());
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { load(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < rows.size()) showSale(rows.get(position));
        });
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        if (db == null || list == null) return;
        rows.clear();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        Cursor c = db.salesHistory(search == null ? "" : search.getText().toString(), 300);
        while (c.moveToNext()) {
            SaleRow r = new SaleRow();
            r.id = c.getLong(0);
            r.num = c.getString(1);
            r.date = c.getString(2);
            r.client = c.getString(3);
            r.total = c.getDouble(4);
            r.received = c.getDouble(5);
            r.status = c.getString(6);
            r.mode = c.getString(7);
            r.sync = c.getString(8);
            rows.add(r);

            String title = r.num + "  •  " + money(r.total) + " Ar";
            String subtitle = r.date + "  •  " + r.client + "  •  " + displayStatus(r.status) +
                    "  •  " + ("synced".equalsIgnoreCase(r.sync) ? "Synchronisée" : "Locale");
            items.add(new TwoLineAdapter.Item(title, subtitle));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, items));
        empty.setVisibility(rows.isEmpty() ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    private void showSale(SaleRow r) {
        try {
            JSONObject receipt = db.saleReceipt(r.id);
            JSONArray lines = db.saleLines(r.id);
            StringBuilder message = new StringBuilder();
            message.append(receipt.optString("date_vente", r.date)).append("\n");
            message.append("Client : ").append(r.client).append("\n\n");

            for (int i = 0; i < lines.length(); i++) {
                JSONObject l = lines.getJSONObject(i);
                double q = l.optDouble("quantite", 0);
                double price = l.optDouble("prix", 0);
                double total = l.has("total_ligne") ? l.optDouble("total_ligne", q * price) : q * price;
                message.append(l.optString("designation", "Produit")).append("\n")
                        .append(qty(q)).append(" × ").append(money(price)).append(" = ")
                        .append(money(total)).append(" Ar\n");
            }

            message.append("\nSous-total : ").append(money(receipt.optDouble("sous_total", 0))).append(" Ar");
            message.append("\nRemise : ").append(money(receipt.optDouble("remise", 0))).append(" Ar");
            message.append("\nTVA : ").append(money(receipt.optDouble("montant_tva", 0))).append(" Ar");
            message.append("\nLivraison : ").append(money(receipt.optDouble("frais_livraison", 0))).append(" Ar");
            message.append("\n\nTOTAL : ").append(money(receipt.optDouble("montant_total", 0))).append(" Ar");
            message.append("\nReçu : ").append(money(receipt.optDouble("montant_recu", 0))).append(" Ar");
            message.append("\nMonnaie à rendre : ").append(money(receipt.optDouble("monnaie_rendue", 0))).append(" Ar");
            message.append("\nPaiement : ").append(receipt.optString("mode_paiement", ""));
            message.append("\nStatut : ").append(displayStatus(receipt.optString("statut_paiement", "")));

            AlertDialog detailDialog = new DialogUi.Builder(this)
                    .setTitle(receipt.optString("num_vente", r.num))
                    .setMessage(message.toString())
                    .setPositiveButton("Réimprimer ticket", (d, w) -> printSale(r.id, r.client))
                    .setNegativeButton("Fermer", null)
                    .create();
            detailDialog.show();
            DialogUi.style(detailDialog);
        } catch (Exception e) {
            Toast.makeText(this, "Historique : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void printSale(long saleId, String clientName) {
        try {
            JSONObject receipt = db.saleReceipt(saleId);
            JSONArray lines = db.saleLines(saleId);
            Toast.makeText(this, "Envoi du ticket à l'imprimante…", Toast.LENGTH_SHORT).show();
            BluetoothEscPosPrinter.printSale(this, receipt, lines, clientName,
                    new BluetoothEscPosPrinter.Callback() {
                        @Override public void onSuccess() {
                            runOnUiThread(() -> Toast.makeText(HistoryActivity.this,
                                    "Ticket réimprimé", Toast.LENGTH_SHORT).show());
                        }

                        @Override public void onError(String message) {
                            runOnUiThread(() -> Toast.makeText(HistoryActivity.this,
                                    "Impression : " + message, Toast.LENGTH_LONG).show());
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Impression : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static String displayStatus(String s) {
        if (s == null) return "";
        if (s.equalsIgnoreCase("PAYE") || s.equalsIgnoreCase("PAYÉ")) return "PAYÉ";
        if (s.equalsIgnoreCase("EN_ATTENTE") || s.equalsIgnoreCase("EN ATTENTE")) return "EN ATTENTE";
        return s;
    }

    private static String money(double v) { return String.format(Locale.FRANCE, "%,.0f", v); }
    private static String qty(double v) { return String.format(Locale.FRANCE, "%.1f", v); }

    private static class SaleRow {
        long id;
        String num, date, client, status, mode, sync;
        double total, received;
    }
}
