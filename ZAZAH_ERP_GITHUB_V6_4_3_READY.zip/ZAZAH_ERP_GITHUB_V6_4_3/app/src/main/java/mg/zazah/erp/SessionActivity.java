package mg.zazah.erp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** Fenêtre de session Android locale. */
public class SessionActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private TextView currentTitle, currentInfo;
    private ListView list;
    private final ArrayList<DatabaseHelper.AppUser> rows = new ArrayList<>();
    private long requestedUserId = 0;
    private boolean requestHandled = false;
    private boolean startupMode = false;

    @Override
    protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_session);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        currentTitle = findViewById(R.id.txtSessionCurrent);
        currentInfo = findViewById(R.id.txtSessionInfo);
        list = findViewById(R.id.listSessionUsers);
        requestedUserId = getIntent().getLongExtra("select_user_id", 0);
        startupMode = getIntent().getBooleanExtra("startup_mode", false);

        findViewById(R.id.btnSessionClose).setOnClickListener(v -> closeSession());
        if (startupMode) {
            // Au démarrage, aucun bouton ne doit permettre de contourner le verrouillage.
            findViewById(R.id.btnSessionBackMain).setVisibility(View.GONE);
            findViewById(R.id.btnSessionUsers).setVisibility(View.GONE);
            findViewById(R.id.btnSessionClose).setVisibility(View.GONE);
        }
        findViewById(R.id.btnSessionUsers).setOnClickListener(v -> openUsers());
        findViewById(R.id.btnSessionBackMain).setOnClickListener(v -> openMain());
        list.setOnItemClickListener((p, v, pos, id) -> requestOpen(rows.get(pos)));
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        long currentId = AppPrefs.sessionUserId(this);
        DatabaseHelper.AppUser current = db.appUser(currentId);
        if (current == null || !current.active) {
            if (currentId > 0) AppPrefs.clearSession(this);
            current = null;
        }

        if (current == null) {
            currentTitle.setText("Aucune session ouverte");
            currentInfo.setText("Touchez un utilisateur actif ci-dessous pour ouvrir une session.");
        } else {
            currentTitle.setText("👤 " + current.displayName());
            String started = "";
            long at = AppPrefs.sessionStartedAt(this);
            if (at > 0) {
                started = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(new Date(at));
            }
            currentInfo.setText("@" + current.username + " • " + current.roleLabel()
                    + (started.isEmpty() ? "" : "\nSession ouverte : " + started));
        }

        Cursor c = db.activeAppUsers();
        rows.clear();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        while (c.moveToNext()) {
            DatabaseHelper.AppUser u = new DatabaseHelper.AppUser();
            u.id = c.getLong(0);
            u.firstname = c.getString(1) == null ? "" : c.getString(1);
            u.lastname = c.getString(2) == null ? "" : c.getString(2);
            u.username = c.getString(3) == null ? "" : c.getString(3);
            u.role = c.getInt(4);
            u.active = c.getInt(5) == 1;
            u.hasPin = c.getInt(6) == 1;
            rows.add(u);
            String title = u.displayName() + (u.id == currentId ? " • ACTUEL" : "");
            String sub = "@" + u.username + " • " + u.roleLabel()
                    + (u.hasPin ? " • 🔒 PIN" : " • accès direct");
            items.add(new TwoLineAdapter.Item(title, sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, items));

        if (!requestHandled && requestedUserId > 0) {
            requestHandled = true;
            for (DatabaseHelper.AppUser u : rows) {
                if (u.id == requestedUserId) {
                    requestOpen(u);
                    break;
                }
            }
        }
    }

    private void requestOpen(DatabaseHelper.AppUser u) {
        if (u == null || !u.active) return;
        if (!u.hasPin) {
            openSession(u);
            return;
        }

        /*
         * Version 6 : toutes les ouvertures de session protégées utilisent le
         * même clavier PIN plein écran que le démarrage. On sélectionne
         * l'utilisateur, puis StartupPinActivity vérifie le PIN avant de laisser
         * entrer dans l'ERP. Il n'y a donc plus de bouton « Ouvrir » à valider.
         */
        AppPrefs.openSession(this, u.id);
        Intent i = new Intent(this, StartupPinActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    private void openSession(DatabaseHelper.AppUser u) {
        AppPrefs.openSession(this, u.id);
        Toast.makeText(this, "Session ouverte : " + u.displayName(), Toast.LENGTH_SHORT).show();
        if (startupMode) {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
            return;
        }
        refresh();
    }

    private void closeSession() {
        if (!AppPrefs.hasSession(this)) {
            Toast.makeText(this, "Aucune session ouverte.", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseHelper.AppUser u = db.appUser(AppPrefs.sessionUserId(this));
        String name = u == null ? "utilisateur" : u.displayName();
        DialogUi.show(new DialogUi.Builder(this)
                .setTitle("Fermer la session ?")
                .setMessage("La session de " + name + " sera fermée. Les données SQLite restent enregistrées.")
                .setPositiveButton("Fermer la session", (d, w) -> {
                    AppPrefs.clearSession(this);
                    refresh();
                })
                .setNegativeButton("Annuler", null));
    }

    private void openUsers() {
        DatabaseHelper.AppUser u = db.appUser(AppPrefs.sessionUserId(this));
        if (u != null && u.role != 1) {
            Toast.makeText(this,
                    "La gestion des utilisateurs est réservée à l'administrateur.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(new Intent(this, UsersActivity.class));
    }

    private void openMain() {
        if (startupMode) {
            // En mode démarrage, retour = quitter au lieu de contourner le PIN.
            finish();
            return;
        }
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }
}
