package mg.zazah.erp;

import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b); SystemUiHelper.install(this);
        setContentView(R.layout.activity_about);
        UiTheme3D.apply(this);

        TextView version = findViewById(R.id.txtAboutVersion);
        TextView theme = findViewById(R.id.txtAboutTheme);
        version.setText("Version " + versionName());
        theme.setText("Thème actif : " + AppPrefs.uiThemeLabel(this));
        findViewById(R.id.btnAboutBack).setOnClickListener(v -> finish());
    }

    private String versionName() {
        try {
            PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
            return p.versionName == null ? "6.1" : p.versionName;
        } catch (Exception e) {
            return "5.25.42";
        }
    }
}
