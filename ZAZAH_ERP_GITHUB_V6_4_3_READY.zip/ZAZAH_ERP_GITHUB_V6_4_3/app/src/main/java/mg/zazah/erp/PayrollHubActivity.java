package mg.zazah.erp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PayrollHubActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private TextView txtSummary;

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_payroll_hub);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        txtSummary = findViewById(R.id.txtPayrollSummary);
        findViewById(R.id.btnEmployees).setOnClickListener(v -> startActivity(new Intent(this, EmployeesActivity.class)));
        findViewById(R.id.btnAdvances).setOnClickListener(v -> startActivity(new Intent(this, AdvancesActivity.class)));
        findViewById(R.id.btnPayrolls).setOnClickListener(v -> startActivity(new Intent(this, PayrollActivity.class)));
    }

    @Override protected void onResume() {
        super.onResume();
        txtSummary.setText("Salariés : " + db.salaryEmployeeCount() + "\nPaies " + DatabaseHelper.currentMonth() + " : " + db.payrollCount(DatabaseHelper.currentMonth()));
    }
}
