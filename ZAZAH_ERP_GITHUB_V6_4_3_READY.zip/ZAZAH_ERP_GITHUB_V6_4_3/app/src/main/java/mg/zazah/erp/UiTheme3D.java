package mg.zazah.erp;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Couche visuelle commune ZAZAH.
 * V5.25.41 : 4 thèmes persistants (Odoo, Hercule, Aurora 2026, Graphite 2026).
 */
public final class UiTheme3D {
    private UiTheme3D() {}

    /** À appeler AVANT super.onCreate() pour que les drawables ?attr utilisent le bon thème. */
    public static void installTheme(Activity activity) {
        if (activity == null) return;
        switch (AppPrefs.uiTheme(activity)) {
            case "HERCULE":
                activity.setTheme(R.style.Theme_ZAZAH_Hercule);
                break;
            case "AURORA":
                activity.setTheme(R.style.Theme_ZAZAH_Aurora);
                break;
            case "GRAPHITE":
                activity.setTheme(R.style.Theme_ZAZAH_Graphite);
                break;
            default:
                activity.setTheme(R.style.Theme_ZAZAH_Odoo);
                break;
        }
    }

    public static void apply(Activity activity) {
        if (activity == null) return;

        Window w = activity.getWindow();
        if (w != null) {
            w.setStatusBarColor(statusColor(activity));
        }

        View root = activity.findViewById(android.R.id.content);
        if (root == null) return;

        styleTree(root, activity);

        root.setAlpha(0.0f);
        root.setTranslationY(dp(root, 8));
        root.animate().alpha(1.0f).translationY(0f).setDuration(180).start();
    }

    private static int statusColor(Activity a) {
        switch (AppPrefs.uiTheme(a)) {
            case "HERCULE": return Color.rgb(13, 40, 56);
            case "AURORA": return Color.rgb(49, 46, 129);
            case "GRAPHITE": return Color.rgb(17, 24, 39);
            default: return Color.rgb(47, 36, 58);
        }
    }

    private static int primaryColor(Activity a) {
        switch (AppPrefs.uiTheme(a)) {
            case "HERCULE": return Color.rgb(26, 76, 92);
            case "AURORA": return Color.rgb(79, 70, 229);
            case "GRAPHITE": return Color.rgb(31, 41, 55);
            default: return Color.rgb(113, 75, 103);
        }
    }

    private static int mutedColor(Activity a) {
        switch (AppPrefs.uiTheme(a)) {
            case "HERCULE": return Color.rgb(88, 107, 112);
            case "AURORA": return Color.rgb(92, 99, 122);
            case "GRAPHITE": return Color.rgb(90, 99, 113);
            default: return Color.rgb(120, 110, 120);
        }
    }

    private static void styleTree(View v, Activity activity) {
        if (v == null) return;

        Object rawTag = v.getTag();
        boolean keepColors = rawTag != null && "zazah_keep_colors".equals(String.valueOf(rawTag));

        if (v instanceof Button) {
            hardenButton((Button) v);
        } else if (v instanceof EditText) {
            EditText e = (EditText) v;
            if (!keepColors) {
                e.setTextColor(Color.rgb(36, 29, 39));
                e.setHintTextColor(mutedColor(activity));
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) e.setElevation(dp(v, 2));
        } else if (v instanceof Spinner) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) v.setElevation(dp(v, 2));
        } else if (v instanceof CheckBox) {
            if (!keepColors) ((CheckBox) v).setTextColor(Color.rgb(51, 42, 55));
        } else if (v instanceof TextView) {
            if (!keepColors) themeText((TextView) v, activity);
        }

        if (v instanceof LinearLayout && v.isClickable() && v.getBackground() != null
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            v.setElevation(dp(v, 7));
            v.setTranslationZ(dp(v, 1));
        }

        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) styleTree(vg.getChildAt(i), activity);
        }
    }

    private static void themeText(TextView t, Activity activity) {
        int c = t.getCurrentTextColor();
        int opaque = Color.rgb(Color.red(c), Color.green(c), Color.blue(c));
        // Remplace uniquement les anciennes couleurs d'accent/muted ZAZAH,
        // pas les textes blancs des entêtes ni les couleurs fonctionnelles.
        if (same(opaque, 0xFF714B67) || same(opaque, 0xFF7B5672)
                || same(opaque, 0xFF6F4A69) || same(opaque, 0xFF8C5D7F)) {
            t.setTextColor(primaryColor(activity));
        } else if (same(opaque, 0xFF786E78) || same(opaque, 0xFF7A737C)
                || same(opaque, 0xFF6B6470) || same(opaque, 0xFF64748B)) {
            t.setTextColor(mutedColor(activity));
        }
    }

    private static boolean same(int a, long b) {
        return (a & 0xFFFFFFFFL) == b;
    }

    /**
     * Rend le libellé de tous les boutons lisible sur les différents Android.
     * Les fonds personnalisés ZAZAH ne sont pas recolorés par le backgroundTint système.
     */
    public static void hardenButton(Button b) {
        if (b == null) return;
        b.setAllCaps(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setBackgroundTintList(null);
            b.setElevation(dp(b, 6));
            b.setTranslationZ(dp(b, 1));
        }

        int c = b.getCurrentTextColor();
        int opaque = Color.rgb(Color.red(c), Color.green(c), Color.blue(c));
        b.setTextColor(opaque);
        b.setAlpha(1.0f);

        double lum = (0.2126 * Color.red(opaque) + 0.7152 * Color.green(opaque) + 0.0722 * Color.blue(opaque)) / 255.0;
        int shadow = lum > 0.58 ? Color.argb(120, 0, 0, 0) : Color.argb(110, 255, 255, 255);
        b.setShadowLayer(dp(b, 1), 0f, dp(b, 1), shadow);
    }

    private static int dp(View v, int value) {
        return Math.round(v.getResources().getDisplayMetrics().density * value);
    }
}
