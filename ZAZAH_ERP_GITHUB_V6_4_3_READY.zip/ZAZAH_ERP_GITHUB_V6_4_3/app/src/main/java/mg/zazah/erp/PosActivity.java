package mg.zazah.erp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Build;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Window;
import androidx.activity.OnBackPressedCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class PosActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private Spinner emp, client, payMode, payStatus;
    private EditText search, remise, tva, livraison, received, comment;
    private ListView results, cart;
    private TextView totals, cartCount;
    private Button paymentOptionsButton, saveSaleButton, clearCartButton, holdButton, resumeButton;
    private long currentDraftId = 0;
    private boolean suppressEmpReset = false;
    private boolean exitConfirmed = false;

    private final ArrayList<ProductRow> productRows = new ArrayList<>();
    private final LinkedHashMap<Long, CartItem> cartItems = new LinkedHashMap<>();
    private final ArrayList<Long> empIds = new ArrayList<>(), clientIds = new ArrayList<>();

    private final ActivityResultLauncher<Intent> scanner =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
                if (r.getResultCode() == RESULT_OK && r.getData() != null) {
                    String code = r.getData().getStringExtra("code");
                    if (code != null) {
                        search.setText(code);
                        searchNow(true);
                    }
                }
            });

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        setContentView(R.layout.activity_pos);
        UiTheme3D.apply(this);
        applyStatusBarInset();
        hidePhoneNavigationBar();
        db = new DatabaseHelper(this);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                handlePosBackPressed(this);
            }
        });

        emp = findViewById(R.id.spinnerEmplacement);
        client = findViewById(R.id.spinnerClient);
        payMode = findViewById(R.id.spinnerPaymentMode);
        payStatus = findViewById(R.id.spinnerPaymentStatus);
        search = findViewById(R.id.inputSearch);
        remise = findViewById(R.id.inputRemise);
        tva = findViewById(R.id.inputTva);
        livraison = findViewById(R.id.inputLivraison);
        received = findViewById(R.id.inputReceived);
        comment = findViewById(R.id.inputComment);
        results = findViewById(R.id.listResults);
        cart = findViewById(R.id.listCart);
        totals = findViewById(R.id.txtTotals);
        cartCount = findViewById(R.id.txtCartCount);
        paymentOptionsButton = findViewById(R.id.btnPaymentOptions);
        saveSaleButton = findViewById(R.id.btnSaveSale);
        clearCartButton = findViewById(R.id.btnClearCart);
        holdButton = findViewById(R.id.btnHoldSale);
        resumeButton = findViewById(R.id.btnResumeSale);

        loadSpinners();

        search.addTextChangedListener(simpleWatcher(() -> searchNow(false)));
        remise.addTextChangedListener(simpleWatcher(this::renderCart));
        tva.addTextChangedListener(simpleWatcher(this::renderCart));
        livraison.addTextChangedListener(simpleWatcher(this::renderCart));
        received.addTextChangedListener(simpleWatcher(this::renderCart));

        emp.setOnItemSelectedListener(new SimpleSelected(() -> {
            if (suppressEmpReset) return;
            cartItems.clear();
            currentDraftId = 0;
            clearPaymentFields(false);
            renderCart();
            searchNow(false);
        }));

        results.setOnItemClickListener((p, v, pos, id) -> {
            if (pos >= 0 && pos < productRows.size()) showVariantDialog(productRows.get(pos));
        });
        cart.setOnItemClickListener((p, v, pos, id) -> {
            ArrayList<CartItem> items = new ArrayList<>(cartItems.values());
            if (pos >= 0 && pos < items.size()) editCart(items.get(pos));
        });
        cart.setOnItemLongClickListener((p, v, pos, id) -> {
            ArrayList<CartItem> items = new ArrayList<>(cartItems.values());
            if (pos >= 0 && pos < items.size()) editCart(items.get(pos));
            return true;
        });

        findViewById(R.id.btnScan).setOnClickListener(v -> scanner.launch(new Intent(this, ScannerActivity.class)));
        findViewById(R.id.btnPacks).setOnClickListener(v -> showPacksForSale());
        findViewById(R.id.btnPosHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        paymentOptionsButton.setOnClickListener(v -> showPaymentDialog());
        saveSaleButton.setOnClickListener(v -> confirmSave());
        clearCartButton.setOnClickListener(v -> confirmClearCart());
        holdButton.setOnClickListener(v -> holdCurrentSale());
        resumeButton.setOnClickListener(v -> showDraftsDialog());

        searchNow(false);
        renderCart();
    }

    @Override protected void onResume() {
        super.onResume();
        hidePhoneNavigationBar();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hidePhoneNavigationBar();
    }

    /**
     * Android 15 peut dessiner l'app sous la barre d'etat.
     * On garde la barre d'etat visible et on reserve sa hauteur pour que
     * Historique / Scanner et le titre restent lisibles.
     */
    private void applyStatusBarInset() {
        View root = findViewById(R.id.posRoot);
        if (root == null) return;
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                top = insets.getInsets(WindowInsets.Type.statusBars()).top;
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                top = insets.getSystemWindowInsetTop();
            }
            v.setPadding(0, top, 0, 0);
            return insets;
        });
        root.requestApplyInsets();
    }

    /**
     * POS uniquement : masque la barre de navigation Android en bas.
     * La barre peut etre revelee temporairement par un geste depuis le bord.
     */
    private void hidePhoneNavigationBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void loadSpinners() {
        ArrayList<String> eNames = new ArrayList<>();
        Cursor c = db.emplacements();
        while (c.moveToNext()) {
            empIds.add(c.getLong(0));
            eNames.add(c.getString(1));
        }
        c.close();
        emp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, eNames));
        selectTsenaDefault(emp, eNames);

        loadClientSpinner(0L);

        payMode.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"ESPECES", "MOBILE_MONEY", "CARTE", "VIREMENT"}));
        payStatus.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"EN ATTENTE", "PARTIEL", "PAYÉ"}));
    }

    private void selectTsenaDefault(Spinner spinner, ArrayList<String> names) {
        int tsenaIndex = -1;
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            if (name != null && "tsena".equalsIgnoreCase(name.trim())) {
                tsenaIndex = i;
                break;
            }
        }
        if (tsenaIndex >= 0) spinner.setSelection(tsenaIndex, false);
        else if (spinner.getCount() > 0) spinner.setSelection(0, false);
    }

    private void loadClientSpinner(long selectId) {
        clientIds.clear();
        ArrayList<String> names = new ArrayList<>();
        names.add("Client comptoir");
        clientIds.add(0L);
        Cursor c = db.clients();
        int selected = 0;
        int index = 1;
        while (c.moveToNext()) {
            long id = c.getLong(0);
            clientIds.add(id);
            names.add(c.getString(2));
            if (id == selectId) selected = index;
            index++;
        }
        c.close();
        client.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        if (selected < client.getCount()) client.setSelection(selected);
    }

    private long empId() {
        if (empIds.isEmpty()) return db.defaultEmplacementId();
        int p = emp.getSelectedItemPosition();
        if (p < 0 || p >= empIds.size()) return db.defaultEmplacementId();
        return empIds.get(p);
    }

    private void searchNow(boolean autoAdd) {
        String q = search.getText().toString().trim();

        if (autoAdd) {
            ArrayList<Row> matchedVariants = new ArrayList<>();
            Cursor c = db.searchVariants(q, empId(), 60);
            while (c.moveToNext()) {
                Row r = readVariantRow(c);
                matchedVariants.add(r);
            }
            c.close();

            if (matchedVariants.size() == 1) {
                addVariant(matchedVariants.get(0));
                search.setText("");
                return;
            }
            if (!matchedVariants.isEmpty()) {
                showVariantDialog("Choisir la variante", matchedVariants, true);
                return;
            }
        }

        productRows.clear();
        ArrayList<ProductCardAdapter.Item> cards = new ArrayList<>();
        Cursor c = db.searchProducts(q, empId(), 100);
        while (c.moveToNext()) {
            ProductRow p = new ProductRow();
            p.id = c.getLong(0);
            p.name = c.getString(1);
            p.variantCount = c.getInt(2);
            p.stock = c.getDouble(3);
            p.imageUrl = c.getString(4);
            productRows.add(p);
            String subtitle = p.variantCount + (p.variantCount > 1 ? " variantes" : " variante") + "  •  stock " + qty(p.stock);
            cards.add(new ProductCardAdapter.Item(p.name, subtitle, p.imageUrl, "Variantes"));
        }
        c.close();
        results.setAdapter(new ProductCardAdapter(this, cards));
    }

    private void showPacksForSale() {
        ArrayList<PackSaleRow> packRows = new ArrayList<>();
        ArrayList<TwoLineAdapter.Item> labels = new ArrayList<>();
        Cursor c = db.packs("");
        while (c.moveToNext()) {
            if (c.getInt(4) == 0) continue;
            PackSaleRow p = new PackSaleRow();
            p.id = c.getLong(0); p.name = c.getString(1); p.price = c.getDouble(2);
            p.itemCount = c.getInt(5); p.linkedCount = c.getInt(6);
            packRows.add(p);
            String state = p.itemCount > 0 && p.itemCount == p.linkedCount ? "✓ prêt à vendre" : "⚠ " + (p.itemCount - p.linkedCount) + " à relier au stock";
            labels.add(new TwoLineAdapter.Item(p.name,
                    money(p.price) + " Ar  •  " + p.itemCount + " article(s)  •  " + state));
        }
        c.close();
        if (packRows.isEmpty()) {
            Toast.makeText(this, "Aucun pack actif. Ouvrez Gestion des packs.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, PackActivity.class));
            return;
        }

        LinearLayout box = modernDialogCard("Packs Nouveau-né", "Touchez un pack pour ajouter sa composition au panier.");
        ListView listView = new ListView(this);
        listView.setDividerHeight(0);
        listView.setAdapter(new TwoLineAdapter(this, labels));
        box.addView(listView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(Math.min(420, Math.max(190, packRows.size() * 78)))));
        AlertDialog dialog = new DialogUi.Builder(this)
                .setView(wrapDialog(box))
                .setNeutralButton("Gérer les packs", (d, w) -> startActivity(new Intent(this, PackActivity.class)))
                .setNegativeButton("Fermer", null)
                .create();
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= packRows.size()) return;
            PackSaleRow p = packRows.get(position);
            if (p.itemCount <= 0) {
                Toast.makeText(this, "Ce pack ne contient encore aucun article.", Toast.LENGTH_LONG).show();
                return;
            }
            if (p.linkedCount < p.itemCount) {
                int missing = p.itemCount - p.linkedCount;
                AlertDialog warn = new DialogUi.Builder(this)
                        .setView(wrapDialog(messageDialogContent("Pack à compléter",
                                missing + " article(s) ne sont pas encore liés au catalogue/stock.\n\nPour déduire correctement le stock, liez tous les articles avant la vente.")))
                        .setPositiveButton("Gérer maintenant", (a, b) -> {
                            dialog.dismiss();
                            startActivity(new Intent(this, PackActivity.class));
                        })
                        .setNegativeButton("Annuler", null)
                        .create();
                warn.show(); styleDialog(warn);
                return;
            }
            if (addPackToCart(p)) dialog.dismiss();
        });
        dialog.show(); styleDialog(dialog);
    }

    private boolean addPackToCart(PackSaleRow pack) {
        LinkedHashMap<Long, PackComponent> components = new LinkedHashMap<>();
        int expectedRows = db.packLinkedComponentCount(pack.id);
        int resolvedRows = 0;
        Cursor c = db.packComponents(pack.id, empId());
        while (c.moveToNext()) {
            resolvedRows++;
            long variantId = c.getLong(1);
            double q = DatabaseHelper.roundHalf(c.getDouble(3));
            if (variantId <= 0 || q < 0.5) continue;
            PackComponent add = new PackComponent();
            add.variantId = variantId;
            add.name = c.getString(5);
            add.color = c.getString(6);
            add.size = c.getString(7);
            add.qty = q;
            add.detailPrice = c.getDouble(4);
            add.catalogPrice = c.getDouble(8);
            add.stock = c.getDouble(9);
            PackComponent existing = components.get(variantId);
            if (existing == null) {
                components.put(variantId, add);
            } else {
                double oldWeight = existing.qty * Math.max(0, existing.detailPrice > 0 ? existing.detailPrice : existing.catalogPrice);
                double newWeight = add.qty * Math.max(0, add.detailPrice > 0 ? add.detailPrice : add.catalogPrice);
                existing.qty = DatabaseHelper.roundHalf(existing.qty + add.qty);
                double totalWeightQty = Math.max(0.00001, existing.qty);
                existing.detailPrice = (oldWeight + newWeight) / totalWeightQty;
                existing.catalogPrice = existing.detailPrice;
                existing.stock = Math.min(existing.stock, add.stock);
            }
        }
        c.close();
        if (resolvedRows < expectedRows) {
            Toast.makeText(this, "Certaines liaisons du pack ne correspondent plus au catalogue. Ouvrez Gestion des packs pour les relier à nouveau.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (components.isEmpty()) {
            Toast.makeText(this, "Aucun article du pack n'est lié au stock.", Toast.LENGTH_LONG).show();
            return false;
        }

        for (PackComponent pc : components.values()) {
            CartItem current = cartItems.get(pc.variantId);
            double inCart = current == null ? 0 : current.qty;
            if (inCart + pc.qty > pc.stock + 0.00001) {
                Toast.makeText(this, "Stock insuffisant pour " + pc.designation() + " : disponible " + qty(pc.stock), Toast.LENGTH_LONG).show();
                return false;
            }
        }

        double totalWeight = 0;
        double totalUnits = 0;
        for (PackComponent pc : components.values()) {
            double base = pc.detailPrice > 0 ? pc.detailPrice : pc.catalogPrice;
            totalWeight += Math.max(0, base) * pc.qty;
            totalUnits += pc.qty;
        }
        if (pack.price < 0) pack.price = 0;

        for (PackComponent pc : components.values()) {
            double base = pc.detailPrice > 0 ? pc.detailPrice : pc.catalogPrice;
            double addLineTotal;
            if (totalWeight > 0.00001) addLineTotal = pack.price * (Math.max(0, base) * pc.qty) / totalWeight;
            else addLineTotal = totalUnits > 0 ? pack.price * pc.qty / totalUnits : 0;
            double allocatedUnitPrice = pc.qty > 0 ? addLineTotal / pc.qty : 0;

            CartItem x = cartItems.get(pc.variantId);
            if (x == null) {
                x = new CartItem();
                x.id = pc.variantId;
                x.designation = pack.name + " • " + pc.designation();
                x.qty = pc.qty;
                x.price = allocatedUnitPrice;
                x.stock = pc.stock;
                cartItems.put(pc.variantId, x);
            } else {
                double oldTotal = x.qty * x.price;
                double newQty = DatabaseHelper.roundHalf(x.qty + pc.qty);
                x.price = newQty > 0 ? (oldTotal + addLineTotal) / newQty : x.price;
                x.qty = newQty;
                x.stock = Math.min(x.stock, pc.stock);
            }
        }
        renderCart();
        Toast.makeText(this, pack.name + " ajouté au panier • " + money(pack.price) + " Ar", Toast.LENGTH_LONG).show();
        return true;
    }

    private Row readVariantRow(Cursor c) {
        Row r = new Row();
        r.id = c.getLong(0);
        r.productId = c.getLong(7);
        r.produit = c.getString(1);
        r.couleur = c.getString(2);
        r.taille = c.getString(3);
        r.code = c.getString(4);
        r.price = c.getDouble(5);
        r.stock = c.getDouble(6);
        r.imageUrl = c.getString(8);
        return r;
    }

    private void showVariantDialog(ProductRow product) {
        ArrayList<Row> variants = new ArrayList<>();
        Cursor c = db.variantsByProduct(product.id, empId(), 100);
        while (c.moveToNext()) variants.add(readVariantRow(c));
        c.close();
        if (variants.isEmpty()) {
            Toast.makeText(this, "Aucune variante disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        if ((variants.get(0).imageUrl == null || variants.get(0).imageUrl.trim().isEmpty()) && product.imageUrl != null) {
            for (Row row : variants) if (row.imageUrl == null || row.imageUrl.trim().isEmpty()) row.imageUrl = product.imageUrl;
        }
        showVariantDialog(product.name, variants, false);
    }

    private void showVariantDialog(String title, List<Row> variants, boolean clearSearchAfterAdd) {
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        for (Row r : variants) {
            String top = r.variantLabel();
            String sub = money(r.price) + " Ar  •  stock " + qty(r.stock) + (r.code == null || r.code.isEmpty() ? "" : "  •  " + r.code);
            items.add(new TwoLineAdapter.Item(top, sub));
        }

        LinearLayout box = modernDialogCard(title, variants.size() + (variants.size() > 1 ? " variantes disponibles" : " variante disponible") + " • touchez une ligne pour l’ajouter au panier");

        ImageView image = new ImageView(this);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundResource(R.drawable.bg_odoo_surface);
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170));
        imageLp.bottomMargin = dp(12);
        box.addView(image, imageLp);

        ListView listView = new ListView(this);
        listView.setDividerHeight(0);
        listView.setAdapter(new TwoLineAdapter(this, items));
        box.addView(listView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(Math.min(390, Math.max(170, variants.size() * 82)))));

        String rawPhoto = firstImageUrl(variants);
        if (rawPhoto.isEmpty()) {
            image.setImageResource(R.drawable.ic_zazah);
            image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        } else {
            RemoteImageLoader.loadInto(this, image, rawPhoto, R.drawable.ic_zazah);
        }

        AlertDialog dialog = new DialogUi.Builder(this).setView(wrapDialog(box)).setNegativeButton("Fermer", null).create();
        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < variants.size()) {
                addVariant(variants.get(position));
                dialog.dismiss();
                if (clearSearchAfterAdd) search.setText("");
            }
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void addVariant(Row r) {
        if (r.stock < 0.5) {
            Toast.makeText(this, "Stock insuffisant", Toast.LENGTH_SHORT).show();
            return;
        }
        CartItem x = cartItems.get(r.id);
        if (x == null) {
            x = new CartItem();
            x.id = r.id;
            x.designation = r.designation();
            x.price = r.price;
            x.qty = 0;
            x.stock = r.stock;
            cartItems.put(r.id, x);
        }
        if (x.qty + 0.5 > r.stock + 0.00001) {
            Toast.makeText(this, "Stock maximum atteint", Toast.LENGTH_SHORT).show();
            return;
        }
        x.qty += 1.0;
        if (x.qty > r.stock) x.qty = r.stock;
        x.qty = DatabaseHelper.roundHalf(x.qty);
        renderCart();
    }

    private void editCart(CartItem x) {
        LinearLayout box = modernDialogCard(x.designation, "Modifiez la quantité ou le prix de cet article.");

        TextView qLabel = dialogLabel("Quantité");
        box.addView(qLabel);
        EditText q = dialogInput("Quantité", qty(x.qty), true);
        box.addView(q);

        TextView pLabel = dialogLabel("Prix");
        box.addView(pLabel);
        EditText p = dialogInput("Prix", String.valueOf(x.price), true);
        box.addView(p);

        AlertDialog dialog = new DialogUi.Builder(this)
                .setView(wrapDialog(box))
                .setPositiveButton("Modifier", (d, w) -> {
                    double nq = DatabaseHelper.roundHalf(num(q));
                    double np = Math.max(0, num(p));
                    if (nq < 0.5) cartItems.remove(x.id);
                    else if (nq <= x.stock + 0.00001) { x.qty = nq; x.price = np; }
                    else Toast.makeText(this, "Stock disponible : " + qty(x.stock), Toast.LENGTH_LONG).show();
                    renderCart();
                })
                .setNeutralButton("Supprimer", (d, w) -> { cartItems.remove(x.id); renderCart(); })
                .setNegativeButton("Annuler", null)
                .create();
        dialog.show();
        styleDialog(dialog);
    }

    private void showPaymentDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 18, 40, 0);

        TextView clientLabel = new TextView(this);
        clientLabel.setText("Client");
        clientLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        clientLabel.setTextColor(0xFF714B67);
        clientLabel.setPadding(0, 0, 0, dp(6));
        box.addView(clientLabel);

        LinearLayout clientRow = new LinearLayout(this);
        clientRow.setOrientation(LinearLayout.HORIZONTAL);
        Spinner dlgClient = new Spinner(this);
        dlgClient.setAdapter(copySpinnerAdapter(client));
        dlgClient.setSelection(client.getSelectedItemPosition());
        dlgClient.setBackgroundResource(R.drawable.bg_input);
        dlgClient.setPadding(dp(6), 0, dp(6), 0);
        LinearLayout.LayoutParams clientLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        clientLp.setMarginEnd(dp(6));
        clientRow.addView(dlgClient, clientLp);
        Button newClientButton = new Button(this);
        newClientButton.setText("+ Nouveau");
        newClientButton.setAllCaps(false);
        newClientButton.setTextColor(0xFFFFFFFF);
        newClientButton.setTextSize(12);
        newClientButton.setBackgroundResource(R.drawable.bg_odoo_success);
        UiTheme3D.hardenButton(newClientButton);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(dp(105), dp(48));
        clientRow.addView(newClientButton, btnLp);
        box.addView(clientRow);

        LinearLayout priceOptionsRow = new LinearLayout(this);
        priceOptionsRow.setOrientation(LinearLayout.HORIZONTAL);
        EditText dlgRemise = compactInputField("Remise Ar", remise.getText().toString());
        EditText dlgTva = compactInputField("TVA %", tva.getText().toString());
        EditText dlgLivraison = compactInputField("Livraison Ar", livraison.getText().toString());
        priceOptionsRow.addView(dlgRemise, weightedFieldParams(0, 8));
        priceOptionsRow.addView(dlgTva, weightedFieldParams(4, 4));
        priceOptionsRow.addView(dlgLivraison, weightedFieldParams(8, 0));
        box.addView(priceOptionsRow);

        Spinner dlgMode = new Spinner(this);
        dlgMode.setAdapter(copySpinnerAdapter(payMode));
        dlgMode.setSelection(payMode.getSelectedItemPosition());
        dlgMode.setBackgroundResource(R.drawable.bg_input);
        dlgMode.setPadding(dp(6), 0, dp(6), 0);
        LinearLayout.LayoutParams modeLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        modeLp.bottomMargin = dp(10);
        box.addView(dlgMode, modeLp);

        TotalsCalc paymentTotals = calcTotals();
        String savedReceived = received.getText().toString().trim();
        String initialReceived = savedReceived;
        if (isCashMode(String.valueOf(payMode.getSelectedItem())) && savedReceived.isEmpty()) {
            initialReceived = plainAmount(paymentTotals.total);
        }

        TextView dlgTotal = new TextView(this);
        dlgTotal.setTextSize(17);
        dlgTotal.setTextColor(0xFF0F172A);
        dlgTotal.setTypeface(null, android.graphics.Typeface.BOLD);
        dlgTotal.setPadding(0, dp(12), 0, dp(4));
        box.addView(dlgTotal);

        EditText dlgReceived = inputField("Montant reçu", initialReceived);
        dlgReceived.setEnabled(true);
        box.addView(dlgReceived);

        TextView dlgChange = new TextView(this);
        dlgChange.setTextSize(16);
        dlgChange.setTextColor(0xFF166534);
        dlgChange.setTypeface(null, android.graphics.Typeface.BOLD);
        dlgChange.setBackgroundResource(R.drawable.bg_soft_success);
        dlgChange.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(dlgChange);

        final boolean[] internalReceivedUpdate = {false};
        final boolean[] receivedManuallyEdited = {!savedReceived.isEmpty()};

        Runnable updatePaymentPreview = () -> {
            TotalsCalc preview = calcDialogTotals(dlgRemise, dlgTva, dlgLivraison, dlgReceived);
            dlgTotal.setText("Montant à payer : " + money(preview.total) + " Ar");
            dlgChange.setText("Monnaie à rendre : " + money(preview.change) + " Ar");
        };

        TextWatcher optionWatcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (isCashMode(String.valueOf(dlgMode.getSelectedItem())) && !receivedManuallyEdited[0]) {
                    TotalsCalc preview = calcDialogTotals(dlgRemise, dlgTva, dlgLivraison, dlgReceived);
                    internalReceivedUpdate[0] = true;
                    dlgReceived.setText(plainAmount(preview.total));
                    dlgReceived.setSelection(dlgReceived.getText().length());
                    internalReceivedUpdate[0] = false;
                }
                updatePaymentPreview.run();
            }
            public void afterTextChanged(Editable e) {}
        };
        dlgRemise.addTextChangedListener(optionWatcher);
        dlgTva.addTextChangedListener(optionWatcher);
        dlgLivraison.addTextChangedListener(optionWatcher);
        dlgReceived.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (!internalReceivedUpdate[0]) receivedManuallyEdited[0] = true;
                updatePaymentPreview.run();
            }
            public void afterTextChanged(Editable e) {}
        });

        dlgMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String mode = String.valueOf(dlgMode.getItemAtPosition(position));
                dlgReceived.setEnabled(true);
                if (isCashMode(mode) && (!receivedManuallyEdited[0] || dlgReceived.getText().toString().trim().isEmpty())) {
                    TotalsCalc preview = calcDialogTotals(dlgRemise, dlgTva, dlgLivraison, dlgReceived);
                    internalReceivedUpdate[0] = true;
                    dlgReceived.setText(plainAmount(preview.total));
                    dlgReceived.setSelection(dlgReceived.getText().length());
                    internalReceivedUpdate[0] = false;
                    receivedManuallyEdited[0] = false;
                }
                updatePaymentPreview.run();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        newClientButton.setOnClickListener(v -> showInlineNewClientDialog(newId -> {
            loadClientSpinner(newId);
            dlgClient.setAdapter(copySpinnerAdapter(client));
            dlgClient.setSelection(client.getSelectedItemPosition());
        }));

        updatePaymentPreview.run();

        Spinner dlgStatus = new Spinner(this);
        dlgStatus.setAdapter(copySpinnerAdapter(payStatus));
        dlgStatus.setSelection(payStatus.getSelectedItemPosition());
        dlgStatus.setBackgroundResource(R.drawable.bg_input);
        dlgStatus.setPadding(dp(6), 0, dp(6), 0);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        statusLp.bottomMargin = dp(10);
        box.addView(dlgStatus, statusLp);

        EditText dlgComment = inputField("Commentaire", comment.getText().toString());
        dlgComment.setInputType(InputType.TYPE_CLASS_TEXT);
        box.addView(dlgComment);

        LinearLayout dialogBox = modernDialogCard("Paiement / Options", "Client, remise, TVA, livraison et mode de paiement.");
        dialogBox.addView(box);
        AlertDialog paymentDialog = new DialogUi.Builder(this)
                .setView(wrapDialog(dialogBox))
                .setPositiveButton("Appliquer", (d, w) -> {
                    client.setSelection(dlgClient.getSelectedItemPosition());
                    payMode.setSelection(dlgMode.getSelectedItemPosition());
                    payStatus.setSelection(dlgStatus.getSelectedItemPosition());
                    remise.setText(emptyNumeric(dlgRemise.getText().toString()));
                    tva.setText(emptyNumeric(dlgTva.getText().toString()));
                    livraison.setText(emptyNumeric(dlgLivraison.getText().toString()));
                    // Le montant ESPÈCES reste modifiable : on conserve exactement la saisie utilisateur.
                    received.setText(emptyNumeric(dlgReceived.getText().toString()));
                    comment.setText(dlgComment.getText().toString());
                    renderCart();
                })
                .setNegativeButton("Annuler", null)
                .create();
        paymentDialog.show();
        styleDialog(paymentDialog);
    }

    private void holdCurrentSale() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Panier vide", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            long id = db.saveDraft(currentDraftId, currentHeader(), currentLines());
            currentDraftId = 0;
            cartItems.clear();
            clearPaymentFields(true);
            renderCart();
            searchNow(false);
            Toast.makeText(this, "Vente mise en attente : " + id, Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showDraftsDialog() {
        ArrayList<DraftRow> drafts = new ArrayList<>();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        Cursor c = db.draftHistory();
        while (c.moveToNext()) {
            DraftRow d = new DraftRow();
            d.id = c.getLong(0);
            d.code = c.getString(1);
            d.updatedAt = c.getString(2);
            d.itemCount = c.getInt(3);
            d.amount = c.getDouble(4);
            drafts.add(d);
            items.add(new TwoLineAdapter.Item(d.code, d.updatedAt + "  •  " + d.itemCount + " article(s)  •  " + money(d.amount) + " Ar"));
        }
        c.close();
        if (drafts.isEmpty()) {
            Toast.makeText(this, "Aucune vente en attente", Toast.LENGTH_SHORT).show();
            return;
        }

        LinearLayout box = modernDialogCard("Ventes en attente", "Touchez une vente pour la reprendre. Appui long pour supprimer.");
        ListView listView = new ListView(this);
        listView.setAdapter(new TwoLineAdapter(this, items));
        box.addView(listView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(360)));

        AlertDialog dialog = new DialogUi.Builder(this)
                .setView(wrapDialog(box))
                .setNegativeButton("Fermer", null)
                .create();

        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < drafts.size()) {
                loadDraft(drafts.get(position).id);
                dialog.dismiss();
            }
        });
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < drafts.size()) {
                DraftRow dr = drafts.get(position);
                AlertDialog confirm = new DialogUi.Builder(this)
                        .setView(wrapDialog(messageDialogContent("Supprimer la vente en attente", dr.code)))
                        .setPositiveButton("Supprimer", (d, w) -> {
                            db.deleteDraft(dr.id);
                            dialog.dismiss();
                            Toast.makeText(this, "Vente en attente supprimée", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Annuler", null)
                        .create();
                confirm.show();
                styleDialog(confirm);
            }
            return true;
        });
        dialog.show();
        styleDialog(dialog);
    }

    private void loadDraft(long draftId) {
        try {
            JSONObject h = db.draftHeader(draftId);
            JSONArray lines = db.draftLines(draftId);
            long draftEmpId = h.optLong("emplacement_id", db.defaultEmplacementId());

            suppressEmpReset = true;
            setSpinnerByLong(emp, empIds, draftEmpId);
            suppressEmpReset = false;
            searchNow(false);

            cartItems.clear();
            for (int i = 0; i < lines.length(); i++) {
                JSONObject j = lines.getJSONObject(i);
                long variantId = j.getLong("variante_id");
                Row r = findVariantById(variantId);
                CartItem x = new CartItem();
                x.id = variantId;
                x.designation = j.optString("designation", "Article");
                x.qty = DatabaseHelper.roundHalf(j.optDouble("quantite", 0));
                x.price = Math.max(0, j.optDouble("prix", 0));
                x.stock = r != null ? r.stock : 999999;
                cartItems.put(variantId, x);
            }
            setSpinnerByLong(client, clientIds, h.optLong("client_id", 0));
            setSpinnerByText(payMode, h.optString("mode_paiement", "ESPECES"));
            remise.setText(zeroToBlank(h.optDouble("remise", 0)));
            tva.setText(zeroToBlank(h.optDouble("taux_tva", 0)));
            livraison.setText(zeroToBlank(h.optDouble("frais_livraison", 0)));
            received.setText(String.valueOf(h.optDouble("montant_recu", 0)));
            comment.setText(h.optString("commentaire", ""));
            currentDraftId = draftId;
            renderCart();
            Toast.makeText(this, "Vente reprise", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            suppressEmpReset = false;
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Row findVariantById(long variantId) {
        Cursor c = db.searchVariants("", empId(), 500);
        try {
            while (c.moveToNext()) {
                if (c.getLong(0) == variantId) return readVariantRow(c);
            }
        } finally { c.close(); }
        return null;
    }

    private void handlePosBackPressed(OnBackPressedCallback callback) {
        if (exitConfirmed || cartItems.isEmpty()) {
            callback.setEnabled(false);
            getOnBackPressedDispatcher().onBackPressed();
            return;
        }

        AlertDialog exitDialog = new DialogUi.Builder(this)
                .setView(wrapDialog(messageDialogContent("Quitter le POS ?", "Une vente est en cours. Pour éviter une fermeture accidentelle, choisissez ce que vous voulez faire.")))
                .setPositiveButton("Mettre en attente et quitter", (d, w) -> holdAndExit())
                .setNeutralButton("Quitter sans sauvegarder", (d, w) -> {
                    exitConfirmed = true;
                    cartItems.clear();
                    callback.setEnabled(false);
                    finish();
                })
                .setNegativeButton("Rester", null)
                .create();
        exitDialog.show();
        styleDialog(exitDialog);
    }

    private void holdAndExit() {
        if (cartItems.isEmpty()) {
            exitConfirmed = true;
            finish();
            return;
        }
        try {
            long id = db.saveDraft(currentDraftId, currentHeader(), currentLines());
            currentDraftId = 0;
            cartItems.clear();
            exitConfirmed = true;
            Toast.makeText(this, "Vente mise en attente : " + id, Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception ex) {
            Toast.makeText(this, "Impossible de mettre en attente : " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void confirmClearCart() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Panier déjà vide", Toast.LENGTH_SHORT).show();
            return;
        }
        AlertDialog clearDialog = new DialogUi.Builder(this)
                .setView(wrapDialog(messageDialogContent("Annuler la vente", "Vider complètement le panier en cours ?")))
                .setPositiveButton("Vider le panier", (d, w) -> {
                    cartItems.clear();
                    currentDraftId = 0;
                    clearPaymentFields(true);
                    renderCart();
                    Toast.makeText(this, "Panier vidé", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Garder", null)
                .create();
        clearDialog.show();
        styleDialog(clearDialog);
    }

    private void confirmSave() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Panier vide", Toast.LENGTH_SHORT).show();
            return;
        }
        TotalsCalc t = calcTotals();
        String draftNote = currentDraftId > 0 ? "\nReprise : vente en attente #" + currentDraftId : "";
        String message =
                "Articles : " + cartItems.size() + "\n" +
                "Sous-total : " + money(t.subtotal) + " Ar\n" +
                "Remise : " + money(t.remise) + " Ar\n" +
                "TVA : " + money(t.montantTva) + " Ar\n" +
                "Livraison : " + money(t.livraison) + " Ar\n" +
                "Total : " + money(t.total) + " Ar\n" +
                "Reçu : " + money(t.received) + " Ar\n" +
                "Monnaie à rendre : " + money(t.change) + " Ar\n" +
                "Statut : " + t.status + draftNote;
        AlertDialog saveDialog = new DialogUi.Builder(this)
                .setView(wrapDialog(messageDialogContent("Valider la vente", message)))
                .setPositiveButton("Valider", (d, w) -> saveSaleConfirmed())
                .setNegativeButton("Annuler", null)
                .create();
        saveDialog.show();
        styleDialog(saveDialog);
    }

    private void saveSaleConfirmed() {
        if (cartItems.isEmpty()) {
            Toast.makeText(this, "Panier vide", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            JSONObject h = currentHeader();
            JSONArray lines = currentLines();
            long usedDraftId = currentDraftId;
            long id = db.saveSale(h, lines);
            JSONObject receipt = db.saleReceipt(id);
            String ticketClient = client.getSelectedItemPosition() > 0 && client.getSelectedItem() != null ? String.valueOf(client.getSelectedItem()) : "Client comptoir";

            if (usedDraftId > 0) db.deleteDraft(usedDraftId);
            currentDraftId = 0;

            if (AppPrefs.autoPrint(this)) {
                BluetoothEscPosPrinter.printSale(this, receipt, lines, ticketClient, new BluetoothEscPosPrinter.Callback() {
                    @Override public void onSuccess() {
                        runOnUiThread(() -> Toast.makeText(PosActivity.this, "Ticket imprimé", Toast.LENGTH_SHORT).show());
                    }
                    @Override public void onError(String message) {
                        runOnUiThread(() -> Toast.makeText(PosActivity.this, "Vente enregistrée, impression : " + message, Toast.LENGTH_LONG).show());
                    }
                });
            }

            cartItems.clear();
            clearPaymentFields(true);
            renderCart();
            searchNow(false);

            Toast.makeText(this, "Vente " + receipt.optString("num_vente") + " enregistrée dans SQLite", Toast.LENGTH_LONG).show();
            if ("ONLINE".equals(AppPrefs.mode(this))) {
                Toast.makeText(this, "Vente locale enregistrée. Ouverture de la synchronisation navigateur…", Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, SyncActivity.class));
            }
        } catch (Exception ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private JSONObject currentHeader() throws Exception {
        JSONObject h = new JSONObject();
        h.put("emplacement_id", empId());
        long cl = clientIds.get(client.getSelectedItemPosition());
        if (cl > 0) h.put("client_id", cl);
        h.put("remise", num(remise));
        h.put("taux_tva", num(tva));
        h.put("frais_livraison", num(livraison));
        h.put("montant_recu", calcTotals().received);
        h.put("mode_paiement", String.valueOf(payMode.getSelectedItem()));
        h.put("statut_paiement", String.valueOf(payStatus.getSelectedItem()));
        h.put("commentaire", comment.getText().toString());
        return h;
    }

    private JSONArray currentLines() throws Exception {
        JSONArray lines = new JSONArray();
        for (CartItem x : cartItems.values()) {
            JSONObject j = new JSONObject();
            j.put("variante_id", x.id);
            j.put("designation", x.designation);
            j.put("quantite", x.qty);
            j.put("prix", x.price);
            lines.put(j);
        }
        return lines;
    }

    private void clearPaymentFields(boolean clearSearch) {
        received.setText("");
        remise.setText("");
        tva.setText("");
        livraison.setText("");
        comment.setText("");
        if (client.getCount() > 0) client.setSelection(0);
        if (payMode.getCount() > 0) payMode.setSelection(0);
        if (payStatus.getCount() > 0) payStatus.setSelection(0);
        if (clearSearch) search.setText("");
    }

    private void renderCart() {
        ArrayList<String> rows = new ArrayList<>();
        for (CartItem x : cartItems.values()) {
            double lt = x.qty * x.price;
            rows.add(x.designation + "  •  " + qty(x.qty) + " × " + money(x.price) + "  •  " + money(lt) + " Ar");
        }
        cart.setAdapter(new SingleLineCartAdapter(this, rows));
        int articleCount = cartItems.size();
        if (cartCount != null) {
            cartCount.setText(articleCount + (articleCount > 1 ? " articles" : " article"));
        }

        TotalsCalc t = calcTotals();
        payStatus.setSelection(t.status.startsWith("EN") ? 0 : t.status.startsWith("PART") ? 1 : 2);
        String holdInfo = currentDraftId > 0 ? "\nEN ATTENTE REPRISE #" + currentDraftId : "";
        totals.setText(
                "Sous-total : " + money(t.subtotal) + " Ar  •  Remise : " + money(t.remise) + " Ar" +
                "  •  TVA : " + money(t.montantTva) + " Ar  •  Livraison : " + money(t.livraison) + " Ar\n" +
                "TOTAL : " + money(t.total) + " Ar  •  Reçu : " + money(t.received) + " Ar\n" +
                "Monnaie : " + money(t.change) + " Ar  •  " + t.status + holdInfo
        );
    }

    private TotalsCalc calcTotals() {
        TotalsCalc t = new TotalsCalc();
        for (CartItem x : cartItems.values()) t.subtotal += x.qty * x.price;
        t.remise = Math.max(0, num(remise));
        t.tauxTva = Math.max(0, num(tva));
        t.livraison = Math.max(0, num(livraison));
        t.montantTva = t.subtotal * t.tauxTva / 100.0;
        t.total = Math.max(0, t.subtotal + t.montantTva - t.remise + t.livraison);
        String receivedText = received.getText().toString().trim();
        if (isCashMode(String.valueOf(payMode.getSelectedItem())) && receivedText.isEmpty()) {
            // ESPÈCES par défaut = total, mais toute valeur saisie manuellement est respectée.
            t.received = t.total;
        } else {
            t.received = Math.max(0, num(received));
        }
        t.change = Math.max(0, t.received - t.total);
        t.status = t.received <= 0.00001 ? "EN ATTENTE" : (t.received + 0.00001 < t.total ? "PARTIEL" : "PAYÉ");
        return t;
    }

    private TotalsCalc calcDialogTotals(EditText remiseField, EditText tvaField, EditText livraisonField, EditText receivedField) {
        TotalsCalc t = new TotalsCalc();
        for (CartItem x : cartItems.values()) t.subtotal += x.qty * x.price;
        t.remise = Math.max(0, num(remiseField));
        t.tauxTva = Math.max(0, num(tvaField));
        t.livraison = Math.max(0, num(livraisonField));
        t.montantTva = t.subtotal * t.tauxTva / 100.0;
        t.total = Math.max(0, t.subtotal + t.montantTva - t.remise + t.livraison);
        t.received = Math.max(0, num(receivedField));
        t.change = Math.max(0, t.received - t.total);
        t.status = t.received <= 0.00001 ? "EN ATTENTE" : (t.received + 0.00001 < t.total ? "PARTIEL" : "PAYÉ");
        return t;
    }

    private void showInlineNewClientDialog(OnPosClientCreated callback) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(4));

        TextView note = new TextView(this);
        note.setText("Code client généré automatiquement lors de la synchronisation.");
        note.setTextColor(0xFF64748B);
        note.setTextSize(12);
        note.setPadding(0, 0, 0, dp(10));
        box.addView(note);

        EditText name = inputField("Nom complet *", "");
        name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        box.addView(name);
        EditText phone = inputField("Téléphone / Contact", "");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        box.addView(phone);
        EditText address = inputField("Adresse", "");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(address);

        LinearLayout dialogBox = modernDialogCard("Nouveau client", "Créez rapidement un client comme dans la version en ligne.");
        dialogBox.addView(box);
        AlertDialog dialog = new DialogUi.Builder(this)
                .setView(wrapDialog(dialogBox))
                .setPositiveButton("Enregistrer", null)
                .setNegativeButton("Annuler", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String fullName = name.getText().toString().trim();
            if (fullName.isEmpty()) {
                name.setError("Nom complet obligatoire");
                return;
            }
            try {
                long id = db.addLocalClient(fullName, phone.getText().toString(), address.getText().toString());
                dialog.dismiss();
                Toast.makeText(this, "Client ajouté à la vente", Toast.LENGTH_SHORT).show();
                if (callback != null) callback.onCreated(id);
            } catch (Exception ex) {
                Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));
        dialog.show();
        styleDialog(dialog);
    }

    private interface OnPosClientCreated { void onCreated(long id); }

    private ArrayAdapter<String> copySpinnerAdapter(Spinner source) {
        ArrayList<String> items = new ArrayList<>();
        for (int i = 0; i < source.getCount(); i++) items.add(String.valueOf(source.getItemAtPosition(i)));
        return new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(0xFF0F172A);
                    t.setTextSize(14);
                    t.setPadding(dp(12), dp(8), dp(12), dp(8));
                }
                return v;
            }
            @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                if (v instanceof TextView) {
                    TextView t = (TextView) v;
                    t.setTextColor(0xFF0F172A);
                    t.setTextSize(14);
                    t.setBackgroundColor(0xFFFFFFFF);
                    t.setPadding(dp(14), dp(12), dp(14), dp(12));
                }
                return v;
            }
        };
    }

    private boolean isCashMode(String mode) {
        if (mode == null) return false;
        String m = mode.trim().toUpperCase(Locale.ROOT).replace('È', 'E').replace('É', 'E');
        return m.equals("ESPECES") || m.equals("ESPECE") || m.equals("CASH");
    }

    private String plainAmount(double value) {
        double rounded = DatabaseHelper.round2(Math.max(0, value));
        if (Math.abs(rounded - Math.rint(rounded)) < 0.00001) {
            return String.format(Locale.ROOT, "%.0f", rounded);
        }
        return String.format(Locale.ROOT, "%.2f", rounded);
    }

    private EditText compactInputField(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextSize(12);
        e.setTextColor(0xFF0F172A);
        e.setHintTextColor(0xFF64748B);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundResource(R.drawable.bg_input);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private LinearLayout.LayoutParams weightedFieldParams(int startMarginDp, int endMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        lp.setMarginStart(dp(startMarginDp));
        lp.setMarginEnd(dp(endMarginDp));
        lp.bottomMargin = dp(12);
        return lp;
    }

    private EditText inputField(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setTextColor(0xFF0F172A);
        e.setHintTextColor(0xFF64748B);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setMinHeight(dp(48));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        e.setLayoutParams(lp);
        return e;
    }

    private String emptyToZero(String s) {
        String x = s == null ? "" : s.trim();
        return x.isEmpty() ? "0" : x;
    }

    private String emptyNumeric(String s) {
        return s == null ? "" : s.trim();
    }

    private String zeroToBlank(double value) {
        return Math.abs(value) < 0.00001 ? "" : String.valueOf(value);
    }

    private void setSpinnerByLong(Spinner spinner, ArrayList<Long> ids, long value) {
        for (int i = 0; i < ids.size(); i++) if (ids.get(i) == value) { spinner.setSelection(i); return; }
        if (spinner.getCount() > 0) spinner.setSelection(0);
    }

    private void setSpinnerByText(Spinner spinner, String text) {
        String wanted = text == null ? "" : text.toUpperCase(Locale.ROOT).replace('_', ' ');
        for (int i = 0; i < spinner.getCount(); i++) {
            String item = String.valueOf(spinner.getItemAtPosition(i)).toUpperCase(Locale.ROOT);
            if (item.equals(wanted) || item.replace('É', 'E').equals(wanted.replace('É', 'E'))) { spinner.setSelection(i); return; }
        }
        if (spinner.getCount() > 0) spinner.setSelection(0);
    }


    private LinearLayout modernDialogCard(String title, String subtitle) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(10));
        box.setBackgroundResource(R.drawable.bg_dialog_surface);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(18);
        t.setTextColor(0xFF2F2B33);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, 0, 0, dp(6));
        box.addView(t);
        if (subtitle != null && !subtitle.trim().isEmpty()) {
            TextView s = new TextView(this);
            s.setText(subtitle);
            s.setTextSize(13);
            s.setTextColor(0xFF64748B);
            s.setPadding(0, 0, 0, dp(12));
            box.addView(s);
        }
        return box;
    }

    private TextView dialogLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(0xFF714B67);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(2), 0, dp(6));
        return t;
    }

    private EditText dialogInput(String hint, String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(0xFF0F172A);
        e.setHintTextColor(0xFF64748B);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setMinHeight(dp(48));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setSingleLine(true);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        e.setLayoutParams(lp);
        return e;
    }

    private ScrollView wrapDialog(View content) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setPadding(dp(6), dp(6), dp(6), dp(6));
        scroll.addView(content);
        return scroll;
    }

    private LinearLayout messageDialogContent(String title, String message) {
        LinearLayout box = modernDialogCard(title, null);
        TextView body = new TextView(this);
        body.setText(message);
        body.setTextColor(0xFF475569);
        body.setTextSize(15);
        body.setPadding(0, dp(4), 0, dp(2));
        box.addView(body);
        return box;
    }

    private void styleDialog(AlertDialog dialog) {
        DialogUi.style(dialog);
    }

    private void styleDialogButton(Button button, int kind) {
        if (button == null) return;
        button.setVisibility(View.VISIBLE);
        button.setAllCaps(false);
        button.setTextSize(button.getText() != null && button.getText().length() > 22 ? 12 : 14);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setMinHeight(dp(44));
        button.setMinWidth(dp(72));
        button.setPadding(dp(12), dp(6), dp(12), dp(6));
        if (kind == 1) {
            button.setTextColor(0xFFFFFFFF);
            button.setBackgroundResource(R.drawable.bg_dialog_action_primary);
        } else if (kind == 2) {
            button.setTextColor(0xFF9F1239);
            button.setBackgroundResource(R.drawable.bg_dialog_action_danger);
        } else {
            button.setTextColor(0xFF714B67);
            button.setBackgroundResource(R.drawable.bg_dialog_action_secondary);
        }
        android.view.ViewGroup.MarginLayoutParams lp = null;
        if (button.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams) {
            lp = (android.view.ViewGroup.MarginLayoutParams) button.getLayoutParams();
            lp.setMarginStart(dp(4));
            lp.setMarginEnd(dp(4));
            lp.topMargin = dp(4);
            lp.bottomMargin = dp(6);
            button.setLayoutParams(lp);
        }
    }

    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }

    private String firstImageUrl(List<Row> variants) {
        for (Row r : variants) if (r.imageUrl != null && !r.imageUrl.trim().isEmpty()) return r.imageUrl.trim();
        return "";
    }

    private TextWatcher simpleWatcher(Runnable r) {
        return new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { r.run(); }
            public void afterTextChanged(Editable e) {}
        };
    }

    private static double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(',', '.')); }
        catch (Exception x) { return 0; }
    }
    private static String money(double v) { return String.format(Locale.FRANCE, "%,.0f", v); }
    private static String qty(double v) { return String.format(Locale.FRANCE, "%.1f", v); }

    static class ProductRow {
        long id; String name; int variantCount; double stock; String imageUrl;
    }
    static class Row {
        long id; long productId; String produit, couleur, taille, code, imageUrl; double price, stock;
        String designation() {
            ArrayList<String> d = new ArrayList<>();
            if (couleur != null && !couleur.isEmpty()) d.add(couleur);
            if (taille != null && !taille.isEmpty()) d.add("Taille " + taille);
            return produit + (d.isEmpty() ? "" : " (" + String.join(" • ", d) + ")");
        }
        String variantLabel() {
            ArrayList<String> d = new ArrayList<>();
            if (couleur != null && !couleur.isEmpty()) d.add(couleur);
            if (taille != null && !taille.isEmpty()) d.add("Taille " + taille);
            return d.isEmpty() ? designation() : String.join(" • ", d);
        }
    }
    static class CartItem { long id; String designation; double price, qty, stock; }
    static class TotalsCalc { double subtotal, remise, tauxTva, montantTva, livraison, total, received, change; String status; }
    static class DraftRow { long id; String code, updatedAt; int itemCount; double amount; }
    static class PackSaleRow { long id; String name; double price; int itemCount, linkedCount; }
    static class PackComponent {
        long variantId; String name, color, size; double qty, detailPrice, catalogPrice, stock;
        String designation() {
            String d = name == null || name.trim().isEmpty() ? "Article" : name.trim();
            ArrayList<String> bits = new ArrayList<>();
            if (color != null && !color.trim().isEmpty()) bits.add(color.trim());
            if (size != null && !size.trim().isEmpty()) bits.add(size.trim());
            if (!bits.isEmpty()) d += " (" + String.join(", ", bits) + ")";
            return d;
        }
    }
    static class SimpleSelected implements AdapterView.OnItemSelectedListener {
        Runnable r; SimpleSelected(Runnable x) { r = x; }
        public void onItemSelected(AdapterView<?> p, View v, int i, long l) { r.run(); }
        public void onNothingSelected(AdapterView<?> p) {}
    }
}
