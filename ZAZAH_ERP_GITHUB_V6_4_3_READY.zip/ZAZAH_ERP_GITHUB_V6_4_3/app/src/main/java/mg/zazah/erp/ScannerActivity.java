package mg.zazah.erp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScannerActivity extends AppCompatActivity {
    private PreviewView preview;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final AtomicBoolean done=new AtomicBoolean(false);
    private BarcodeScanner scanner;
    private final ActivityResultLauncher<String> permission =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(),ok->{if(ok)startCamera();else finish();});

    @Override protected void onCreate(Bundle b){
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);setContentView(R.layout.activity_scanner);
        UiTheme3D.apply(this);
        preview=findViewById(R.id.previewView);scanner=BarcodeScanning.getClient();
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();
        else permission.launch(Manifest.permission.CAMERA);
    }

    private void startCamera(){
        ListenableFuture<ProcessCameraProvider> f=ProcessCameraProvider.getInstance(this);
        f.addListener(()->{try{
            ProcessCameraProvider cp=f.get();Preview p=new Preview.Builder().build();p.setSurfaceProvider(preview.getSurfaceProvider());
            ImageAnalysis a=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
            a.setAnalyzer(executor,img->scan(img));
            cp.unbindAll();cp.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,a);
        }catch(Exception e){finish();}},ContextCompat.getMainExecutor(this));
    }

    private void scan(ImageProxy proxy){
        if(done.get()){proxy.close();return;}
        if(proxy.getImage()==null){proxy.close();return;}
        InputImage im=InputImage.fromMediaImage(proxy.getImage(),proxy.getImageInfo().getRotationDegrees());
        scanner.process(im).addOnSuccessListener(list->accept(list)).addOnCompleteListener(t->proxy.close());
    }

    private void accept(List<Barcode> list){
        if(done.get()||list==null)return;
        for(Barcode b:list){String s=b.getRawValue();if(s!=null&&!s.trim().isEmpty()&&done.compareAndSet(false,true)){
            Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null&&android.os.Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(80,VibrationEffect.DEFAULT_AMPLITUDE));
            Intent data=new Intent();data.putExtra("code",s.trim());setResult(RESULT_OK,data);finish();break;}}
    }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();if(scanner!=null)scanner.close();}
}
