package mg.zazah.erp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private TextView txtMode, txtProducts, txtStock, txtEmployees, txtPending, txtSessionHome;
    private String appliedThemeKey;

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);SystemUiHelper.install(this);
        setContentView(R.layout.activity_main);
        UiTheme3D.apply(this);
        db = new DatabaseHelper(this);
        appliedThemeKey = AppPrefs.uiTheme(this);

        txtMode = findViewById(R.id.txtMode);
        txtProducts = findViewById(R.id.txtProducts);
        txtStock = findViewById(R.id.txtStock);
        txtEmployees = findViewById(R.id.txtEmployees);
        txtPending = findViewById(R.id.txtPending);
        txtSessionHome = findViewById(R.id.txtSessionHome);

        findViewById(R.id.btnPos).setOnClickListener(v -> startActivity(new Intent(this, PosActivity.class)));
        findViewById(R.id.btnPosHistory).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.btnStock).setOnClickListener(v -> startActivity(new Intent(this, StockActivity.class)));
        findViewById(R.id.btnProductsManage).setOnClickListener(v -> startActivity(new Intent(this, ProductsActivity.class)));
        findViewById(R.id.btnLabels).setOnClickListener(v -> startActivity(new Intent(this, LabelPrintActivity.class)));
        findViewById(R.id.btnClients).setOnClickListener(v -> startActivity(new Intent(this, ClientsActivity.class)));
        findViewById(R.id.btnPayroll).setOnClickListener(v -> startActivity(new Intent(this, PayrollHubActivity.class)));
        findViewById(R.id.btnPacks).setOnClickListener(v -> startActivity(new Intent(this, PackActivity.class)));
        findViewById(R.id.btnUsers).setOnClickListener(v -> startActivity(new Intent(this, UsersActivity.class)));
        findViewById(R.id.btnSession).setOnClickListener(v -> startActivity(new Intent(this, SessionActivity.class)));
        findViewById(R.id.btnSync).setOnClickListener(v -> startActivity(new Intent(this, SyncActivity.class)));
        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnThemes).setOnClickListener(v -> startActivity(new Intent(this, ThemeActivity.class)));
        findViewById(R.id.btnAbout).setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        findViewById(R.id.btnMode).setOnClickListener(v -> {
            String next = "LOCAL".equals(AppPrefs.mode(this)) ? "ONLINE" : "LOCAL";
            AppPrefs.setMode(this, next);
            refresh();
        });
    }

    @Override protected void onResume() {
        super.onResume();
        String nowTheme = AppPrefs.uiTheme(this);
        if (appliedThemeKey != null && !appliedThemeKey.equals(nowTheme)) {
            recreate();
            return;
        }
        refresh();
    }

    private void refresh() {
        String mode = AppPrefs.mode(this);
        txtMode.setText("ONLINE".equals(mode)
                ? "EN LIGNE · SQLite + synchro"
                : "LOCAL · SQLite hors ligne");

        // Chaque compteur est protégé pour que l'accueil reste utilisable même
        // pendant une migration ou avec une ancienne base SQLite incomplète.
        try { txtProducts.setText(String.valueOf(db.productCount())); }
        catch (Exception e) { txtProducts.setText("—"); }

        try { txtStock.setText(String.format(Locale.FRANCE, "%.1f", db.stockTotal())); }
        catch (Exception e) { txtStock.setText("—"); }

        try { txtEmployees.setText(String.valueOf(db.salaryEmployeeCount())); }
        catch (Exception e) { txtEmployees.setText("—"); }

        try {
            int pending = db.pendingMasterCount() + db.pendingCount();
            txtPending.setText(String.valueOf(pending));
        } catch (Exception e) {
            txtPending.setText("—");
        }

        try {
            DatabaseHelper.AppUser u = db.appUser(AppPrefs.sessionUserId(this));
            if (u == null || !u.active) {
                if (AppPrefs.hasSession(this)) AppPrefs.clearSession(this);
                txtSessionHome.setText("Aucune session active");
            } else {
                txtSessionHome.setText(u.displayName() + " • " + u.roleLabel());
            }
        } catch (Exception e) {
            txtSessionHome.setText("Aucune session active");
        }
    }
}
