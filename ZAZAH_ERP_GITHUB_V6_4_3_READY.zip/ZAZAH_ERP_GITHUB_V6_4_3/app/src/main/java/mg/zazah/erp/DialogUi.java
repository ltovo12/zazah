package mg.zazah.erp;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Style premium commun de tous les popups/dialogs ZAZAH.
 * V5.25.48 : aspect inspiré de la page de connexion : en-tête clair,
 * corps graphite, champs contrastés et actions modernes.
 */
public final class DialogUi {
    private static final String CLOSE_TAG = "zazah_dialog_close_v52548";
    private DialogUi() {}

    /**
     * Builder à utiliser partout dans l'application. Il garantit que même les
     * dialogs affichés directement avec .show() reçoivent le style ZAZAH.
     */
    public static class Builder extends AlertDialog.Builder {
        public Builder(Context context) {
            super(context);
        }

        public Builder(Context context, int themeResId) {
            super(context, themeResId);
        }

        @Override
        public AlertDialog create() {
            final AlertDialog dialog = super.create();
            final Window window = dialog.getWindow();
            if (window != null) {
                final View decor = window.getDecorView();
                decor.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                    @Override
                    public void onViewAttachedToWindow(View v) {
                        v.post(() -> DialogUi.style(dialog));
                    }

                    @Override
                    public void onViewDetachedFromWindow(View v) {
                    }
                });
            }
            return dialog;
        }

        @Override
        public AlertDialog show() {
            AlertDialog dialog = create();
            dialog.show();
            DialogUi.style(dialog);
            return dialog;
        }
    }

    public static void style(AlertDialog dialog) {
        if (dialog == null) return;

        TextView title = findAndroidText(dialog, "alertTitle");
        TextView message = dialog.findViewById(android.R.id.message);
        Window w = dialog.getWindow();

        if (w != null) {
            // Une boîte avec titre reprend le visuel blanc + graphite de la
            // page de démarrage. Sans titre, on garde une carte graphite pure.
            w.setBackgroundDrawableResource(
                    title != null
                            ? R.drawable.bg_dialog_login_card
                            : R.drawable.bg_dialog_login_card_plain
            );
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams p = w.getAttributes();
            p.dimAmount = 0.76f;
            w.setAttributes(p);
            w.setWindowAnimations(R.style.ZAZAH_Dialog_Animation);

            int screen = dialog.getContext().getResources().getDisplayMetrics().widthPixels;
            int max = dp(w.getDecorView(), 650);
            int margin = dp(w.getDecorView(), 28);
            int width = Math.min(Math.max(dp(w.getDecorView(), 280), screen - margin), max);
            w.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                w.getDecorView().setElevation(dp(w.getDecorView(), 28));
            }
        }

        styleButton(dialog.getButton(AlertDialog.BUTTON_POSITIVE), 1);
        styleButton(dialog.getButton(AlertDialog.BUTTON_NEGATIVE), 0);
        styleButton(dialog.getButton(AlertDialog.BUTTON_NEUTRAL), 2);

        if (title != null) {
            title.setTextColor(Color.rgb(30, 41, 59));
            title.setTextSize(20);
            title.setTypeface(null, Typeface.BOLD);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setPadding(
                    title.getPaddingLeft(),
                    Math.max(title.getPaddingTop(), dp(title, 12)),
                    dp(title, 50),
                    Math.max(title.getPaddingBottom(), dp(title, 12))
            );
        }

        if (message != null) {
            message.setTextColor(Color.rgb(218, 226, 238));
            message.setTextSize(15);
            message.setLineSpacing(0f, 1.12f);
        }

        styleDialogList(dialog);

        View decor = w != null ? w.getDecorView() : null;
        if (decor != null) {
            styleContentTree(decor, title, message, false);
            installClose(dialog, decor);
        }
    }

    public static AlertDialog show(AlertDialog dialog) {
        if (dialog == null) return null;
        dialog.show();
        style(dialog);
        return dialog;
    }

    public static AlertDialog show(AlertDialog.Builder builder) {
        if (builder == null) return null;
        return show(builder.create());
    }

    private static TextView findAndroidText(AlertDialog dialog, String name) {
        int id = dialog.getContext().getResources().getIdentifier(name, "id", "android");
        if (id == 0) return null;
        View v = dialog.findViewById(id);
        return v instanceof TextView ? (TextView) v : null;
    }

    private static void styleDialogList(final AlertDialog dialog) {
        final ListView list = dialog.getListView();
        if (list == null) return;

        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(dp(list, 10), dp(list, 6), dp(list, 10), dp(list, 8));
        list.setClipToPadding(false);

        list.post(() -> {
            for (int i = 0; i < list.getChildCount(); i++) {
                styleDialogListChild(list.getChildAt(i));
            }
        });
    }

    private static void styleDialogListChild(View child) {
        if (child == null) return;
        if (child instanceof TextView && !(child instanceof Button)) {
            TextView t = (TextView) child;
            t.setTextColor(Color.rgb(238, 243, 249));
            t.setTextSize(14);
            t.setTypeface(null, Typeface.BOLD);
            t.setGravity(Gravity.CENTER_VERTICAL);
            t.setMinHeight(dp(t, 52));
            t.setPadding(dp(t, 16), dp(t, 8), dp(t, 16), dp(t, 8));
            t.setBackgroundResource(R.drawable.bg_dialog_choice_lux);
        }
        if (child instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) child;
            for (int i = 0; i < g.getChildCount(); i++) {
                styleDialogListChild(g.getChildAt(i));
            }
        }
    }

    private static void installClose(final AlertDialog dialog, View decor) {
        if (!(decor instanceof FrameLayout)) return;
        FrameLayout frame = (FrameLayout) decor;
        if (frame.findViewWithTag(CLOSE_TAG) != null) return;

        TextView x = new TextView(dialog.getContext());
        x.setTag(CLOSE_TAG);
        x.setText("×");
        x.setTextColor(Color.rgb(71, 85, 105));
        x.setTextSize(23);
        x.setTypeface(null, Typeface.BOLD);
        x.setGravity(Gravity.CENTER);
        x.setContentDescription("Fermer");
        x.setBackgroundResource(R.drawable.bg_dialog_close_lux);
        x.setClickable(true);
        x.setFocusable(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) x.setElevation(dp(x, 12));
        x.setOnClickListener(v -> dialog.dismiss());

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                dp(x, 40), dp(x, 40), Gravity.TOP | Gravity.END
        );
        lp.topMargin = dp(x, 8);
        lp.setMarginEnd(dp(x, 8));
        frame.addView(x, lp);
        x.bringToFront();
    }

    private static void styleContentTree(View v, TextView title, TextView message, boolean inheritedLightCard) {
        if (v == null) return;

        Object rawTag = v.getTag();
        String tag = rawTag == null ? "" : String.valueOf(rawTag);
        boolean keepOwnColors = "zazah_keep_colors".equals(tag);
        boolean lightCard = inheritedLightCard || "zazah_light_card".equals(tag);

        if (v instanceof Button) {
            // Les boutons standards sont traités séparément.
        } else if (v instanceof EditText) {
            EditText e = (EditText) v;
            e.setTextColor(Color.WHITE);
            e.setHintTextColor(Color.rgb(147, 163, 184));
            e.setBackgroundResource(R.drawable.bg_dialog_input_lux);
            e.setPadding(dp(e, 14), e.getPaddingTop(), dp(e, 14), e.getPaddingBottom());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) e.setElevation(dp(e, 2));
        } else if (v instanceof Spinner) {
            // Le Spinner reste clair : ne pas recolorer son TextView interne en blanc.
            v.setBackgroundResource(R.drawable.bg_dialog_spinner_lux);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) v.setElevation(dp(v, 2));
            return;
        } else if (v instanceof TextView) {
            TextView t = (TextView) v;
            if (t != title && t != message && t.getId() != android.R.id.button1
                    && t.getId() != android.R.id.button2 && t.getId() != android.R.id.button3) {
                // Corps graphite = texte clair. Carte blanche = texte sombre conservé.
                if (!keepOwnColors && !lightCard) {
                    t.setTextColor(Color.rgb(226, 232, 240));
                }
            }
        }

        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                styleContentTree(vg.getChildAt(i), title, message, lightCard);
            }
        }
    }

    private static void styleButton(Button b, int kind) {
        if (b == null) return;
        CharSequence label = b.getText();
        if (label == null || label.toString().trim().isEmpty()) {
            b.setVisibility(View.GONE);
            return;
        }

        b.setVisibility(View.VISIBLE);
        b.setAllCaps(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) b.setBackgroundTintList(null);
        b.setAlpha(1.0f);
        b.setTextSize(b.getText() != null && b.getText().length() > 22 ? 12 : 14);
        b.setTypeface(null, Typeface.BOLD);

        if (kind == 1) {
            b.setTextColor(Color.WHITE);
            b.setBackgroundResource(R.drawable.bg_dialog_action_primary_lux);
        } else if (kind == 2) {
            b.setTextColor(Color.WHITE);
            b.setBackgroundResource(R.drawable.bg_dialog_action_danger_lux);
        } else {
            b.setTextColor(Color.rgb(232, 238, 247));
            b.setBackgroundResource(R.drawable.bg_dialog_action_secondary_lux);
        }

        UiTheme3D.hardenButton(b);
        b.setMinHeight(dp(b, 48));
        b.setMinWidth(dp(b, 80));
        b.setPadding(dp(b, 14), dp(b, 6), dp(b, 14), dp(b, 6));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setElevation(dp(b, 7));
            b.setTranslationZ(dp(b, 1));
        }

        if (b.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) b.getLayoutParams();
            lp.setMarginStart(dp(b, 4));
            lp.setMarginEnd(dp(b, 4));
            lp.topMargin = dp(b, 5);
            lp.bottomMargin = dp(b, 7);
            b.setLayoutParams(lp);
        }
    }

    private static int dp(View v, int value) {
        return Math.round(v.getResources().getDisplayMetrics().density * value);
    }
}
