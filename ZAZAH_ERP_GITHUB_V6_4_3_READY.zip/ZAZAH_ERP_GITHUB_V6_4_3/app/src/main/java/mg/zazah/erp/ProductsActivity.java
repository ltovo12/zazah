package mg.zazah.erp;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

/** Gestion des produits directement dans SQLite, utilisable hors ligne. */
public class ProductsActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private EditText search;
    private ListView list;
    private TextView info;
    private final ArrayList<ProductRow> rows = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        UiTheme3D.installTheme(this);
        super.onCreate(b);
        SystemUiHelper.install(this);
        setContentView(R.layout.activity_products);
        UiTheme3D.apply(this);

        db = new DatabaseHelper(this);
        search = findViewById(R.id.inputProductSearch);
        list = findViewById(R.id.listProducts);
        info = findViewById(R.id.txtProductInfo);
        Button add = findViewById(R.id.btnNewProduct);
        Button stock = findViewById(R.id.btnProductsStock);
        Button back = findViewById(R.id.btnProductsBack);

        add.setOnClickListener(v -> showProductDialog(null));
        stock.setOnClickListener(v -> startActivity(new Intent(this, StockActivity.class)));
        back.setOnClickListener(v -> finish());
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < rows.size()) showProductDialog(rows.get(position));
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < rows.size()) showActions(rows.get(position));
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { load(); }
            public void afterTextChanged(Editable e) {}
        });
        load();
    }

    @Override protected void onResume() {
        super.onResume();
        if (db != null && search != null) load();
    }

    private void load() {
        rows.clear();
        ArrayList<TwoLineAdapter.Item> items = new ArrayList<>();
        Cursor c = db.productsManage(search.getText().toString());
        int localCount = 0;
        while (c.moveToNext()) {
            ProductRow r = new ProductRow();
            r.id = c.getLong(0);
            r.name = c.getString(1);
            r.price = c.getDouble(2);
            r.active = c.getInt(3) == 1;
            r.imageUrl = c.getString(4);
            r.localDirty = c.getInt(5) == 1;
            r.variantCount = c.getInt(6);
            r.stockTotal = c.getDouble(7);
            rows.add(r);
            if (r.id < 0 || r.localDirty) localCount++;

            String title = r.name + (r.active ? "" : "  •  INACTIF");
            String source = r.id < 0 ? "SQLite local" : (r.localDirty ? "Modifié localement" : "Serveur");
            String sub = money(r.price) + " Ar  •  " + r.variantCount + " variant(s)  •  stock " + qty(r.stockTotal) + "  •  " + source;
            items.add(new TwoLineAdapter.Item(title, sub));
        }
        c.close();
        list.setAdapter(new TwoLineAdapter(this, items));
        info.setText(rows.size() + " produit(s) affiché(s) • " + localCount + " création/modification SQLite");
    }

    private void showActions(ProductRow row) {
        String[] actions = row.variantCount == 0
                ? new String[]{"Modifier le produit", "Créer une variante par défaut", "Ouvrir le stock"}
                : new String[]{"Modifier le produit", "Ouvrir le stock"};
        AlertDialog d = new DialogUi.Builder(this)
                .setTitle(row.name)
                .setItems(actions, (dialog, which) -> {
                    String action = actions[which];
                    if (action.startsWith("Modifier")) showProductDialog(row);
                    else if (action.startsWith("Créer une variante")) showDefaultVariantDialog(row);
                    else startActivity(new Intent(this, StockActivity.class));
                })
                .setNegativeButton("Fermer", null)
                .create();
        d.show();
        DialogUi.style(d);
    }

    private void showDefaultVariantDialog(ProductRow row) {
        LinearLayout card = card();
        section(card, "Variante par défaut");
        hint(card, "Crée une variante sans couleur ni taille. Elle apparaîtra immédiatement dans le POS et le stock SQLite.");
        label(card, "Stock initial à Tsena");
        EditText qty = input("0 ou 0,5");
        qty.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        qty.setText("0");
        card.addView(qty);

        AlertDialog d = new DialogUi.Builder(this)
                .setTitle(row.name)
                .setView(container(card))
                .setPositiveButton("Créer", (x, w) -> {
                    try {
                        db.ensureDefaultVariantForLocalProduct(row.id, number(qty));
                        Toast.makeText(this, "Variante créée dans SQLite", Toast.LENGTH_SHORT).show();
                        load();
                    } catch (Exception e) {
                        Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Annuler", null)
                .create();
        d.show();
        DialogUi.style(d);
    }

    private void showProductDialog(ProductRow row) {
        final boolean editing = row != null;
        LinearLayout card = card();
        section(card, editing ? "Modifier le produit" : "Nouveau produit SQLite");
        hint(card, editing
                ? "Les modifications sont conservées dans SQLite, même après une mise à jour du catalogue."
                : "Le produit est créé localement et reste disponible hors ligne.");

        label(card, "Nom du produit *");
        EditText name = input("Ex: Body bébé coton");
        card.addView(name);

        label(card, "Prix de vente (Ar)");
        EditText price = input("0");
        price.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        card.addView(price);

        label(card, "Image (optionnel)");
        EditText image = input("URL complète ou chemin serveur");
        card.addView(image);

        label(card, "Statut");
        Spinner status = new Spinner(this);
        status.setBackgroundResource(R.drawable.bg_input);
        status.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Actif", "Inactif"}));
        card.addView(status, matchWrap());

        CheckBox defaultVariant = new CheckBox(this);
        defaultVariant.setText("Créer aussi une variante par défaut pour le POS");
        defaultVariant.setTextColor(0xFF334155);
        defaultVariant.setChecked(true);
        defaultVariant.setPadding(0, dp(10), 0, dp(4));
        defaultVariant.setVisibility(editing ? View.GONE : View.VISIBLE);
        card.addView(defaultVariant);

        LinearLayout qtyWrap = new LinearLayout(this);
        qtyWrap.setOrientation(LinearLayout.VERTICAL);
        qtyWrap.setVisibility(editing ? View.GONE : View.VISIBLE);
        TextView qtyLabel = new TextView(this);
        qtyLabel.setText("Stock initial à Tsena");
        qtyLabel.setTextColor(0xFF475569);
        qtyLabel.setTypeface(qtyLabel.getTypeface(), android.graphics.Typeface.BOLD);
        qtyLabel.setPadding(0, dp(4), 0, dp(5));
        EditText initialQty = input("0");
        initialQty.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        initialQty.setText("0");
        qtyWrap.addView(qtyLabel);
        qtyWrap.addView(initialQty);
        card.addView(qtyWrap);
        defaultVariant.setOnCheckedChangeListener((button, checked) -> qtyWrap.setVisibility(checked ? View.VISIBLE : View.GONE));

        if (editing) {
            name.setText(row.name);
            price.setText(trimNumber(row.price));
            image.setText(row.imageUrl == null ? "" : row.imageUrl);
            status.setSelection(row.active ? 0 : 1);
            hint(card, row.id < 0
                    ? "Produit 100 % local SQLite. Il n'est pas envoyé au serveur par cette version."
                    : "Produit issu du serveur : cette modification devient une préférence locale SQLite.");
        }

        AlertDialog dialog = new DialogUi.Builder(this)
                .setTitle(editing ? "Produit" : "Créer un produit")
                .setView(container(card))
                .setPositiveButton(editing ? "Enregistrer" : "Créer", null)
                .setNegativeButton("Annuler", null)
                .create();
        dialog.setOnShowListener(x -> {
            DialogUi.style(dialog);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try {
                    String n = name.getText().toString().trim();
                    double p = price.getText().toString().trim().isEmpty() ? 0 : number(price);
                    boolean active = status.getSelectedItemPosition() == 0;
                    if (editing) {
                        db.updateLocalProduct(row.id, n, p, image.getText().toString(), active);
                        Toast.makeText(this, "Produit modifié dans SQLite", Toast.LENGTH_SHORT).show();
                    } else {
                        double q = defaultVariant.isChecked() ? number(initialQty) : 0;
                        db.createLocalProduct(n, p, image.getText().toString(), active, defaultVariant.isChecked(), q);
                        Toast.makeText(this, "Produit créé dans SQLite", Toast.LENGTH_SHORT).show();
                    }
                    dialog.dismiss();
                    load();
                } catch (Exception e) {
                    Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        });
        dialog.show();
    }

    private LinearLayout card() {
        LinearLayout x = new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setPadding(dp(4), dp(2), dp(4), dp(6));
        return x;
    }

    private ScrollView container(LinearLayout content) {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.addView(content, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        return sc;
    }

    private void section(LinearLayout parent, String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(18); v.setTextColor(0xFF2F2B33); v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        v.setPadding(0, 0, 0, dp(4)); parent.addView(v);
    }
    private void hint(LinearLayout parent, String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(12); v.setTextColor(0xFF64748B); v.setPadding(0, 0, 0, dp(10)); parent.addView(v);
    }
    private void label(LinearLayout parent, String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(12); v.setTextColor(0xFF475569); v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        v.setPadding(0, dp(5), 0, dp(5)); parent.addView(v);
    }
    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextColor(0xFF1F2937); e.setHintTextColor(0xFF94A3B8); e.setTextSize(14);
        e.setSingleLine(true); e.setBackgroundResource(R.drawable.bg_input); e.setPadding(dp(12), 0, dp(12), 0);
        e.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));
        return e;
    }
    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        p.bottomMargin = dp(4); return p;
    }
    private double number(EditText e) throws Exception {
        String s = e.getText().toString().trim().replace(',', '.');
        if (s.isEmpty()) return 0;
        try { return Double.parseDouble(s); } catch (Exception ex) { throw new Exception("Valeur numérique invalide."); }
    }
    private String money(double v) { return String.format(Locale.FRANCE, "%,.0f", v); }
    private String qty(double v) {
        if (Math.abs(v - Math.rint(v)) < 0.00001) return String.valueOf((long)Math.rint(v));
        return String.format(Locale.FRANCE, "%.1f", v);
    }
    private String trimNumber(double v) {
        if (Math.abs(v - Math.rint(v)) < 0.00001) return String.valueOf((long)Math.rint(v));
        return String.valueOf(v).replace('.', ',');
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static class ProductRow {
        long id; String name; double price; boolean active; String imageUrl; boolean localDirty; int variantCount; double stockTotal;
    }
}
