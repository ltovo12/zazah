package mg.zazah.erp;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppPrefs {
    private static final String PREFS = "zazah_erp";
    private static final String API_DEFAULT =
            "https://zazahtsenasabotsy.infinityfree.io/zazah/admin/mobile_api";

    /*
     * V5.4 : fonctionnement comme la V4.
     * Le token est de nouveau enregistré dans SharedPreferences et peut être
     * modifié depuis Paramètres. La valeur par défaut reste compatible avec
     * le server_patch V5.1/V5.3 fourni précédemment.
     */
    private static final String TOKEN_DEFAULT =
            "ZAZAH-SYNC-2026-09-09-8f3c71d2a94e6b50";
    private static final String TOKEN_MIGRATION_V528 =
            "token_migration_v5_25_28_done";

    public static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String api(Context c) {
        String value = p(c).getString("api_url", API_DEFAULT);
        if (value == null || value.trim().isEmpty()) return API_DEFAULT;
        value = value.trim();
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    public static String token(Context c) {
        SharedPreferences prefs = p(c);

        /*
         * V5.25.30 : le token de synchronisation est verrouillé sur la valeur
         * commune livrée avec le server_patch. Une ancienne valeur conservée
         * après une mise à jour Android ne peut donc plus provoquer
         * "TOKEN invalide".
         */
        String stored = prefs.getString("api_token", "");
        if (stored == null || !TOKEN_DEFAULT.equals(stored.trim())) {
            prefs.edit()
                    .putString("api_token", TOKEN_DEFAULT)
                    .putBoolean(TOKEN_MIGRATION_V528, true)
                    .apply();
        }
        return TOKEN_DEFAULT;
    }

    public static String defaultToken() {
        return TOKEN_DEFAULT;
    }

    public static void resetToken(Context c) {
        p(c).edit()
                .putString("api_token", TOKEN_DEFAULT)
                .putBoolean(TOKEN_MIGRATION_V528, true)
                .apply();
    }

    public static String mode(Context c) {
        return p(c).getString("mode", "LOCAL");
    }

    public static void setMode(Context c, String mode) {
        p(c).edit().putString("mode", mode).apply();
    }

    public static String printerAddress(Context c) {
        return p(c).getString("printer_address", "");
    }

    public static String printerName(Context c) {
        return p(c).getString("printer_name", "");
    }

    public static String printerMode(Context c) {
        return p(c).getString("printer_mode", "AUTO");
    }

    public static int paperWidth(Context c) {
        int width = p(c).getInt("paper_width", 58);
        return width == 80 ? 80 : 58;
    }

    public static boolean autoPrint(Context c) {
        return p(c).getBoolean("auto_print", true);
    }

    // V5.25.33 - session utilisateur locale SQLite.
    public static long sessionUserId(Context c) {
        return p(c).getLong("session_user_id", 0L);
    }

    public static long sessionStartedAt(Context c) {
        return p(c).getLong("session_started_at", 0L);
    }

    public static boolean hasSession(Context c) {
        return sessionUserId(c) > 0L;
    }

    public static void openSession(Context c, long userId) {
        p(c).edit()
                .putLong("session_user_id", userId)
                .putLong("session_started_at", System.currentTimeMillis())
                .apply();
    }

    public static void clearSession(Context c) {
        p(c).edit()
                .remove("session_user_id")
                .remove("session_started_at")
                .apply();
    }

    // V5.25.41 - thème visuel persistant.
    public static String uiTheme(Context c) {
        String value = p(c).getString("ui_theme", "ODOO");
        if (value == null) return "ODOO";
        value = value.trim().toUpperCase(java.util.Locale.ROOT);
        if (!"ODOO".equals(value) && !"HERCULE".equals(value)
                && !"AURORA".equals(value) && !"GRAPHITE".equals(value)) {
            return "ODOO";
        }
        return value;
    }

    public static void setUiTheme(Context c, String theme) {
        if (theme == null) theme = "ODOO";
        String value = theme.trim().toUpperCase(java.util.Locale.ROOT);
        if (!"ODOO".equals(value) && !"HERCULE".equals(value)
                && !"AURORA".equals(value) && !"GRAPHITE".equals(value)) {
            value = "ODOO";
        }
        p(c).edit().putString("ui_theme", value).apply();
    }

    public static String uiThemeLabel(Context c) {
        switch (uiTheme(c)) {
            case "HERCULE": return "Hercule";
            case "AURORA": return "Aurora 2026";
            case "GRAPHITE": return "Graphite 2026";
            default: return "Odoo";
        }
    }

}
