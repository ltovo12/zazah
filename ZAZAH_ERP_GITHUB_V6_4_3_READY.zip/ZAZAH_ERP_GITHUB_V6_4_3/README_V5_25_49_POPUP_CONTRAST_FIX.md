# V5.25.49 — Popup contrast fix

Correction visuelle des fenêtres premium introduites en V5.25.48.

- Les lignes blanches des variantes POS gardent désormais un texte sombre et lisible.
- Correction appliquée à toutes les listes utilisant `TwoLineAdapter` (produits, stock, packs, historique, clients, employés, paie, utilisateurs, étiquettes, etc.).
- Les Spinners clairs ne reçoivent plus un texte blanc provenant du style global des popups.
- Ajout d'un marqueur `zazah_light_card` pour protéger automatiquement les textes des cartes claires.
- Style premium graphite/blanc, bouton Fermer et autres fonctions V5.25.48 conservés.

Version Android : `5.25.49-popup-contrast-fix`  
VersionCode : `80`
