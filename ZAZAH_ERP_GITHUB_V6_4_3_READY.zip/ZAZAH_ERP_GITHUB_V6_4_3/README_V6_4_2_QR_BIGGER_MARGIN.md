# ZAZAH ERP Android SQLite V6.4.2

## Modifications
- QR 40x30 agrandi
- QR 60x40 agrandi
- marge ajoutée côté QR pour éviter qu'il soit collé au bord
- disposition texte à gauche / QR à droite conservée
- 1 seule avance papier de fin conservée

## Version
- versionCode : 115
- versionName : 6.4.2-qr-bigger-margin
