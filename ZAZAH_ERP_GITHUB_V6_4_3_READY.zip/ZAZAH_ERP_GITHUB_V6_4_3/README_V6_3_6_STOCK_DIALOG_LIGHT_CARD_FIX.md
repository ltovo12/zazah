# ZAZAH ERP Android SQLite V6.3.6

## Correction
- Les cartes blanches des fenêtres Stock sont maintenant marquées comme cartes claires.
- DialogUi conserve donc les textes foncés au lieu de les remplacer par du texte blanc.
- Corrige Ajouter quantité stock, Changer produit et les autres formulaires Stock utilisant dialogCard().
- Toutes les fonctions V6.3.5 sont conservées.

## Version
- versionCode : 109
- versionName : 6.3.6-stock-dialog-light-card-fix
