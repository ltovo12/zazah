# ZAZAH ERP Android SQLite V6.1.6

Amélioration visuelle du générateur d'image marketing du module Pack.

## Changements
- nouveau rendu plus premium / plus propre
- meilleure hiérarchie visuelle
- cartes produit plus lisibles
- bloc prix plus visible
- fond plus élégant
- conservation des fonctions : image pack, logo, WhatsApp, format carré, partage

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/PackImageGenerator.java`
- `app/build.gradle`
