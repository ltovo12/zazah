# ZAZAH ERP Android V5.25.41 — Thèmes + À propos

- Ajout de deux boutons sur le tableau de bord : **Thèmes** et **À propos**.
- 4 thèmes persistants : **Odoo**, **Hercule**, **Aurora 2026**, **Graphite 2026**.
- Le thème choisi est mémorisé dans SharedPreferences et appliqué au prochain affichage de chaque écran.
- Les principaux fonds, cartes, entêtes, boutons, champs et dialogues utilisent maintenant des couleurs pilotées par le thème.
- Conservation des corrections précédentes : PIN au démarrage, contraste des boutons, Tsena par défaut.
- versionCode : 72
- versionName : 5.25.41-themes-about
