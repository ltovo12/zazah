# ZAZAH ERP Android V5.25.39 — contraste global des boutons

Corrections :
- texte lisible sur tous les boutons XML de l’application ;
- suppression de la teinte Android/Material qui pouvait masquer les fonds personnalisés ;
- couleurs de texte forcées opaques ;
- légère ombre de contraste pour les libellés ;
- boutons des AlertDialog corrigés ;
- boutons créés dynamiquement dans POS et Packs corrigés ;
- suppression des emoji dans certains libellés de boutons pour éviter les glyphes invisibles sur certains téléphones ;
- conservation du verrouillage PIN au démarrage de la V5.25.38.

Version : 5.25.39-global-button-contrast
VersionCode : 70
