SERVEUR V5.9

Dans /zazah/admin/mobile_api/ :
1. Remplacer browser_sync.php
2. Ajouter push_masterdata.php

Ne remplacez PAS config_mobile.php si votre TOKEN actuel fonctionne.
La table mobile_sync_ops est créée automatiquement par push_masterdata.php.
