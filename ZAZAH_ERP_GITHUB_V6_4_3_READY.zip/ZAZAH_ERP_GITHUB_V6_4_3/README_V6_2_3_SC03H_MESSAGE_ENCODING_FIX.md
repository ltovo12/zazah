# ZAZAH ERP Android SQLite V6.2.3

Correction renforcée du message de bas de ticket SC03h.

## Correction
- réparation de plusieurs niveaux de mojibake UTF-8
- correction des caractères français : é è ê ë à â ä ù û ü ô ö î ï ç É È À
- correction des apostrophes et guillemets mal encodés
- correction d'entités HTML fréquentes
- correction appliquée avant rendu bitmap, donc indépendante du protocole thermique

## Version
- versionCode 96
- versionName 6.2.3-sc03h-message-encoding-fix

## Fichier modifié
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
