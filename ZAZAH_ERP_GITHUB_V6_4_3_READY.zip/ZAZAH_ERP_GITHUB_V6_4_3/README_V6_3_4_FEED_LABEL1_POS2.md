# ZAZAH ERP Android SQLite V6.3.4

- Étiquette QR/Barcode : 1 avance papier à la fin
- Ticket Vente POS : 2 avances papier à la fin
- Appliqué à SC03h et ESC/POS
- QR 40x30 / 60x40 et QR grand sans contour conservés

versionCode 107
versionName 6.3.4-feed-label1-pos2
