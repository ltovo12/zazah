# ZAZAH ERP Android SQLite V6.3.3

## Changements
- QR code agrandi
- suppression du contour/cadre autour du QR
- valable pour les formats QR 40x30 et 60x40
- le QR prend presque toute la zone disponible

## Version
- versionCode : 106
- versionName : 6.3.3-qr-big-no-border

## Fichiers modifiés
- app/src/main/java/mg/zazah/erp/Sc03BlePrinter.java
- app/build.gradle
