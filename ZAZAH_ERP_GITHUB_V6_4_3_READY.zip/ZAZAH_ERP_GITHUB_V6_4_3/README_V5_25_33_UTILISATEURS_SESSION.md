# ZAZAH ERP Android SQLite V5.25.33 — Utilisateurs & Session

Cette version ajoute deux modules Android locaux : **Utilisateurs** et **Session**.

## Utilisateurs
- Nouveau bouton **Utilisateurs** dans le menu principal.
- Création, modification, activation/désactivation et suppression des comptes Android.
- Rôles : **Administrateur** et **Utilisateur**.
- PIN local facultatif de 4 à 8 chiffres.
- Le PIN est stocké sous forme d'empreinte SHA-256 dans SQLite, jamais en clair.
- Protection du dernier administrateur actif.
- Le compte initial `admin` / Administrateur est créé automatiquement lors de la migration.

## Session
- Nouveau bouton **Session** dans le menu principal.
- Affiche l'utilisateur actuellement connecté.
- Permet d'ouvrir/changer de session en touchant un utilisateur.
- Demande le PIN uniquement si l'utilisateur en a défini un.
- Bouton **Fermer la session**.
- Bouton **Menu principal**.
- La session reste mémorisée après fermeture/réouverture de l'application.

## Important
Ces comptes et PIN sont locaux à l'application Android SQLite. Ils ne modifient pas les mots de passe des utilisateurs du site en ligne.

## Mise à jour
Ouvrir le projet complet dans Android Studio, puis :
1. Sync Project with Gradle Files
2. Build > Clean Project
3. Build > Rebuild Project

Aucune suppression de la base SQLite existante n'est nécessaire : la migration passe automatiquement la base de version 14 à version 15.
