# ZAZAH V5.25.19 — Recherche article + liaison stock

- Champ de recherche visible lors de l’ajout/modification d’un article de pack.
- Recherche par produit, couleur, taille et code-barres.
- Stock affiché en total tous emplacements ; stock 0 reste sélectionnable.
- Validation réelle de la variante avant enregistrement de la liaison.
- Message clair si le catalogue local n’est pas synchronisé.
- Compatible avec les packs et images de V5.25.18.
