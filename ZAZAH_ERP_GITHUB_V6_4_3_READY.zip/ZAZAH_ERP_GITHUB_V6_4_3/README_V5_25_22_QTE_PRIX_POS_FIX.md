# ZAZAH V5.25.22 — Quantité / prix / liaison pack

- Vérification après chaque ajout ou modification d’un article de pack.
- La quantité, le prix et la variante liée sont relus depuis SQLite après sauvegarde.
- Une erreur claire est affichée si SQLite n’a pas enregistré la valeur demandée.
- Le POS Android conserve son chargement initial des produits.
