# ZAZAH ERP Android SQLite V5.25.5 — Synchronisation Paie vers local

Base: V5.25.4 Sync Salariés.

## Correction principale
La synchronisation MySQL -> SQLite récupère maintenant :
- salariés
- avances de salaire
- fiches de paie
- paiements partiels de paie

## SQLite
DB_VERSION = 9.
Les tables `avances`, `paies` et `paie_paiements` reçoivent un `server_id` pour éviter les doublons lors des synchronisations suivantes.

## Correspondance
- `salaries.server_id` relie le salarié MySQL au salarié SQLite.
- `paies.server_id` relie la fiche de paie MySQL à la fiche SQLite.
- les avances et paiements sont importés en conservant leurs IDs serveur.

## Conflit même salarié / même mois
Si une paie locale existe déjà pour le même salarié et le même mois, elle est associée à la fiche serveur et mise à jour avec les données en ligne.

## Important
Cette version corrige surtout le téléchargement ERP en ligne -> SQLite pour la paie.
Les paies générées uniquement en local ne sont pas encore envoyées vers MySQL.
