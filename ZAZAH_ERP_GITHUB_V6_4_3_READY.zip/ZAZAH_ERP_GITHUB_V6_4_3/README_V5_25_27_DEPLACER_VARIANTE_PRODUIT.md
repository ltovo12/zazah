# ZAZAH ERP Android SQLite V5.25.27

## Changer le produit d’une variante

- Dans Stock, appui long sur une variante ou bouton **Changer produit** dans la fenêtre d’ajout de stock.
- Recherche du produit destination par nom.
- La variante conserve son ID, code-barres, couleur, taille, prix, image et stocks.
- Protection contre une combinaison couleur/taille déjà existante dans le produit destination.
- En mode ONLINE, la modification est mise en file d’attente et synchronisée vers le même ID de variante en ligne.
- Les anciennes ventes gardent leur désignation historique.

## Ticket pack mobile

- Le ticket Bluetooth affiche le prix global du pack une seule fois.
- Les composants du pack affichent seulement leur désignation et leur quantité, sans prix par article.
