# ZAZAH ERP Android SQLite V5.25.8

## Paie calculée selon la période propre de chaque salarié

- La liste Paie est regroupée par le mois de **fin de période** (ex. Sept-26), et non par un mois calendrier imposé.
- Chaque fiche garde ses propres `periode_debut` et `periode_fin`.
- Le recalcul reprend le **salaire de base actuel** du salarié, ses repas et uniquement les avances comprises dans sa propre période.
- `Générer tous` reproduit le cycle historique de chaque salarié : ex. 21→20, 18→17, 1→fin de mois.
- `Générer une paie` propose automatiquement la période propre du salarié sélectionné.
- Le bouton et les libellés utilisent **Période** au lieu de **Mois**.
- Les paiements partiels restent séparés du net calculé.
- La synchronisation Paie existante reste compatible.

Aucun changement de schéma SQLite n'est nécessaire pour cette version.
