# V5.25.9 — Recalcul local corrigé

Correction du module Paie SQLite local :

- `Recalculer la période` met à jour directement chaque fiche `paies.id`.
- Le salaire de base est relu depuis `salaries.salaire_base` à chaque recalcul.
- L'allocation repas / jour est relue depuis la fiche salarié actuelle.
- Les avances sont recalculées uniquement entre `periode_debut` et `periode_fin` propres à la fiche.
- `net_a_payer = salaire_base actuel + total repas - avances de la période`.
- Les paiements partiels restent séparés et ne sont pas modifiés.
- La liste est rafraîchie immédiatement après recalcul.

Exemple :
Base salarié actuelle 120 000 Ar, avances de sa période 47 000 Ar, repas 0 Ar
=> net recalculé 73 000 Ar.
