# ZAZAH ERP Android SQLite V5.25.6

## Avances salariés
- Sélection d’un salarié => détection automatique de sa dernière période de paie.
- Les dates Début / Fin sont remplies automatiquement.
- La liste des avances se recharge immédiatement.
- Si aucune paie n’existe pour ce salarié, le mois courant est utilisé.
- Le bouton Nouvelle avance pré-sélectionne le salarié actuellement filtré.

## Paie mensuelle
- Le champ technique `AAAA-MM` a été remplacé par une liste déroulante.
- Affichage lisible : `Sept-26`, `Oct-26`, etc.
- La valeur interne reste `YYYY-MM` pour ne pas casser les calculs ni la synchronisation.
- Les mois déjà présents dans SQLite sont ajoutés à la liste, même s’ils sont anciens.
- La sélection d’un mois recharge automatiquement la liste des paies.

La synchronisation Paie de la V5.25.5 est conservée. Aucun changement serveur n’est nécessaire pour cette amélioration d’interface.
