# ZAZAH ERP Android V5.25.38 — PIN au démarrage

Cette version ajoute un véritable verrouillage de l'application au lancement.

- `StartupPinActivity` devient l'activité LAUNCHER.
- Si la session active possède un PIN, le PIN est demandé **avant** l'accès au menu principal.
- Un PIN incorrect ne permet pas d'ouvrir l'ERP.
- Le bouton **Changer d’utilisateur** ouvre la sélection de session ; un utilisateur protégé devra lui aussi saisir son PIN.
- S'il n'existe aucune session, l'application demande d'abord de choisir un utilisateur.
- Si l'utilisateur actif n'a pas de PIN configuré, l'application s'ouvre normalement.
- `MainActivity` n'est plus exportée, ce qui empêche de contourner l'écran de verrouillage depuis l'extérieur de l'application.
- Si l'icône ZAZAH ERP est retouchée alors que l'application est déjà ouverte, l'ancienne pile d'écrans est effacée avant le verrouillage : le bouton Retour ne peut pas révéler l'ERP derrière le PIN.
- En mode sélection au démarrage, les boutons Menu principal / Utilisateurs / Fermer session sont masqués pour éviter un contournement.

Version Android : `5.25.38-startup-pin-lock` (`versionCode 69`).
