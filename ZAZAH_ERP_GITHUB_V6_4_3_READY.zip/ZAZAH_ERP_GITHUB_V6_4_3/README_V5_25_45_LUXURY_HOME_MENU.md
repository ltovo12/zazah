# ZAZAH ERP Android V5.25.45 — Menu principal moderne & luxe

- Accueil entièrement redessiné avec un en-tête premium, statut de session et mode LOCAL/EN LIGNE.
- Compteurs plus lisibles et compacts.
- POS mis en avant comme action principale.
- Menus regroupés en sections : Accès rapide, Gestion, Équipe & administration, Personnalisation.
- Cartes 2 colonnes, badges sobres sans dépendre des emoji, meilleur contraste et effets 3D légers.
- Compatible avec les 4 thèmes Odoo, Hercule, Aurora 2026 et Graphite 2026.
- Toutes les fonctions et IDs de la V5.25.44 sont conservés.
- versionCode 76 / versionName 5.25.45-luxury-home-menu.
