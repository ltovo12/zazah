# ZAZAH ERP Android SQLite V5.25.31 — Synchronisation Packs

Cette version corrige la synchronisation des Packs Nouveau-né dans les deux sens.

- Pack créé/modifié/supprimé sur Android -> envoyé vers MySQL.
- Composition complète du pack (articles, variante liée, quantité, prix détail, ordre) -> envoyée vers MySQL.
- Pack créé/modifié/supprimé en ligne -> téléchargé vers SQLite.
- Les packs existants sont rapprochés par `server_id`; au premier passage, les packs standards peuvent être rapprochés par leur nom pour éviter les doublons.
- Une modification locale en attente n'est jamais écrasée par le catalogue serveur.
- Les liaisons `variante_id` sont conservées et suivent le remappage des nouvelles variantes locales.
- Le correctif TOKEN V5.25.30 reste inclus.

Important : mettre à jour à la fois l'application Android et les fichiers serveur `admin/mobile_api/` fournis dans la V5.25.31.
