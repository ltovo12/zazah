# ZAZAH ERP Android SQLite V6.1.9

Amélioration du rendu image pack.

## Changements
- quantité affichée aussi sur chaque sous-produit
- petite icône devant chaque sous-produit
- conservation du style rouge / blanc
- quantité entre parenthèses au titre et aux sous-produits

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/PackImageGenerator.java`
- `app/build.gradle`
