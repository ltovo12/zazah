# ZAZAH ERP Android SQLite V6.1.7

Style de la liste des packs inspiré du modèle envoyé par l'utilisateur.

## Changements
- style fiche claire pour la liste des produits du pack
- pilule rouge pour le titre de chaque bloc
- texte plus foncé et plus lisible
- cartes blanches / rosées avec contour doux
- appliqué au générateur d'image pack

## Fichiers modifiés
- `app/src/main/java/mg/zazah/erp/PackImageGenerator.java`
- `app/build.gradle`
