V5.21
- nouveau client SQLite -> sync en ligne
- modification client local/synchronise -> update meme client MySQL
- clic client pour modifier nom/contact/adresse
- conserve V5.20 panier une ligne et anti-fermeture
