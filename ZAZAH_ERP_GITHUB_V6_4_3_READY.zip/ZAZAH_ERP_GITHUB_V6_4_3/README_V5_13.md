V5.13
- images online: URL complete côté serveur
- chargement Android avec User-Agent navigateur et Referer
- cache local des images pour affichage hors ligne après premier chargement
- mode ESPECES: montant reçu = total automatiquement
- le champ reçu est rempli automatiquement dans le popup paiement
