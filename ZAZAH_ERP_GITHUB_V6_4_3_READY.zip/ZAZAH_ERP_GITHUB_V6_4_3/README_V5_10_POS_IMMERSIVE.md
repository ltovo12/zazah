V5.10
- Barre de navigation Android masquee uniquement dans le POS.
- Mode immersif sticky.
- Geste depuis le bord pour afficher temporairement la barre.
- Les autres ecrans Android gardent leur navigation normale.
