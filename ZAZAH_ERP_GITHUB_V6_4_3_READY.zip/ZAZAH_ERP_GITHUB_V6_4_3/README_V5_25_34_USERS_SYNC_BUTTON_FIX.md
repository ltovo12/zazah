# V5.25.34
Utilisateurs Android ↔ serveur + correction lisibilité des boutons clairs du POS. SQLite passe en version 16. Le PIN reste local et les mots de passe serveur ne sont jamais téléchargés.
